from pathlib import Path
import json, hashlib, math
p=Path(__file__).resolve().parent
m=json.loads((p/'MANIFEST.json').read_text())
for name,digest in m.items():
    assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
runs=json.loads((p/'data/swarm_runs.json').read_text())['runs']
v=json.loads((p/'data/swarm_validation.json').read_text())['records']
for run in runs:
    seed=run['seed']; events=run['events']; rec=v[f'global_swarm_seed{seed}_final']
    assert len(events)==961 and [e['evaluation'] for e in events]==list(range(1,962))
    assert len({e['label_sha256'] for e in events})==961
    assert run['resolved']+run['unresolved']==961
    best=min((e for e in events if e['resolved']),key=lambda e:e['loss'])
    assert best['label_sha256']==rec['label_sha256']
    assert rec['passed'] and rec['strict_tolerance']==1e-10
    assert v[f'start_seed{seed}']['passed']
    assert abs(rec['strict_loss']-run['best_loss'])<1e-9
    assert all(sum(e['agent']==agent for e in events)==24 for agent in range(40))
    print(seed,format(rec['strict_loss'],'.15g'))
print('PASS: manifest, 3 x 961 event budgets, 40-agent participation, and recorded strict validation')
