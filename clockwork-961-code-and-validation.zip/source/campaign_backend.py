"""Atomic physical-score cache for independent, checkpointed optimization trials."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
from pathlib import Path
import hashlib,json,time
import numpy as np
from scipy.io import savemat
from swarm import Problem,mat
from fem import relative_loss
from scaled_search import atomic_json

class CampaignProblem(Problem):
    def __init__(self,data,out,tol=1e-8,solver_mode='fresh'):
        super().__init__(data)
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=True);self.tol=tol;self.solver_mode=solver_mode
        self.target=mat(self.data/'UOrigin.mat','UOrigin');self.interest=mat(self.data/'Interest.mat','Interest')
        self.mask=np.pad(self.interest,((0,1),(0,1)),mode='edge')>0
        digest=hashlib.sha256()
        for name in ['physical.py','fast_physical.py','swarm.py','fem.py','campaign_backend.py']:
            digest.update(Path(__file__).with_name(name).read_bytes())
        for name in ['Indicator.mat','PhiIndex.mat','OriginCell.mat','ShapeSpace.mat','UOrigin.mat','Interest.mat']:
            digest.update((self.data/name).read_bytes())
        digest.update((self.data.parent/'Label_opt.mat').read_bytes())
        self.identity={'model':'pixel-half-void-schur-v1','sha256':digest.hexdigest(),'tolerance':tol,'solver_mode':solver_mode}
        meta=self.out/'model_identity.json'
        if meta.exists() and json.loads(meta.read_text())!=self.identity:raise ValueError('Physical model/cache identity mismatch; use a fresh campaign cache')
        atomic_json(meta,self.identity)
        cache=self.out/'evaluations.json';self.records=json.loads(cache.read_text()) if cache.exists() else {}
        self.solves=0;self.attempts=0;self.cache_hits=0;self.reset_solver()
    def reset_solver(self):
        if hasattr(self,'solver') and hasattr(self.solver,'reset'):self.solver.reset()
        if self.solver_mode in ('reuse','warm'):
            from fast_physical import PixelSolver
            self.solver=PixelSolver(tol=self.tol,refresh_every=0 if self.solver_mode=='warm' else 12,reuse_maxiter=100)
        elif self.solver_mode=='fresh':
            from physical import PixelSolver
            self.solver=PixelSolver(tol=self.tol)
        else:raise ValueError('Unknown solver mode')
    def score(self,x):
        x=np.asarray(x)
        if x.shape!=(len(self.active),) or not np.issubdtype(x.dtype,np.integer) or np.any((x<0)|(x>14)):raise ValueError('Invalid label vector')
        key=hashlib.sha256(np.asarray(x,dtype='<i2').tobytes()).hexdigest()[:20]
        old=self.records.get(key)
        if old is not None and old['tolerance']<=self.tol:
            self.cache_hits+=1;return old['loss'] if old.get('status','ok')=='ok' else np.inf
        self.attempts+=1;start=time.perf_counter();phi=self.assemble(x)
        try:
            active=np.zeros((1501,1501),bool)
            for dy in [0,1]:
                for dx in [0,1]:active[dy:dy+1500,dx:dx+1500]|=phi>0
            if np.any(self.mask&~active):raise ValueError('Objective has eliminated void-only nodes')
            u,stats=self.solver.solve(phi);loss=relative_loss(u,self.target,self.interest)
            if not np.isfinite(loss):raise RuntimeError('Nonfinite physical loss')
        except (ValueError,RuntimeError) as error:
            self.records[key]={'loss':None,'status':'unresolved','labels':x.tolist(),'tolerance':self.tol,'reason':str(error),'wall_seconds':time.perf_counter()-start}
            atomic_json(self.out/'evaluations.json',self.records)
            print(json.dumps({'event':'physical_unresolved','label':key,'reason':str(error)}),flush=True)
            return np.inf
        self.solves+=1
        self.records[key]={'loss':loss,'status':'ok','labels':x.tolist(),'tolerance':self.tol,'stats':stats,'wall_seconds':time.perf_counter()-start}
        atomic_json(self.out/'evaluations.json',self.records)
        best=min((r for r in self.records.values() if r.get('status','ok')=='ok' and r['tolerance']<=self.tol),key=lambda r:r['loss'])
        # This global cache winner is an output only, never a search-run incumbent.
        tmp=self.out/'best_label.tmp';savemat(str(tmp),{'Label':self.labels(np.asarray(best['labels'],int))},appendmat=False);tmp.replace(self.out/'best_label.mat')
        if best is self.records[key]:
            tmp=self.out/'best_retained_displacement.tmp'
            with tmp.open('wb') as f:np.savez_compressed(f,u=u,loss=loss,labels=self.labels(x))
            tmp.replace(self.out/'best_retained_displacement.npz')
        print(json.dumps({'event':'physical_score','label':key,'loss':loss,'fresh_successful_solves':self.solves}),flush=True)
        return loss
