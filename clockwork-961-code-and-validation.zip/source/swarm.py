"""Seeded portfolio search with explicitly selected lookup or physical objective."""
from pathlib import Path
import argparse,json,time
import numpy as np
from scipy.io import loadmat,savemat
import h5py

def mat(path,key):
    try:return loadmat(path)[key]
    except NotImplementedError:
        with h5py.File(path) as f:return np.array(f[key]).T

class Problem:
    def __init__(self,data,objective="lookup",allow_large=False):
        self.objective=objective;self.allow_large=allow_large;self.cache={}
        self.data=Path(data); self.indicator=mat(self.data/'Indicator.mat','Indicator')
        self.passive=self.indicator[2:-2,2:15]
        # Assemble visits label positions row-wise; lookup rows follow that visit order.
        self.active=np.flatnonzero(self.passive.ravel()==1)
        self.cost=mat(self.data/'Uenergy.mat','Uenergy')[self.active]
        self.phi_index=mat(self.data/'PhiIndex.mat','PhiIndex').astype(int)
        self.prior=mat(self.data.parent/'Label_opt.mat','Label').astype(int)
        self.initial=self.prior.ravel()[self.active]
        if np.any(self.phi_index[self.active]<=0):raise ValueError('Invalid active shape reference')
    def score(self,x):
        x=np.asarray(x)
        if x.shape!=(len(self.active),) or not np.issubdtype(x.dtype,np.integer) or np.any((x<0)|(x>14)):raise ValueError('Labels must be integer vector in 0..14')
        if self.objective=='lookup':return float(self.cost[np.arange(len(x)),x].sum())
        key=x.tobytes()
        if key not in self.cache:
            from physical import PixelSolver
            from fem import relative_loss
            u,_=PixelSolver().solve(self.assemble(x))
            self.cache[key]=relative_loss(u,mat(self.data/'UOrigin.mat','UOrigin'),mat(self.data/'Interest.mat','Interest'))
        return self.cache[key]
    def labels(self,x):
        result=self.prior.copy(); result.ravel()[self.active]=x; return result
    def assemble(self,x):
        labels=self.labels(x); origin=mat(self.data/'OriginCell.mat','OriginCell')
        structure=np.zeros((1300,650),dtype=np.uint8)
        shape_path=self.data/'ShapeSpace.mat'
        from contextlib import nullcontext
        hdf=h5py.is_hdf5(shape_path)
        with (h5py.File(shape_path) if hdf else nullcontext({'ShapeSpace':mat(shape_path,'ShapeSpace')})) as f:
            shapes=f['ShapeSpace']
            for y in range(26):
                for col in range(13):
                    kind=self.passive[y,col]
                    if kind==1:cell=(np.array(shapes[self.phi_index[y*13+col,labels[y,col]]-1]).T if hdf else shapes[:,:,self.phi_index[y*13+col,labels[y,col]]-1])
                    elif kind==2:cell=origin
                    else:continue
                    structure[(25-y)*50:(26-y)*50,col*50:(col+1)*50]=cell[::-1,:]
        phi=np.tile(origin,(30,30));phi[100:1400,100:1400]=np.concatenate((structure,structure[:,::-1]),axis=1)
        return phi

class Evaluator:
    def __init__(self,p,budget):self.p=p;self.budget=budget;self.calls=0;self.best=np.inf;self.x=None;self.trace=[]
    def __call__(self,x):
        if self.calls>=self.budget:raise StopIteration
        score=self.p.score(x);self.calls+=1
        if score<self.best:self.best=score;self.x=x.copy();self.trace.append([self.calls,score])
        return score

def search(p,method,seed,budget):
    rng=np.random.default_rng(seed);e=Evaluator(p,budget);n=len(p.active);x=p.initial.copy();sx=e(x)
    roles=['random','mutation','annealing','coordinate','genetic','cross_entropy'] if method=='swarm' else [method]
    archive=[(sx,x.copy())];prob=np.full((n,15),1/15);credits={r:0 for r in roles};turn=0
    try:
        while True:
            role=roles[turn%len(roles)];turn+=1; before=e.best
            if role=='random':candidate=rng.integers(15,size=n)
            elif role=='coordinate':
                candidate=e.x.copy();j=(turn//len(roles))%n;candidate[j]=(turn//(len(roles)*n))%15
            elif role=='cross_entropy':
                elite=np.array([v for _,v in sorted(archive,key=lambda z:z[0])[:max(2,len(archive)//4)]])
                counts=np.array([(elite==k).mean(axis=0) for k in range(15)]).T
                prob=.8*prob+.2*(.95*counts+.05/15)
                candidate=np.array([rng.choice(15,p=row/row.sum()) for row in prob])
            elif role=='genetic':
                parents=[archive[rng.integers(min(8,len(archive)))][1] for _ in range(2)]
                candidate=np.where(rng.random(n)<.5,*parents).copy();mask=rng.random(n)<.04;candidate[mask]=rng.integers(15,size=mask.sum())
            else:
                candidate=(x if role=='annealing' else e.x).copy();mask=rng.random(n)<(max(1/n,.03) if role=='mutation' else 1/n)
                if not mask.any():mask[rng.integers(n)]=True
                candidate[mask]=rng.integers(15,size=mask.sum())
            sc=e(candidate);credits[role]+=max(0,before-e.best)
            temp=max(1e-7,.01*(1-e.calls/budget))
            if sc<sx or (role=='annealing' and rng.random()<np.exp(min(0,(sx-sc)/temp))):x,sx=candidate,sc
            archive.append((sc,candidate.copy()));archive=sorted(archive,key=lambda z:z[0])[:32]
    except StopIteration:pass
    return {'method':method,'seed':seed,'evaluations':e.calls,'score':e.best,'trace':e.trace,'credits':credits},e.x

def main():
    a=argparse.ArgumentParser();a.add_argument('--data',type=Path,required=True);a.add_argument('--out',type=Path,default=Path('results'));a.add_argument('--budget',type=int,default=10000);a.add_argument('--seeds',type=int,default=5);a.add_argument('--objective',choices=['lookup','fem'],default='lookup');a.add_argument('--allow-large',action='store_true');a.add_argument('--methods',nargs='+',choices=['random','mutation','annealing','coordinate','genetic','cross_entropy','swarm'],default=['random','mutation','annealing','coordinate','genetic','cross_entropy','swarm']);args=a.parse_args()
    if args.budget<1 or args.seeds<1:a.error('budget and seeds must be positive')
    args.out.mkdir(parents=True,exist_ok=True);p=Problem(args.data,args.objective,args.allow_large);results=[];best=None
    for method in args.methods:
        for seed in range(args.seeds):
            start=time.perf_counter();r,x=search(p,method,seed,args.budget);r['seconds']=time.perf_counter()-start;results.append(r)
            if best is None or r['score']<best[0]:best=(r['score'],x)
    report={'objective':('sum of active Uenergy entries, lookup proxy only' if args.objective=='lookup' else 'full-resolution exterior displacement loss; zero-void Schur limit'),'active_cells':len(p.active),'prior_score':p.score(p.initial),'runs':results}
    if args.objective=='lookup':
        oracle=p.cost.argmin(axis=1);report['exact_separable_minimum']=p.score(oracle);savemat(args.out/'lookup_optimal_label.mat',{'Label':p.labels(oracle)})
    (args.out/'results.json').write_text(json.dumps(report,indent=2));savemat(args.out/'best_label.mat',{'Label':p.labels(best[1])})
    print(json.dumps({k:v for k,v in report.items() if k!='runs'},indent=2))
    for method in sorted(set(r['method'] for r in results)):
        rr=[r['score'] for r in results if r['method']==method];print(method,np.mean(rr),np.std(rr))
if __name__=='__main__':main()
