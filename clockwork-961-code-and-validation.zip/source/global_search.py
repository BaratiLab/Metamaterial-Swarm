"""Physical-only global categorical search: forty agents in five diverse islands.
No supplied solution, lookup proxy, or target loss is used by this optimizer.
Trusted-local pickle checkpoints contain complete RNG and search state.
"""
import hashlib,json,pickle,time
from pathlib import Path
import numpy as np
from scaled_search import atomic_json,atomic_pickle,fingerprint
ROLES=('uniform_global','correlated_field','multiscale_mutation','categorical_learning','recombination','diversity_reset','annealed_neighborhood','coordinate_polish')

def optimize(problem,method,budget,seed,initial,on_progress=None,checkpoint=None):
    if method=='coordinate_descent':
        from scaled_search import optimize as coordinate
        return coordinate(problem,method,budget,seed,initial,on_progress,checkpoint)
    if method!='global_swarm':raise ValueError('Expected global_swarm or coordinate_descent')
    if budget<1:raise ValueError('Budget must be positive')
    initial=np.asarray(initial)
    if initial.ndim!=1 or len(initial)!=len(problem.active) or not np.issubdtype(initial.dtype,np.integer) or np.any((initial<0)|(initial>14)):raise ValueError('Invalid initial labels')
    initial=initial.astype(int);n=len(initial)
    if not n:raise ValueError('No design variables')
    identity={'method':method,'seed':seed,'dimension':n,'initial_sha256':fingerprint(initial),'model':getattr(problem,'identity',None),'physical_tolerance':getattr(problem,'tol',None),'algorithm_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'dependency_sha256':hashlib.sha256(Path(__file__).with_name('scaled_search.py').read_bytes()).hexdigest()}
    path=Path(checkpoint) if checkpoint else None
    if path and path.exists():
        st=pickle.loads(path.read_bytes())
        if st['identity']!=identity:raise ValueError('Checkpoint identity mismatch')
        if st['calls']>budget:raise ValueError('Budget smaller than completed calls')
    else:
        streams=np.random.SeedSequence(seed).spawn(40)
        st={'homogeneous_order':np.random.default_rng(np.random.SeedSequence([seed,73129])).permutation(15),'identity':identity,'calls':0,'seen':{},'archive':[],'events':[],'turn':0,'parents':[initial.copy() for _ in range(5)],'scores':[np.inf]*5,'initialized':[False]*5,'agents':[{'island':i,'role':role,'rng':np.random.default_rng(streams[i*8+j]),'proposals':0,'evaluations':0,'improvements':0,'gain':0.,'resolved':0,'unresolved':0,'cache_hits':0,'successful_new_solves':0,'failed_new_attempts':0,'changed_cells_total':0,'changed_parent_total':0,'action_counts':{}} for i in range(5) for j,role in enumerate(ROLES)],'resolved':0,'unresolved':0,'cache_hits':0,'successful_new_solves':0,'failed_new_attempts':0,'duplicates_skipped':0,'seconds':0.}
    start=time.perf_counter();base_seconds=st['seconds'];coords=np.array([divmod(int(i),13) for i in problem.active]);span=np.maximum(np.ptp(coords,axis=0),1);xy=(coords-coords.min(axis=0))/span
    def report():
        return {'method':method,'seed':seed,'budget':budget,'unique_candidates':st['calls'],'initial_sha256':identity['initial_sha256'],'initial_loss':st['events'][0]['loss'] if st['events'] else None,'best_loss':st['archive'][0][0] if st['archive'] else None,'best_labels':st['archive'][0][1].tolist() if st['archive'] else None,'resolved':st['resolved'],'unresolved':st['unresolved'],'cache_hits':st['cache_hits'],'successful_new_solves':st['successful_new_solves'],'failed_new_attempts':st['failed_new_attempts'],'duplicates_skipped':st['duplicates_skipped'],'seconds':st['seconds'],'events':st['events'],'agents':[{k:v for k,v in a.items() if k!='rng'} for a in st['agents']],'objective':'physical displacement loss; no supplied-solution or lookup input','islands':5,'agent_count':40,'island_losses':[v if np.isfinite(v) else None for v in st['scores']]}
    def save():
        st['seconds']=base_seconds+time.perf_counter()-start
        if path:
            path.parent.mkdir(parents=True,exist_ok=True);atomic_pickle(path,st);atomic_json(path.with_suffix('.json'),report())
    def evaluate(x,idx,parent,action=None,field_mode=None):
        key=tuple(map(int,x))
        if key in st['seen']:st['duplicates_skipped']+=1;return st['seen'][key],False
        record=getattr(problem,'records',{}).get(fingerprint(x)[:20]);cached=record is not None and record.get('tolerance',np.inf)<=getattr(problem,'tol',np.inf)
        before_solves=getattr(problem,'solves',None);value=problem.score(x);score=float(value) if value is not None else np.inf
        if not np.isfinite(score):score=np.inf
        after_solves=getattr(problem,'solves',None);resolved=bool(np.isfinite(score));before=st['archive'][0][0] if st['archive'] else np.inf
        if cached:category='cache_hits';count=1
        elif before_solves is not None and after_solves is not None and after_solves>before_solves:category='successful_new_solves';count=after_solves-before_solves
        elif not resolved:category='failed_new_attempts';count=1
        else:category='successful_new_solves';count=1
        st[category]+=count;st['resolved' if resolved else 'unresolved']+=1;st['calls']+=1;st['seen'][key]=score
        if resolved:st['archive'].append((score,x.copy()));st['archive'].sort(key=lambda z:z[0]);del st['archive'][64:]
        delta=int(np.count_nonzero(x!=initial));delta_parent=int(np.count_nonzero(x!=parent));gain=max(0,before-score) if np.isfinite(before) else 0.
        if idx is not None:
            a=st['agents'][idx];a['action_counts'][action or a['role']]=a['action_counts'].get(action or a['role'],0)+1;a['evaluations']+=1;a[category]+=count;a['resolved' if resolved else 'unresolved']+=1;a['improvements']+=int(score<before);a['gain']+=gain;a['changed_cells_total']+=delta;a['changed_parent_total']+=delta_parent
        st['events'].append({'evaluation':st['calls'],'agent':idx,'role':action if action is not None else (st['agents'][idx]['role'] if idx is not None else 'initial'),'declared_specialty':st['agents'][idx]['role'] if idx is not None else 'initial','island':st['agents'][idx]['island'] if idx is not None else None,'loss':score if resolved else None,'resolved':resolved,'cache_hit':bool(cached),'best_loss':st['archive'][0][0] if st['archive'] else None,'label_sha256':fingerprint(x),'changed_cells_from_initial':delta,'changed_cells_from_parent':delta_parent,'global_gain':gain,'field_mode':field_mode,'homogeneous_label':int(x[0]) if np.all(x==x[0]) else None})
        return score,True
    def commit(new):
        save()
        if new and on_progress:on_progress(st['events'][-1])
    if st['calls']==0:
        score,new=evaluate(initial,None,initial)
        if np.isfinite(score):st['scores']=[score]*5
        commit(new)
    if not st['archive']:raise ValueError('Initial physical evaluation unresolved; no finite incumbent')
    retries=0
    while st['calls']<budget:
        retries+=1
        if retries>100000:raise RuntimeError('Unique proposal space exhausted')
        idx=st['turn']%40;a=st['agents'][idx];rng=a['rng'];a['proposals']+=1;i=a['island'];role=a['role'];parent=st['parents'][i].copy();candidate=parent.copy();field_mode=None
        # Every broad specialist alternates one exploration proposal with two
        # sparse exploitation proposals; independent of total budget.
        if role!='coordinate_polish' and (a['proposals']-1)%3!=0:role='island_local_polish'
        if role=='island_local_polish':
            ids=rng.choice(n,size=min(n,int(rng.integers(1,4))),replace=False);candidate[ids]=(candidate[ids]+rng.integers(1,15,size=len(ids)))%15
        elif role=='uniform_global':candidate=rng.integers(15,size=n)
        elif role=='correlated_field':
            broad_index=(a['proposals']-1)//3
            if broad_index<3:
                field_mode='homogeneous';category=int(st['homogeneous_order'][(broad_index*5+i)%15]);candidate=np.full(n,category,dtype=int)
            else:
                mode=(broad_index-3)%3
                if mode==0:
                    field_mode='voronoi';centers=rng.random((int(rng.integers(1,9)),2));labels=rng.integers(15,size=len(centers));candidate=labels[np.argmin(np.sum((xy[:,None,:]-centers[None,:,:])**2,axis=2),axis=1)]
                elif mode==1:
                    field_mode='stripe';direction=rng.normal(size=2);field=xy@direction;field=(field-field.min())/max(np.ptp(field),1e-12);candidate=(np.floor(field*rng.integers(2,16)).astype(int)+rng.integers(15))%15
                else:
                    field_mode='block';candidate=rng.integers(15,size=(26,13))[coords[:,0]//2*2,coords[:,1]//2*2]
        elif role=='multiscale_mutation':
            fraction=float(rng.choice([1/n,.03,.1,.3,.7,1.]));ids=rng.choice(n,size=max(1,min(n,int(np.ceil(fraction*n)))),replace=False);candidate[ids]=(candidate[ids]+rng.integers(1,15,size=len(ids)))%15
        elif role=='categorical_learning':
            elite=np.array([x for _,x in st['archive'][:min(24,len(st['archive']))]])
            if len(elite):
                probabilities=np.array([(elite==k).mean(axis=0) for k in range(15)]).T;probabilities=.65*probabilities+.35/15
                candidate=np.array([rng.choice(15,p=row/row.sum()) for row in probabilities])
            else:candidate=rng.integers(15,size=n)
        elif role=='recombination':
            other=st['parents'][int(rng.integers(5))]
            if st['archive'] and rng.random()<.5:other=st['archive'][int(rng.integers(len(st['archive'])))][1]
            candidate=np.where(rng.random(n)<rng.uniform(.2,.8),parent,other);ids=rng.random(n)<.1;candidate[ids]=rng.integers(15,size=int(ids.sum()))
        elif role=='diversity_reset':
            # Broad categorical resets keep suboptimal but distinct island parents.
            candidate=rng.integers(15,size=n);ids=rng.random(n)<.2;candidate[ids]=parent[ids]
        elif role=='annealed_neighborhood':
            center=int(rng.integers(n));ids=np.argsort(np.sum((xy-xy[center])**2,axis=1),kind='stable')[:max(1,int(np.ceil(n*rng.uniform(.1,.8))))];candidate[ids]=(candidate[ids]+rng.integers(1,15,size=len(ids)))%15
        else:
            # Local polish probes the global incumbent but does not clone islands.
            if st['archive']:parent=st['archive'][0][1].copy();candidate=parent.copy()
            j=(a['proposals']-1+i)%n;candidate[j]=(candidate[j]+1+((a['proposals']-1)//n)%14)%15
        score,new=evaluate(candidate,idx,parent,role,field_mode)
        if np.isfinite(score):
            if not st['initialized'][i] or score<st['scores'][i]:accept=True
            elif role in ('uniform_global','diversity_reset'):accept=rng.random()<.35
            else:
                finite_initial=st['events'][0]['loss'];temperature=max(1e-8,.15*abs(finite_initial if finite_initial is not None else score))
                accept=role in ('annealed_neighborhood','correlated_field','recombination') and rng.random()<np.exp(min(0,(st['scores'][i]-score)/temperature))
            if accept:st['parents'][i]=candidate.copy();st['scores'][i]=score;st['initialized'][i]=True
        if new:st['turn']+=1;retries=0
        commit(new)
    save()
    if not st['archive']:raise ValueError('Every physical evaluation unresolved; no valid best label')
    return report(),st['archive'][0][1].copy()

def self_test():
    import tempfile
    class Tiny:
        initial=np.arange(20,dtype=int)%15;active=np.arange(20)
        def score(self,x):return None if np.sum(x)%13==0 and not np.array_equal(x,self.initial) else float(np.square(x-3).sum())
    for method in ('global_swarm','coordinate_descent'):
        for budget in (61,301):
            p=Tiny();full,x=optimize(p,method,budget,2,p.initial)
            with tempfile.TemporaryDirectory() as d:
                cp=Path(d)/'state.pkl'
                class Interrupted(Exception):pass
                def stop(e):
                    if e['evaluation']==27:raise Interrupted
                try:optimize(Tiny(),method,budget,2,p.initial,stop,cp)
                except Interrupted:pass
                resumed,y=optimize(Tiny(),method,budget,2,p.initial,checkpoint=cp)
                assert resumed['events']==full['events'] and np.array_equal(x,y)
            assert full['unique_candidates']==budget and full['resolved']+full['unresolved']==budget
            assert len({e['label_sha256'] for e in full['events']})==budget
            if method=='global_swarm':
                assert len(full['agents'])==40 and all(a['evaluations'] for a in full['agents'])
                broad=[e for e in full['events'] if e['role'] in ('uniform_global','diversity_reset')]
                assert broad and all(e['changed_cells_from_initial']>len(p.initial)/2 for e in broad)
                assert full['unresolved']>0
                local=[e for e in full['events'] if e['role']=='island_local_polish']
                if budget==301:
                    assert local and all(1<=e['changed_cells_from_parent']<=3 for e in local)
                    homogeneous=[e for e in full['events'] if e['field_mode']=='homogeneous'];assert len(homogeneous)==15 and {e['homogeneous_label'] for e in homogeneous}==set(range(15))
                coordinate=[e for e in full['events'] if e['role']=='coordinate_polish'];assert all(e['changed_cells_from_parent']==1 for e in coordinate)
    for seed in (0,1,2):
        report,_=optimize(Tiny(),'global_swarm',61,seed,Tiny.initial)
        assert report['unique_candidates']==61
    with tempfile.TemporaryDirectory() as d:
        cp=Path(d)/'extension.pkl'
        optimize(Tiny(),'global_swarm',61,3,Tiny.initial,checkpoint=cp)
        extended,x=optimize(Tiny(),'global_swarm',301,3,Tiny.initial,checkpoint=cp)
        direct,y=optimize(Tiny(),'global_swarm',301,3,Tiny.initial)
        assert extended['events']==direct['events'] and np.array_equal(x,y)
    high,_=optimize(Tiny(),'global_swarm',901,4,Tiny.initial)
    assert {'homogeneous','voronoi','stripe','block'}<={e['field_mode'] for e in high['events'] if e['role']=='correlated_field'}
    print('PASS: both methods61/301, exact resume and budget extension, three seeds, unresolved accounting, 40 agents, broad global proposals')
if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--self-test',action='store_true');args=ap.parse_args()
    if args.self_test:self_test()
    else:ap.error('Use optimize() from campaign runner or --self-test')
