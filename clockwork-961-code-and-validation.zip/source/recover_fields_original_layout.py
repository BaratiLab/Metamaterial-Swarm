"""Strict evaluation of three fixed recorded endpoints; no optimizer is imported."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
os.environ['MKL_NUM_THREADS']='1'
from pathlib import Path
import sys,json,hashlib,gc
import numpy as np
from scipy.io import loadmat
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
bundle=ROOT/'outputs/clockwork_global_to961'
campaign=bundle/'global_results/campaign'
sys.path.insert(0,str(bundle))
from swarm import Problem,mat
from physical import PixelSolver,element
from fem import relative_loss
from scaled_search import fingerprint
validation=json.loads((campaign/'validation/validation.json').read_text())
problem=Problem(campaign/'inputs/data')
target=mat(campaign/'inputs/data/UOrigin.mat','UOrigin')
interest=mat(campaign/'inputs/data/Interest.mat','Interest')
nu=.35
D=np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]])/(1-nu**2)
def B(xi,eta):
    dn=np.array([[-(1-eta),1-eta,1+eta,-(1+eta)],[-(1-xi),-(1+xi),1+xi,1-xi]])/2
    b=np.zeros((3,8));b[0,::2]=dn[0];b[1,1::2]=dn[1];b[2,::2]=dn[1];b[2,1::2]=dn[0]
    return b
quad=sum(B(x,y).T@D@B(x,y)*.25 for x in [-1/np.sqrt(3),1/np.sqrt(3)] for y in [-1/np.sqrt(3),1/np.sqrt(3)])
err=float(np.max(abs(quad-element())));assert err<1e-14
# Affine displacement patch: physical y increases upward while image rows increase downward.
coords=np.array([[0,-1],[1,-1],[1,0],[0,0]])
ue=np.c_[.001*coords[:,0]+.002*coords[:,1],.003*coords[:,0]-.0005*coords[:,1]].ravel()
patch=float(np.max(abs(D@B(0,0)@ue-D@np.array([.001,-.0005,.005]))));assert patch<1e-15
report={'complete':False,'optimization_calls':0,'fixed_designs':3,'strict_tolerance':1e-10,'stiffness_quadrature_error':err,'affine_patch_error':patch,'cases':[],
 'conventions':{'coordinates':'physical x right and y up; stored rows increase down','displacement':'original model displacement units; not calibrated mm','stress':'solid Q4 element-center stress divided by applied nominal traction; legacy stiffness scaling cancels','void':'masked; eliminated void-only nodal zero placeholders are not recovered displacement','local_maxima':'not mesh-converged stress estimates'}}
nominal=50*(50*50)**2/(1500*(7e6**2)*.01)
for seed in range(3):
    labelpath=campaign/'validation/labels'/f'global_swarm_seed{seed}_final.mat'
    labels=loadmat(labelpath)['Label'];x=labels.ravel()[problem.active]
    original=validation['records'][f'global_swarm_seed{seed}_final']
    assert fingerprint(x)==original['label_sha256'] and original['passed']
    phi=problem.assemble(x);path=OUT/'fields'/f'swarm_seed{seed}.npz'
    if path.exists():
        saved=np.load(path);u=saved['u'];stats=json.loads(str(saved['solver_stats']))
    else:
        u,stats=PixelSolver(tol=1e-10).solve(phi)
    loss=float(relative_loss(u,target,interest));assert abs(loss-original['strict_loss'])<1e-8
    assert stats['cg_info']==0 and stats['relative_residual']<=1.1e-10
    U=u.reshape(1501,1501,2).transpose(1,0,2)
    # Source Q4 node order: lower-left, lower-right, upper-right, upper-left.
    corners=[U[1:,:-1],U[1:,1:],U[:-1,1:],U[:-1,:-1]]
    center=sum(corners)/4
    strain=np.zeros((1500,1500,3))
    for j,c in enumerate(corners):
        strain+=np.einsum('ij,xyj->xyi',B(0,0)[:,2*j:2*j+2],c)
    stress=np.einsum('ij,xyj->xyi',D,strain)/nominal
    sx,sy,txy=np.moveaxis(stress,-1,0)
    vm=np.sqrt(np.maximum(sx*sx-sx*sy+sy*sy+3*txy*txy,0))
    avg=(sx+sy)/2;rad=np.sqrt(((sx-sy)/2)**2+txy*txy)
    solid=phi>0
    entry={'seed':seed,'label_sha256':fingerprint(x),'strict_loss':loss,'original_strict_loss':original['strict_loss'],'loss_difference':abs(loss-original['strict_loss']),'solver':stats,'solid_pixel_count':int(solid.sum()),'unclipped_extrema':{}}
    arrays={'ux':center[:,:,0],'uy':center[:,:,1],'umag':np.linalg.norm(center,axis=2),'sigma_xx':sx,'sigma_yy':sy,'tau_xy':txy,'von_mises':vm,'principal_max':avg+rad,'principal_min':avg-rad}
    for name,a in arrays.items():entry['unclipped_extrema'][name]={'min':float(a[solid].min()),'max':float(a[solid].max())}
    np.savez_compressed(path,u=u,labels=labels,solid=solid,solver_stats=json.dumps(stats),**{k:a.astype(np.float32) for k,a in arrays.items()})
    report['cases'].append(entry);(OUT/'validation.json').write_text(json.dumps(report,indent=2));print('RECOVERED',seed,loss,flush=True)
    del u,U,phi,stress,strain,corners,center,arrays,sx,sy,txy,vm,avg,rad;gc.collect()
report['complete']=True
(OUT/'validation.json').write_text(json.dumps(report,indent=2))
