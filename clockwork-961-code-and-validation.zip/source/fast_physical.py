"""Optional stateful full-pixel solver with projected SPD AMG reuse and warm starts.
Physics and convergence tolerance match physical.PixelSolver. Reuse affects only
preconditioning; every candidate assembles its own exact solid stiffness and RHS.
Falls back to a fresh AMG hierarchy if reused preconditioning fails to converge.
Warm-only full-size validation matched prior loss within 7e-12 on a neighbor.
Projected reuse was slower on that neighbor; the campaign uses fresh AMG each solve.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import numpy as np,time,json,resource,sys,gc
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import cg,LinearOperator
from scipy.sparse.csgraph import connected_components
from physical import element,void_load_transfer

class PixelSolver:
    def __init__(self,tol=1e-8,maxiter=1500,reuse_maxiter=120,max_changed_fraction=.02,refresh_every=12):
        self.tol=tol;self.maxiter=maxiter;self.reuse_maxiter=reuse_maxiter
        self.max_changed_fraction=max_changed_fraction;self.refresh_every=refresh_every
        self._pre=None;self._last=None;self._reuse_age=0
    def reset(self):
        self._pre=None;self._last=None;self._reuse_age=0
    def solve(self,phi,half=True,rhs_correction=None,save=None):
        import pyamg
        start=time.perf_counter();ny,fullnx=phi.shape;nx=fullnx//2 if half else fullnx
        if half and not np.array_equal(phi,phi[:,::-1]):raise ValueError('Half solver requires mirror-symmetric pixels')
        solid=np.asarray(phi[:,:nx]>0);ys,xs=np.nonzero(solid)
        # Source element DOF sequence: (x,y+1),(x+1,y+1),(x+1,y),(x,y).
        nodes=(xs*(ny+1)+ys).astype(np.int32)
        corners=nodes[:,None]+np.array([1,ny+2,ny+1,0],np.int32)
        used=np.unique(corners);node_map=np.full((nx+1)*(ny+1),-1,np.int32);node_map[used]=np.arange(len(used),dtype=np.int32)
        cn=node_map[corners];ed=np.empty((len(cn),8),np.int32);ed[:,::2]=cn*2;ed[:,1::2]=cn*2+1
        del corners,nodes,cn
        ke=element();nd=2*len(used)
        # 32-bit triplets; only solid elements, no 144-million-entry full-domain assembly.
        ii=np.repeat(ed,8,axis=1).ravel();jj=np.tile(ed,(1,8)).ravel();vv=np.tile(ke.ravel(),len(ed))
        k=coo_matrix((vv,(ii,jj)),shape=(nd,nd)).tocsr();k.eliminate_zeros()
        del ii,jj,vv,ed
        yy=used%(ny+1);xx=used//(ny+1)
        # Check solid connectivity at shared nodes (includes point contacts, as Q4 FEM does).
        graph=k[::2,::2].copy();graph.data[:]=1
        ncomp,components=connected_components(graph,directed=False);del graph
        fixed=[]
        if half:fixed.extend((2*np.flatnonzero(xx==nx)).tolist())
        else:
            fixed.extend((2*np.flatnonzero(xx==nx//2)).tolist())
        for x in ([0,nx] if not half else [0,nx]):
            hit=np.flatnonzero((xx==x)&(yy==ny//2));fixed.extend((2*hit+1).tolist())
        if not half:
            hit=np.flatnonzero((xx==nx//2)&(yy==ny//2));fixed.extend((2*hit+1).tolist())
        fixed=np.unique(fixed).astype(np.int32)
        constrained_components=np.unique(components[fixed//2]);
        if len(constrained_components)!=ncomp:raise ValueError(f'{ncomp} components with unanchored solid islands')
        for component_id in range(ncomp):
            fd=fixed[components[fixed//2]==component_id]
            constraint=np.zeros((len(fd),3));constraint[:,0]=(fd%2==0);constraint[:,1]=(fd%2==1)
            constraint[:,2]=np.where(fd%2==0,-(yy[fd//2]-ny/2),(xx[fd//2]-nx/2))/max(ny,nx)
            if np.linalg.matrix_rank(constraint)<3:raise ValueError('Solid component has unconstrained rigid motions; zero-void limit unresolved')
        f=np.zeros(nd);left=np.flatnonzero(xx==0)
        f[2*left]=50*(50*50)**2/ny/(7e6**2*.01)
        f[2*left[(yy[left]==0)|(yy[left]==ny)]]*=.5
        if not half:
            right=np.flatnonzero(xx==nx);f[2*right]=-50*(50*50)**2/ny/(7e6**2*.01);f[2*right[(yy[right]==0)|(yy[right]==ny)]]*=.5
        # All original boundary load nodes must belong to solid; no silently discarded forces.
        transfer,transfer_stats=void_load_transfer(solid,used,node_map,half);f+=transfer
        print(json.dumps({'stage':'void_transfer',**transfer_stats}),flush=True)
        free=np.setdiff1d(np.arange(nd,dtype=np.int32),fixed);a=k[free][:,free];del k
        rhs=f[free];del f
        if rhs_correction is not None:
            correction=np.asarray(rhs_correction)
            if correction.shape!=rhs.shape:raise ValueError('Condensed correction DOF ordering/shape mismatch')
            rhs=rhs-correction
        B=np.zeros((nd,3));B[::2,0]=1;B[1::2,1]=1;B[::2,2]=-(yy-ny/2)/max(ny,nx);B[1::2,2]=(xx-nx/2)/max(ny,nx)
        B=B[free];setup=time.perf_counter()
        domain_key=(ny,fullnx,bool(half))
        global_free=(2*used[free//2]+free%2).astype(np.int32)
        x0=None;warm_shared=0
        if self._last is not None and self._last[0]==domain_key:
            _,last_global,last_u=self._last
            _,new_ix,old_ix=np.intersect1d(global_free,last_global,assume_unique=True,return_indices=True)
            x0=np.zeros(len(free));x0[new_ix]=last_u[old_ix];warm_shared=len(new_ix)
            # Nearest-neighbor interpolation only seeds newly appearing DOFs.
            missing=np.setdiff1d(np.arange(len(free)),new_ix,assume_unique=True)
            if len(missing):
                from scipy.spatial import cKDTree
                for component in [0,1]:
                    old=np.flatnonzero(last_global%2==component);new=missing[global_free[missing]%2==component]
                    if len(new) and len(old):
                        on=last_global[old]//2;nn=global_free[new]//2
                        tree=cKDTree(np.column_stack((on//(ny+1),on%(ny+1))))
                        _,nearest=tree.query(np.column_stack((nn//(ny+1),nn%(ny+1))))
                        x0[new]=last_u[old[nearest]]
        reused=False;pre_overlap=0.;fallback=False
        ml=pre=old_pre=apply_pre=None
        def fresh():
            ml=pyamg.smoothed_aggregation_solver(a,B=B,symmetry='symmetric',strength=('symmetric',{'theta':0.0}),max_coarse=300,improve_candidates=[('block_gauss_seidel',{'sweep':'symmetric','iterations':2}),None],smooth=('energy',{'degree':2}),presmoother=('gauss_seidel',{'sweep':'symmetric'}),postsmoother=('gauss_seidel',{'sweep':'symmetric'}))
            self._pre=(domain_key,global_free.copy(),ml);self._reuse_age=0
            return ml,ml.aspreconditioner()
        if self._pre is not None and self._pre[0]==domain_key and self._reuse_age<self.refresh_every:
            _,old_global,ml=self._pre
            _,new_ix,old_ix=np.intersect1d(global_free,old_global,assume_unique=True,return_indices=True)
            pre_overlap=min(len(new_ix)/len(global_free),len(old_ix)/len(old_global))
            if pre_overlap>=1-self.max_changed_fraction:
                old_pre=ml.aspreconditioner();new_only=np.setdiff1d(np.arange(len(free)),new_ix,assume_unique=True)
                diagonal=a.diagonal();old_n=len(old_global)
                # P.T M_old P plus positive Jacobi on new-only DOFs is SPD.
                def apply_pre(r):
                    old_r=np.zeros(old_n);old_r[old_ix]=r[new_ix]
                    old_z=old_pre@old_r;z=np.zeros(len(free));z[new_ix]=old_z[old_ix]
                    z[new_only]=r[new_only]/diagonal[new_only]
                    return z
                pre=LinearOperator(a.shape,matvec=apply_pre,rmatvec=apply_pre,dtype=float)
                reused=True;self._reuse_age+=1
            else:
                # Release every hierarchy/operator/closure reference before rebuilding.
                ml=pre=old_pre=apply_pre=None;self._pre=None;gc.collect()
                ml,pre=fresh()
        else:
            ml=pre=old_pre=apply_pre=None;self._pre=None;gc.collect()
            ml,pre=fresh()
        build=time.perf_counter();residuals=[];count=[0]
        def callback(x):
            count[0]+=1
            if count[0]%20==0:
                residuals.append([count[0],float(np.linalg.norm(rhs-a@x)/np.linalg.norm(rhs))])
                print(json.dumps({'iteration':count[0],'relative_residual':residuals[-1][1],'elapsed':time.perf_counter()-start,'reused_amg':reused}),flush=True)
        import inspect
        tol_kw={'rtol':self.tol} if 'rtol' in inspect.signature(cg).parameters else {'tol':self.tol}
        solution,info=cg(a,rhs,x0=x0,M=pre,atol=0,maxiter=min(self.maxiter,self.reuse_maxiter) if reused else self.maxiter,callback=callback,**tol_kw)
        current_residual=float(np.linalg.norm(rhs-a@solution)/np.linalg.norm(rhs))
        if reused and (info!=0 or not np.isfinite(current_residual) or current_residual>self.tol*1.1):
            fallback=True;refresh_start=time.perf_counter()
            # LinearOperator retains apply_pre, which retains old_pre: clear all
            # links as well as the state cache before allocating another AMG.
            ml=pre=old_pre=apply_pre=None;self._pre=None;gc.collect()
            ml,pre=fresh();build+=time.perf_counter()-refresh_start
            solution,info=cg(a,rhs,x0=solution if np.isfinite(solution).all() else x0,M=pre,atol=0,maxiter=self.maxiter,callback=callback,**tol_kw)
        residual=float(np.linalg.norm(rhs-a@solution)/np.linalg.norm(rhs));u=np.zeros(nd);u[free]=solution
        stats={'shape':[ny,fullnx],'half':half,'solid_elements':len(ys),'retained_nodes':len(used),'free_dofs':len(free),'components':int(ncomp),'reused_amg':reused,'preconditioner_overlap':pre_overlap,'warm_start_shared_dofs':warm_shared,'fresh_amg_fallback':fallback,'iterations':count[0],'cg_info':int(info),'relative_residual':residual,'assembly_seconds':setup-start,'amg_seconds':build-setup,'total_seconds':time.perf_counter()-start,'operator_complexity':float(ml.operator_complexity()),'tolerance':self.tol,'finite_void_first_order_correction':rhs_correction is not None,'peak_process_rss_bytes':int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024)),**transfer_stats}
        print(json.dumps(stats),flush=True)
        if info!=0 or not np.isfinite(residual) or residual>self.tol*1.1:raise RuntimeError(f'Unconverged physical solve: {stats}')
        self._last=(domain_key,global_free.copy(),solution.copy())
        full=np.zeros((ny+1,fullnx+1,2));half_u=np.zeros(((nx+1)*(ny+1),2));half_u[used]=u.reshape(-1,2);half_u=half_u.reshape((nx+1,ny+1,2)).transpose(1,0,2)
        full[:,:nx+1]=half_u
        if half:
            full[:,nx+1:]=half_u[:,:nx][:,::-1];full[:,nx+1:,0]*=-1
        result=full.transpose(1,0,2).reshape(-1)
        if save:np.savez_compressed(save,u=result,stats=json.dumps(stats))
        if self.refresh_every==0:
            # Warm-only mode retains vectors, never an old hierarchy during the
            # next candidate's large stiffness assembly.
            self._pre=None;ml=pre=old_pre=apply_pre=None;gc.collect()
        return result,stats
