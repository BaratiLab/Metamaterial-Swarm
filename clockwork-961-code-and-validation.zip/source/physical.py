"""Full pixel-resolution zero-void elasticity with half-domain symmetry and AMG.
Preserves the original solid stiffness/load scale; inactive void DOFs eliminated.
This is the zero-void limit, not a claim of literal finite-Emin MATLAB parity.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import numpy as np,time,json,resource,sys
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import cg,spsolve
from scipy.sparse.csgraph import connected_components
from scipy.ndimage import label as region_label

def element():
    a=np.array([[12,3,-6,-3],[3,12,3,0],[-6,3,12,-3],[-3,0,-3,12]])
    b=np.array([[-6,-3,0,3],[-3,-6,-3,-6],[0,-3,-6,3],[3,-6,3,-6]])
    c=np.array([[-4,3,-2,9],[3,-4,-9,4],[-2,-9,-4,-3],[9,4,-3,-4]])
    d=np.array([[2,-3,4,-9],[-3,2,9,-2],[4,9,2,3],[-9,-2,3,2]])
    return (np.block([[a,b],[b.T,a]])+.35*np.block([[c,d],[d.T,c]]))/(24*(1-.35**2))

def void_load_transfer(solid,used,node_map,half=True):
    """Leading-order exact condensation of loads on void-only nodes.
    K=Ks+eps*Kv. For void-only v: w=eps*u_v -> Kv_vv*w=f_v.
    Retained RHS is f_s-Kv_sv*w, NOT simply f_s. Unloaded components have w=0.
    """
    ny,nx=solid.shape;nn=(ny+1)*(nx+1)
    present=np.zeros(nn,bool);present[used]=True
    inactive=(~present).reshape((nx+1,ny+1)).T
    regions,nregions=region_label(inactive,np.ones((3,3)))
    chosen=np.unique(regions[:,0]);chosen=chosen[chosen>0]
    if not half:
        chosen=np.unique(np.r_[chosen,regions[:,-1]]);chosen=chosen[chosen>0]
    selected=np.isin(regions,chosen)&inactive
    affected=selected[:-1,:-1]|selected[1:,:-1]|selected[:-1,1:]|selected[1:,1:]
    ys,xs=np.nonzero(affected&~solid)
    corners=(xs*(ny+1)+ys)[:,None]+np.array([1,ny+2,ny+1,0])
    localnodes=np.unique(corners);lm=np.full(nn,-1,np.int32);lm[localnodes]=np.arange(len(localnodes),dtype=np.int32)
    cn=lm[corners];ed=np.empty((len(cn),8),np.int32);ed[:,::2]=2*cn;ed[:,1::2]=2*cn+1
    vv=np.tile(element().ravel(),len(ed));ii=np.repeat(ed,8,axis=1).ravel();jj=np.tile(ed,(1,8)).ravel()
    kv=coo_matrix((vv,(ii,jj)),shape=(2*len(localnodes),2*len(localnodes))).tocsr()
    yy=localnodes%(ny+1);xx=localnodes//(ny+1)
    voidnodes=selected.T.ravel()[localnodes]
    vdofs=np.flatnonzero(np.repeat(voidnodes,2))
    fixed=[]
    if half:fixed.extend((2*np.flatnonzero(xx==nx)).tolist())
    else:fixed.extend((2*np.flatnonzero(xx==nx//2)).tolist())
    for x in ([0,nx] if half else [0,nx//2,nx]):
        fixed.extend((2*np.flatnonzero((xx==x)&(yy==ny//2))+1).tolist())
    vdofs=np.setdiff1d(vdofs,np.array(fixed,dtype=int))
    f=np.zeros(2*len(localnodes));left=np.flatnonzero(xx==0);scale=50*(50*50)**2/ny/(7e6**2*.01)
    f[2*left]=scale;f[2*left[(yy[left]==0)|(yy[left]==ny)]]*=.5
    if not half:
        right=np.flatnonzero(xx==nx);f[2*right]=-scale;f[2*right[(yy[right]==0)|(yy[right]==ny)]]*=.5
    if len(vdofs):
        a=kv[vdofs][:,vdofs];w=spsolve(a,f[vdofs])
        error=float(np.linalg.norm(a@w-f[vdofs])/np.linalg.norm(f[vdofs]))
        reaction=kv[:,vdofs]@w
    else:reaction=np.zeros_like(f);error=0.
    good=present[localnodes];idx=node_map[localnodes[good]]
    adjusted=np.zeros(2*len(used));adjusted[2*idx]=-reaction[2*np.flatnonzero(good)];adjusted[2*idx+1]=-reaction[2*np.flatnonzero(good)+1]
    return adjusted,{'void_components_loaded':int(len(chosen)),'void_load_dofs':int(len(vdofs)),'void_transfer_residual':error,'void_elements_condensed':len(ys)}

class PixelSolver:
    def __init__(self,tol=1e-8,maxiter=1500):self.tol=tol;self.maxiter=maxiter
    def solve(self,phi,half=True,rhs_correction=None,save=None):
        import pyamg
        start=time.perf_counter();ny,fullnx=phi.shape;nx=fullnx//2 if half else fullnx
        if half and not np.array_equal(phi,phi[:,::-1]):raise ValueError('Half solver requires mirror-symmetric pixels')
        solid=np.asarray(phi[:,:nx]>0);ys,xs=np.nonzero(solid)
        # Source element DOF sequence: (x,y+1),(x+1,y+1),(x+1,y),(x,y).
        nodes=(xs*(ny+1)+ys).astype(np.int32)
        corners=nodes[:,None]+np.array([1,ny+2,ny+1,0],np.int32)
        used=np.unique(corners);node_map=np.full((nx+1)*(ny+1),-1,np.int32);node_map[used]=np.arange(len(used),dtype=np.int32)
        cn=node_map[corners];ed=np.empty((len(cn),8),np.int32);ed[:,::2]=cn*2;ed[:,1::2]=cn*2+1
        del corners,nodes,cn
        ke=element();nd=2*len(used)
        # 32-bit triplets; only solid elements, no 144-million-entry full-domain assembly.
        ii=np.repeat(ed,8,axis=1).ravel();jj=np.tile(ed,(1,8)).ravel();vv=np.tile(ke.ravel(),len(ed))
        k=coo_matrix((vv,(ii,jj)),shape=(nd,nd)).tocsr();k.eliminate_zeros()
        del ii,jj,vv,ed
        yy=used%(ny+1);xx=used//(ny+1)
        # Check solid connectivity at shared nodes (includes point contacts, as Q4 FEM does).
        graph=k[::2,::2].copy();graph.data[:]=1
        ncomp,components=connected_components(graph,directed=False);del graph
        fixed=[]
        if half:fixed.extend((2*np.flatnonzero(xx==nx)).tolist())
        else:
            fixed.extend((2*np.flatnonzero(xx==nx//2)).tolist())
        for x in ([0,nx] if not half else [0,nx]):
            hit=np.flatnonzero((xx==x)&(yy==ny//2));fixed.extend((2*hit+1).tolist())
        if not half:
            hit=np.flatnonzero((xx==nx//2)&(yy==ny//2));fixed.extend((2*hit+1).tolist())
        fixed=np.unique(fixed).astype(np.int32)
        constrained_components=np.unique(components[fixed//2]);
        if len(constrained_components)!=ncomp:raise ValueError(f'{ncomp} components with unanchored solid islands')
        for component_id in range(ncomp):
            fd=fixed[components[fixed//2]==component_id]
            constraint=np.zeros((len(fd),3));constraint[:,0]=(fd%2==0);constraint[:,1]=(fd%2==1)
            constraint[:,2]=np.where(fd%2==0,-(yy[fd//2]-ny/2),(xx[fd//2]-nx/2))/max(ny,nx)
            if np.linalg.matrix_rank(constraint)<3:raise ValueError('Solid component has unconstrained rigid motions; zero-void limit unresolved')
        f=np.zeros(nd);left=np.flatnonzero(xx==0)
        f[2*left]=50*(50*50)**2/ny/(7e6**2*.01)
        f[2*left[(yy[left]==0)|(yy[left]==ny)]]*=.5
        if not half:
            right=np.flatnonzero(xx==nx);f[2*right]=-50*(50*50)**2/ny/(7e6**2*.01);f[2*right[(yy[right]==0)|(yy[right]==ny)]]*=.5
        # All original boundary load nodes must belong to solid; no silently discarded forces.
        transfer,transfer_stats=void_load_transfer(solid,used,node_map,half);f+=transfer
        print(json.dumps({'stage':'void_transfer',**transfer_stats}),flush=True)
        free=np.setdiff1d(np.arange(nd,dtype=np.int32),fixed);a=k[free][:,free];del k
        rhs=f[free];del f
        if rhs_correction is not None:
            correction=np.asarray(rhs_correction)
            if correction.shape!=rhs.shape:raise ValueError('Condensed correction DOF ordering/shape mismatch')
            rhs=rhs-correction
        B=np.zeros((nd,3));B[::2,0]=1;B[1::2,1]=1;B[::2,2]=-(yy-ny/2)/max(ny,nx);B[1::2,2]=(xx-nx/2)/max(ny,nx)
        B=B[free];setup=time.perf_counter()
        ml=pyamg.smoothed_aggregation_solver(a,B=B,symmetry='symmetric',strength=('symmetric',{'theta':0.0}),max_coarse=300,improve_candidates=[('block_gauss_seidel',{'sweep':'symmetric','iterations':2}),None],smooth=('energy',{'degree':2}),presmoother=('gauss_seidel',{'sweep':'symmetric'}),postsmoother=('gauss_seidel',{'sweep':'symmetric'}))
        build=time.perf_counter();residuals=[];count=[0]
        def callback(x):
            count[0]+=1
            if count[0]%20==0:
                residuals.append([count[0],float(np.linalg.norm(rhs-a@x)/np.linalg.norm(rhs))])
                print(json.dumps({'iteration':count[0],'relative_residual':residuals[-1][1],'elapsed':time.perf_counter()-start}),flush=True)
        import inspect
        tol_kw={'rtol':self.tol} if 'rtol' in inspect.signature(cg).parameters else {'tol':self.tol}
        solution,info=cg(a,rhs,M=ml.aspreconditioner(),atol=0,maxiter=self.maxiter,callback=callback,**tol_kw)
        residual=float(np.linalg.norm(rhs-a@solution)/np.linalg.norm(rhs));u=np.zeros(nd);u[free]=solution
        stats={'shape':[ny,fullnx],'half':half,'solid_elements':len(ys),'retained_nodes':len(used),'free_dofs':len(free),'components':int(ncomp),'iterations':count[0],'cg_info':int(info),'relative_residual':residual,'assembly_seconds':setup-start,'amg_seconds':build-setup,'total_seconds':time.perf_counter()-start,'operator_complexity':float(ml.operator_complexity()),'tolerance':self.tol,'finite_void_first_order_correction':rhs_correction is not None,'peak_process_rss_bytes':int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024)),**transfer_stats}
        print(json.dumps(stats),flush=True)
        if info!=0 or not np.isfinite(residual) or residual>self.tol*1.1:raise RuntimeError(f'Unconverged physical solve: {stats}')
        full=np.zeros((ny+1,fullnx+1,2));half_u=np.zeros(((nx+1)*(ny+1),2));half_u[used]=u.reshape(-1,2);half_u=half_u.reshape((nx+1,ny+1,2)).transpose(1,0,2)
        full[:,:nx+1]=half_u
        if half:
            full[:,nx+1:]=half_u[:,:nx][:,::-1];full[:,nx+1:,0]*=-1
        result=full.transpose(1,0,2).reshape(-1)
        if save:np.savez_compressed(save,u=result,stats=json.dumps(stats))
        return result,stats
