"""Loss-blind random valid starts in an isolated, solution-free data bundle."""
from pathlib import Path
import hashlib,json,shutil
import numpy as np
from scipy.io import savemat
from swarm import Problem,mat
from audit_geometry import audit
from scaled_search import atomic_json,fingerprint

PHYSICAL_INPUTS=('Indicator.mat','PhiIndex.mat','OriginCell.mat','ShapeSpace.mat','UOrigin.mat','Interest.mat')
def prepare(source,out,seeds):
    source=Path(source);out=Path(out);data=out/'inputs/data';data.mkdir(parents=True,exist_ok=True)
    # Legacy Problem expects these two files. Neither supplied file is read:
    # inactive label entries never select geometry, and lookup costs are unused.
    for name in PHYSICAL_INPUTS:
        dest=data/name
        if not dest.exists():shutil.copyfile(source/name,dest)
        if hashlib.sha256(dest.read_bytes()).digest()!=hashlib.sha256((source/name).read_bytes()).digest():raise ValueError('Physical input changed')
    template=data.parent/'Label_opt.mat';cost=data/'Uenergy.mat'
    if not template.exists():savemat(template,{'Label':np.zeros((26,13),dtype=np.int64)})
    if not cost.exists():savemat(cost,{'Uenergy':np.zeros((338,15))})
    if np.any(mat(template,'Label')) or np.any(mat(cost,'Uenergy')):raise ValueError('Neutral compatibility inputs changed')
    p=Problem(data);starts=out/'starts';starts.mkdir(exist_ok=True)
    spec={'seeds':list(seeds),'distribution':'independent uniform integer labels 0..14 at all active cells, conditioned only on independent geometry certificate','rng':'numpy PCG64 via SeedSequence([20261020, seed, 9317])','physical_loss_screening':False,'supplied_solution_read':False,'lookup_cost_read':'synthetic zero compatibility array only','active_cells':len(p.active),'physical_inputs':{name:hashlib.sha256((data/name).read_bytes()).hexdigest() for name in PHYSICAL_INPUTS}}
    spec_path=starts/'spec.json'
    if spec_path.exists() and json.loads(spec_path.read_text())!=spec:raise ValueError('Random-start specification changed')
    atomic_json(spec_path,spec)
    for seed in seeds:
        record_path=starts/f'seed{seed}.json';label=starts/f'seed{seed}.mat'
        if record_path.exists():
            r=json.loads(record_path.read_text());x=mat(label,'Label').astype(int).ravel()[p.active]
            if fingerprint(x)!=r['initial_sha256']:raise ValueError('Frozen random start changed')
            continue
        rng=np.random.default_rng(np.random.SeedSequence([20261020,seed,9317]));rejections=[]
        for attempt in range(1,10001):
            x=rng.integers(15,size=len(p.active));savemat(label,{'Label':p.labels(x)})
            certificate=audit(data,label)
            if certificate['solid_stiffness_positive_definiteness_certified']:
                atomic_json(record_path,{'seed':seed,'attempts':attempt,'initial_sha256':fingerprint(x),'labels':x.tolist(),'rejections':rejections,'geometry':certificate,'selection':'first geometry-certified draw; no physical score evaluated'})
                print(json.dumps({'event':'random_start_ready','seed':seed,'draws':attempt,'hash':fingerprint(x)}),flush=True);break
            rejections.append({'draw':attempt,'label_sha256':fingerprint(x),'edge_components':certificate['edge_connected_components'],'node_components':certificate['node_connected_components']})
        else:raise RuntimeError('No geometry-certified random draw within limit')
    return data
