"""Exact post-search source-Q4 rigidity certificate for edge parts joined at nodes.
This changes verification only; it never screens or guides optimizer proposals.
"""
from pathlib import Path
import hashlib
import numpy as np
from scipy.ndimage import label
from swarm import Problem,mat
from scaled_search import fingerprint
from verify_rigidity_supplement import exact_rank,element_certificate

def certify(data,label_file):
    p=Problem(data);a=mat(label_file,'Label').astype(int);x=a.ravel()[p.active];full=p.assemble(x)
    assert np.array_equal(full,full[:,::-1]);ny,fnx=full.shape;nx=fnx//2;parts,n=label(full[:,:nx].astype(bool))
    if not 1<=n<=32:return {'passed':False,'reason':'Edge-part count outside exact review limit','edge_parts':n}
    nodes=[];sizes=[]
    for k in range(1,n+1):
        y,xx=np.nonzero(parts==k);v=xx*(ny+1)+y;sizes.append(int(len(v)));nodes.append(np.unique(np.concatenate([v,v+1,v+ny+1,v+ny+2])))
    rows=[];contacts=[]
    for i in range(n):
        for j in range(i+1,n):
            shared=np.intersect1d(nodes[i],nodes[j]);xy=[]
            for v in shared:
                xx,y=int(v//(ny+1)),int(v%(ny+1));xy.append([xx,y]);ux=[0]*(3*n);uy=ux.copy();ux[3*i]=1;ux[3*i+2]=y;ux[3*j]=-1;ux[3*j+2]=-y;uy[3*i+1]=1;uy[3*i+2]=xx;uy[3*j+1]=-1;uy[3*j+2]=-xx;rows.extend([ux,uy])
            if xy:contacts.append({'parts':[i+1,j+1],'shared_nodes_xy':xy})
    for i,used in enumerate(nodes):
        xx=used//(ny+1);y=used%(ny+1)
        for yy in y[xx==nx]:
            row=[0]*(3*n);row[3*i]=1;row[3*i+2]=int(yy);rows.append(row)
        for xxx in xx[(y==ny//2)&((xx==0)|(xx==nx))]:
            row=[0]*(3*n);row[3*i+1]=1;row[3*i+2]=int(xxx);rows.append(row)
    rank,witness=exact_rank(rows,3*n);ke=element_certificate()
    return {'passed':rank==3*n,'label_sha256':fingerprint(x),'edge_parts':n,'part_element_counts':sizes,'contacts':contacts,'rigid_parameters':3*n,'exact_constraint_rank':rank,'independent_integer_constraint_rows':witness,'element_certificate':ke,'certificate_code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Discrete source-Q4 positive definiteness only. Exact nonnegative element LDL with rank5 and three verified null modes, plus full-rank coupled-body/support constraints, remove all free zero-energy modes. Not a continuum manufacturability or finite-Emin error certificate.'}
