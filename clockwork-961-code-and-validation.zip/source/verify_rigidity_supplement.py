"""Post-search exact rigidity certificate; never edits frozen search/validation files.
The single-edge-component check is sufficient but not necessary. This supplement
proves the flagged multi-part assignment's source-Q4 stiffness has no free modes.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json
import numpy as np
from scipy.ndimage import label
from swarm import Problem,mat
from physical import element
from scaled_search import fingerprint,atomic_json

def exact_rank(rows,n):
    pivots={};witness=[]
    for values in rows:
        row=[F(int(x)) for x in values]
        for j in sorted(pivots):
            q=row[j]
            if q:row=[a-q*b for a,b in zip(row,pivots[j])]
        j=next((j for j,v in enumerate(row) if v),None)
        if j is not None:
            d=row[j];pivots[j]=[v/d for v in row];witness.append(list(map(int,values)))
    return len(pivots),witness

def element_certificate():
    floating=element();q=[[F(float(x)).limit_denominator(1000000) for x in row] for row in floating]
    error=max(abs(float(q[i][j])-floating[i,j]) for i in range(8) for j in range(8))
    assert error<1e-14 and all(q[i][j]==q[j][i] for i in range(8) for j in range(8))
    # Exact LDL with zero pivots allowed only when the entire remaining column
    # is zero. Nonnegative pivots prove PSD; five positive pivots prove rank5.
    L=[[F(int(i==j)) for j in range(8)] for i in range(8)];D=[]
    for j in range(8):
        d=q[j][j]-sum(L[j][k]**2*D[k] for k in range(j));assert d>=0;D.append(d)
        for i in range(j+1,8):
            residual=q[i][j]-sum(L[i][k]*L[j][k]*D[k] for k in range(j))
            if d:L[i][j]=residual/d
            else:assert residual==0
    assert sum(d>0 for d in D)==5
    xy=[(0,1),(1,1),(1,0),(0,0)]
    modes=[[1 if i%2==0 else 0 for i in range(8)],[1 if i%2 else 0 for i in range(8)],[v for x,y in xy for v in (y,x)]]
    assert all(sum(q[i][j]*v[j] for j in range(8))==0 for v in modes for i in range(8))
    assert exact_rank(modes,8)[0]==3
    return {'positive_semidefinite_exact_LDL':True,'rank':5,'nullity':3,'LDL_diagonal':[str(d) for d in D],'exact_rational_matrix':[[str(v) for v in row] for row in q],'maximum_difference_from_floating_source_matrix':error,'source_array_coordinate_kernel':'ux=tx+y*omega, uy=ty+x*omega; plus signs follow the supplied element matrix with array y coordinates','local_node_coordinates':xy,'three_independent_null_modes_verified_exactly':True}

def certificate(campaign):
    campaign=Path(campaign);raw=campaign/'validation/validation.json';original=json.loads(raw.read_text());summary=campaign/'summary.json'
    assert original['complete'] and original['summary_sha256']==hashlib.sha256(summary.read_bytes()).hexdigest()
    name='global_swarm_seed0_final';record=original['records'][name]
    p=Problem(campaign/'inputs/data');path=campaign/'runs/global_swarm_seed0_best.mat';labels=mat(path,'Label').astype(int);x=labels.ravel()[p.active]
    assert fingerprint(x)==record['label_sha256']
    solid=p.assemble(x)[:,:750].astype(bool);ny,nx=solid.shape;parts,count=label(solid);assert count==2
    nodes=[];sizes=[]
    for k in range(1,count+1):
        y,xx=np.nonzero(parts==k);v=xx*(ny+1)+y;sizes.append(int(len(v)))
        nodes.append(np.unique(np.concatenate([v,v+1,v+(ny+1),v+(ny+2)])))
    shared=np.intersect1d(*nodes);shared_xy=[(int(v//(ny+1)),int(v%(ny+1))) for v in shared];rows=[]
    for xx,y in shared_xy:
        rows.extend([[1,0,y,-1,0,-y],[0,1,xx,0,-1,-xx]])
    for k,used in enumerate(nodes):
        xx=used//(ny+1);y=used%(ny+1)
        for yy in y[xx==nx]:
            row=[0]*6;row[3*k]=1;row[3*k+2]=int(yy);rows.append(row)
        for xxx in xx[(y==ny//2)&((xx==0)|(xx==nx))]:
            row=[0]*6;row[3*k+1]=1;row[3*k+2]=int(xxx);rows.append(row)
    rank,witness=exact_rank(rows,6);ke=element_certificate();passed=rank==6 and len(shared)>=2
    result={'passed':passed,'record':name,'label_sha256':record['label_sha256'],'original_validation_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'summary_sha256':original['summary_sha256'],'original_single_edge_component_gate_passed':False,'edge_connected_parts':count,'part_element_counts':sizes,'shared_node_coordinates':shared_xy,'rigid_parameters':6,'exact_constraint_rank':rank,'independent_integer_constraint_rows':witness,'constraint_row_count':len(rows),'element_certificate':ke,'conclusion':'Each edge-connected source-Q4 part has exactly three zero-energy modes. Shared-node continuity and the original supports constrain all six modes, so the assembled constrained solid stiffness is positive definite. Three distinct point joints are sufficient here; the earlier single-edge-component gate was inconclusive, not evidence of a free hinge.','scope':'Supplementary post-search geometry certification only. No optimization, objective, query budget, label assignment or original failed validation record is changed.'}
    assert passed;atomic_json(campaign/'validation/rigidity_supplement.json',result)
    # A separate combined assessment retains the original record verbatim for
    # provenance. No search trajectory or original audit output is overwritten.
    combined=json.loads(raw.read_text());entry=combined['records'][name];entry['original_validation_record']=json.loads(json.dumps(entry));entry['geometry']['original_single_edge_component_certificate_passed']=False;entry['geometry']['supplemental_exact_rigidity_certificate']='rigidity_supplement.json';entry['geometry']['solid_stiffness_positive_definiteness_certified']=True;entry['geometry']['certificate_scope']+=' Supplemented by exact source-element PSD/nullspace and coupled-body constraint rank; see rigidity_supplement.json.'
    assert entry['stats']['cg_info']==0 and entry['stats']['relative_residual']<=1.1e-10
    entry['passed']=True;entry['passed_via_supplemental_geometry_certificate']=True
    combined['original_validation_passed']=original['passed'];combined['original_validation_sha256']=result['original_validation_sha256'];combined['supplemental_geometry_certificate']='rigidity_supplement.json';combined['passed']=all(r['passed'] for r in combined['records'].values()) and combined['winner_checks']['passed'];assert combined['passed']
    atomic_json(campaign/'validation/validation_with_rigidity_supplement.json',combined)
    return result

def self_test():
    ke=element_certificate();assert ke['rank']==5
    fixed=[[1,0,0,0,0,0],[0,1,0,0,0,0],[1,0,1,0,0,0]]
    one=[[1,0,0,-1,0,0],[0,1,0,0,-1,0]]
    two=one+[[1,0,1,-1,0,-1],[0,1,1,0,-1,-1]]
    assert exact_rank(fixed+one,6)[0]==5
    assert exact_rank(fixed+two,6)[0]==6
    print('PASS: exact source element PSD/rank/kernel, one-point hinge rank5, two-point rigid coupling rank6; no FEA')

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--campaign',type=Path,default=Path(__file__).resolve().parent/'global_results/campaign');a.add_argument('--self-test',action='store_true');args=a.parse_args()
    if args.self_test:self_test()
    else:print(json.dumps(certificate(args.campaign),indent=2))
