"""Independent geometry/anchor certificate; assembles pixels but performs no FEA.

A single edge-connected Q4 component has only three rigid zero-energy modes.
Source boundary constraints of rank three eliminate those modes. Node connectivity
alone is insufficient because point contacts can admit hinge mechanisms.
"""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.ndimage import label
from swarm import Problem,mat


def audit(data,label_path):
    p=Problem(data)
    labels=np.asarray(mat(label_path,'Label'))
    if labels.shape!=(26,13) or not np.issubdtype(labels.dtype,np.integer) or np.any((labels<0)|(labels>14)):
        raise ValueError('Label must be a 26x13 integer matrix with values 0..14')
    phi=p.assemble(labels.ravel()[p.active])
    symmetric=bool(np.array_equal(phi,phi[:,::-1]))
    if not symmetric:raise ValueError('Source half-domain requires mirrored geometry')
    ny,fx=phi.shape;nx=fx//2
    solid=phi[:,:nx].astype(bool);del phi
    edges,ne=label(solid)
    comps,nn=label(solid,np.ones((3,3),dtype=np.uint8))
    interest=np.pad(mat(Path(data)/'Interest.mat','Interest'),((0,1),(0,1)),mode='edge').astype(bool)
    # Reflect the full original mask onto the half domain. Its pixel-to-node
    # convention is asymmetric, so either member can contribute to the objective.
    objective=interest[:,:nx+1].copy()
    objective[:,:nx]|=interest[:,nx+1:][:,::-1]
    del interest
    records=[]
    for cid in range(1,nn+1):
        ys,xs=np.nonzero(comps==cid)
        # Compact bounding-box node map avoids million-node sort/unique buffers.
        x0,x1=int(xs.min()),int(xs.max());y0,y1=int(ys.min()),int(ys.max())
        local=comps[y0:y1+1,x0:x1+1]==cid
        present=np.zeros((y1-y0+2,x1-x0+2),bool)
        for dy,dx in [(0,0),(0,1),(1,0),(1,1)]:
            present[dy:dy+local.shape[0],dx:dx+local.shape[1]]|=local
        py,px=np.nonzero(present);px+=x0;py+=y0
        cx=float(px.mean());cy=float(py.mean());rows=[]
        sym=px==nx
        if sym.any():rows.extend(np.column_stack((np.ones(sym.sum()),np.zeros(sym.sum()),-(py[sym]-cy)/max(nx,ny))).tolist())
        vertical=(py==ny//2)&((px==0)|(px==nx))
        if vertical.any():rows.extend(np.column_stack((np.zeros(vertical.sum()),np.ones(vertical.sum()),(px[vertical]-cx)/max(nx,ny))).tolist())
        rank=int(np.linalg.matrix_rank(np.asarray(rows))) if rows else 0
        edge_ids=np.unique(edges[ys,xs]);edge_ids=edge_ids[edge_ids>0]
        overlap=int(np.count_nonzero(objective[py,px]))
        records.append({'component':cid,'solid_elements':int(len(xs)),'retained_nodes':int(len(px)),
            'element_bounds_xy':[x0,x1,y0,y1],'edge_connected_parts':int(len(edge_ids)),
            'symmetry_ux_constraints':int(sym.sum()),'midpoint_uy_constraints':int(vertical.sum()),
            'rigid_motion_constraint_rank':rank,'objective_node_overlap':overlap,
            'rigid_modes_anchored':rank==3,
            'positive_definiteness_certified_by_edge_connectivity':bool(len(edge_ids)==1 and rank==3)})
    certificate=all(r['positive_definiteness_certified_by_edge_connectivity'] for r in records)
    return {'label_file':str(Path(label_path).resolve()),'model':'source CA=1 half-domain solid geometry',
        'shape':list(solid.shape),'mirror_symmetric':symmetric,'edge_connected_components':int(ne),
        'node_connected_components':int(nn),'solid_elements':int(solid.sum()),'components':records,
        'all_component_rigid_modes_anchored':all(r['rigid_modes_anchored'] for r in records),
        'solid_stiffness_positive_definiteness_certified':certificate,
        'certificate_scope':'Geometry-only certificate for zero-void solid stiffness with source constraints; does not certify void Schur approximation error or solver convergence.'}


def main():
    root=Path(__file__).resolve().parent
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--data',type=Path,default=root/'source/data')
    ap.add_argument('--label',type=Path,default=root/'source/Label_opt.mat')
    ap.add_argument('--output',type=Path)
    args=ap.parse_args();result=audit(args.data,args.label)
    text=json.dumps(result,indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(text+'\n')
    print(text)

if __name__=='__main__':main()
