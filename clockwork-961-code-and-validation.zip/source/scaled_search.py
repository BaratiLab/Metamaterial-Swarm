"""Resumable, physical-only 24-agent portfolio and matched coordinate search.
Checkpoint pickle is local trusted state: never load an untrusted checkpoint.
"""
import hashlib,json,pickle,time
from pathlib import Path
import numpy as np
ROLES=('single_scout','adjacent','coordinate_probe','spatial_patch','crossover','anneal','successful_cell','path_relink')

def fingerprint(x):return hashlib.sha256(np.asarray(x,dtype='<i2').tobytes()).hexdigest()
def atomic_pickle(path,obj):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_bytes(pickle.dumps(obj,protocol=5));tmp.replace(path)
def atomic_json(path,obj):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2));tmp.replace(path)

def optimize(problem,method,budget,seed,initial,on_progress=None,checkpoint=None):
    if method not in ('scaled_swarm','coordinate_descent'):raise ValueError('Unknown method')
    if budget<1:raise ValueError('budget must be positive')
    initial=np.asarray(initial)
    if initial.ndim!=1 or len(initial)!=len(problem.active) or not np.issubdtype(initial.dtype,np.integer) or np.any((initial<0)|(initial>14)):raise ValueError('Invalid initial labels')
    initial=initial.astype(int);n=len(initial);path=Path(checkpoint) if checkpoint else None
    identity={'method':method,'seed':seed,'initial_sha256':fingerprint(initial),'dimension':n,'model':getattr(problem,'identity',None),'physical_tolerance':getattr(problem,'tol',None),'algorithm_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    if path and path.exists():
        st=pickle.loads(path.read_bytes())
        if st['identity']!=identity:raise ValueError('Checkpoint belongs to a different run/model/initial')
        if budget<st['calls']:raise ValueError('Budget smaller than resumed calls')
    else:
        streams=np.random.SeedSequence(seed).spawn(25)
        st={'identity':identity,'rng':np.random.default_rng(streams[-1]),'agents':[{'role':r,'island':island,'rng':np.random.default_rng(streams[island*8+j]),'cursor':0,'evaluations':0,'improvements':0,'resolved':0,'unresolved':0,'cache_hits':0,'successful_new_solves':0,'failed_new_attempts':0} for island in range(3) for j,r in enumerate(ROLES)],'seen':{},'archive':[],'calls':0,'events':[],'turn':0,'weights':np.ones(n),'islands':[None]*3,'island_scores':[np.inf]*3,'chains':[None]*3,'chain_scores':[np.inf]*3,'coordinate':{'x':initial.copy(),'score':np.inf,'cells':[],'cell':None,'alternatives':[]},'cache_hits':0,'successful_new_solves':0,'failed_new_attempts':0,'resolved':0,'unresolved':0,'duplicates_skipped':0,'seconds':0.}
    start=time.perf_counter();start_seconds=st['seconds'];coords=np.array([divmod(int(i),13) for i in problem.active])
    def save():
        st['seconds']=start_seconds+time.perf_counter()-start
        if path:
            path.parent.mkdir(parents=True,exist_ok=True);atomic_pickle(path,st)
            atomic_json(path.with_suffix('.json'),report())
    def report():
        return {'method':method,'seed':seed,'budget':budget,'unique_candidates':st['calls'],'initial_sha256':identity['initial_sha256'],'initial_loss':st['events'][0]['loss'] if st['events'] else None,'best_loss':st['archive'][0][0] if st['archive'] else None,'best_labels':st['archive'][0][1].tolist() if st['archive'] else None,'resolved':st['resolved'],'unresolved':st['unresolved'],'cache_hits':st['cache_hits'],'successful_new_solves':st['successful_new_solves'],'failed_new_attempts':st['failed_new_attempts'],'duplicates_skipped':st['duplicates_skipped'],'seconds':st['seconds'],'events':st['events'],'agents':[{k:v for k,v in a.items() if k!='rng'} for a in st['agents']] if method=='scaled_swarm' else [],'objective':'physical displacement loss; no surrogate','coordinate_rule':'random cell permutation; random alternative order; first improvement commits and advances cell' if method=='coordinate_descent' else None}
    def evaluate(x,agent):
        key=tuple(map(int,x))
        if key in st['seen']:
            st['duplicates_skipped']+=1;return st['seen'][key],False
        record_key=fingerprint(x)[:20];record=getattr(problem,'records',{}).get(record_key)
        is_cached=bool(record is not None and record.get('tolerance',np.inf)<=getattr(problem,'tol',np.inf))
        solves_before=getattr(problem,'solves',None);value=problem.score(x)
        score=float(value) if value is not None else np.inf
        if not np.isfinite(score):score=np.inf
        solves_after=getattr(problem,'solves',None)
        if is_cached:st['cache_hits']+=1
        elif solves_before is not None and solves_after is not None and solves_after>solves_before:st['successful_new_solves']+=solves_after-solves_before
        elif not np.isfinite(score):st['failed_new_attempts']+=1
        elif solves_before is None:st['successful_new_solves']+=1
        before=st['archive'][0][0] if st['archive'] else np.inf;st['seen'][key]=score;st['calls']+=1
        resolved=bool(np.isfinite(score));st['resolved' if resolved else 'unresolved']+=1
        if resolved:
            st['archive'].append((score,x.copy()));st['archive'].sort(key=lambda z:z[0]);del st['archive'][32:]
        if agent is not None:
            a=st['agents'][agent];a['evaluations']+=1;a['improvements']+=int(score<before);a['resolved' if resolved else 'unresolved']+=1
            if is_cached:a['cache_hits']+=1
            elif solves_before is not None and solves_after is not None and solves_after>solves_before:a['successful_new_solves']+=solves_after-solves_before
            elif not resolved:a['failed_new_attempts']+=1
            elif solves_before is None:a['successful_new_solves']+=1
        event={'evaluation':st['calls'],'agent':agent,'role':st['agents'][agent]['role'] if agent is not None else ('initial' if st['calls']==1 else 'coordinate_descent'),'loss':score if resolved else None,'resolved':resolved,'cache_hit':is_cached,'best_loss':st['archive'][0][0] if st['archive'] else None,'label_sha256':fingerprint(x)}
        st['events'].append(event);return score,True
    def notify(new):
        save()
        if new and on_progress:on_progress(st['events'][-1])
    if st['calls']==0:
        score,new=evaluate(initial,None)
        if np.isfinite(score):
            st['islands']=[initial.copy() for _ in range(3)];st['island_scores']=[score]*3;st['chains']=[initial.copy() for _ in range(3)];st['chain_scores']=[score]*3;st['coordinate']['score']=score
        notify(new)
    if not st['archive']:raise ValueError('Initial physical evaluation unresolved; no finite incumbent')
    attempts=0
    while st['calls']<budget:
        attempts+=1
        if attempts>100000:raise RuntimeError('No unique candidates available within proposal limit')
        if method=='coordinate_descent':
            c=st['coordinate'];rng=st['rng']
            if c['cell'] is None or not c['alternatives']:
                if not c['cells']:c['cells']=rng.permutation(n).tolist()
                c['cell']=c['cells'].pop();c['alternatives']=rng.permutation([k for k in range(15) if k!=c['x'][c['cell']]]).tolist()
            candidate=c['x'].copy();candidate[c['cell']]=c['alternatives'].pop();score,new=evaluate(candidate,None)
            if score<c['score']:c['x']=candidate.copy();c['score']=score;c['cell']=None;c['alternatives']=[]
        else:
            idx=st['turn']%24
            if st['turn']%24==0:
                global_score,global_x=st['archive'][0]
                for island in range(3):
                    if global_score<st['island_scores'][island]:st['islands'][island]=global_x.copy();st['island_scores'][island]=global_score
            st['turn']+=1;a=st['agents'][idx];a['cursor']+=1;rng=a['rng'];island=a['island'];role=a['role'];base=st['islands'][island].copy();candidate=base.copy()
            if role=='single_scout':j=rng.integers(n);candidate[j]=(candidate[j]+rng.integers(1,15))%15
            elif role=='adjacent':j=rng.integers(n);candidate[j]=(candidate[j]+rng.choice([-1,1]))%15
            elif role=='coordinate_probe':j=(a['cursor']-1+island)%n;candidate[j]=(candidate[j]+1+(a['cursor']//n)%14)%15
            elif role=='spatial_patch':
                j=rng.integers(n);ids=np.argsort(np.sum((coords-coords[j])**2,axis=1),kind='stable')[:min(n,2+island)];candidate[ids]=(candidate[ids]+rng.choice([-1,1]))%15
            elif role in ('crossover','path_relink'):
                other=st['archive'][rng.integers(len(st['archive']))][1];ids=np.flatnonzero(other!=candidate)
                if len(ids):
                    ids=rng.choice(ids,size=min(len(ids),1 if role=='path_relink' else 2+island),replace=False);candidate[ids]=other[ids]
                else:j=rng.integers(n);candidate[j]=(candidate[j]+rng.integers(1,15))%15
            elif role=='anneal':candidate=st['chains'][island].copy();j=rng.integers(n);candidate[j]=(candidate[j]+rng.integers(1,15))%15
            else:j=rng.choice(n,p=st['weights']/st['weights'].sum());candidate[j]=(candidate[j]+rng.integers(1,15))%15
            score,new=evaluate(candidate,idx)
            if not new:st['turn']-=1
            if score<st['island_scores'][island]:st['weights'][candidate!=base]+=1;st['islands'][island]=candidate.copy();st['island_scores'][island]=score
            # Fixed per-island temperature gives exact resume and budget-extension behavior.
            temperature=max(1e-9,.01*abs(st['events'][0]['loss']))
            if score<st['chain_scores'][island] or (role=='anneal' and np.isfinite(score) and rng.random()<np.exp(min(0,(st['chain_scores'][island]-score)/temperature))):st['chains'][island]=candidate.copy();st['chain_scores'][island]=score
        notify(new)
        if new:attempts=0
    save();return report(),st['archive'][0][1].copy()

def self_test():
    import tempfile
    class Tiny:
        initial=np.full(12,7,dtype=int);active=np.arange(12)
        def score(self,x):return None if np.sum(x)%7==0 and not np.array_equal(x,self.initial) else float(np.square(x-3).sum())
    for method in ('scaled_swarm','coordinate_descent'):
        for seed in (0,1,2):
            full,x=optimize(Tiny(),method,61,seed,Tiny.initial)
            with tempfile.TemporaryDirectory() as d:
                cp=Path(d)/'state.pkl'
                class Interrupted(Exception):pass
                def callback(e):
                    if e['evaluation']==19:raise Interrupted
                try:optimize(Tiny(),method,61,seed,Tiny.initial,callback,cp)
                except Interrupted:pass
                resumed,y=optimize(Tiny(),method,61,seed,Tiny.initial,checkpoint=cp)
                assert resumed['events']==full['events'] and np.array_equal(x,y)
            assert full['unique_candidates']==61 and full['resolved']+full['unresolved']==61
            assert len({e['label_sha256'] for e in full['events']})==61
            assert full['best_loss']<=full['initial_loss']
            if method=='scaled_swarm':assert len(full['agents'])==24 and all(a['evaluations'] for a in full['agents'])
    print('PASS: both methods x three seeds; exact interruption/resume, unique matched budgets, unresolved accounting, 24-agent participation')
if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--self-test',action='store_true');args=ap.parse_args()
    if args.self_test:self_test()
    else:ap.error('Use optimize() from the campaign runner, or --self-test')
