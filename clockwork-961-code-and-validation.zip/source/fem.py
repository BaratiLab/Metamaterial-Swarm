"""Literal stiffness/load port of UCal.m, with explicit memory guard.
E0 occurs twice in the supplied MATLAB stiffness; preserved intentionally.
"""
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

def displacement(phi,allow_large=False):
    ny,nx=phi.shape;ne=nx*ny;nd=2*(ny+1)*(nx+1)
    if ne>100000 and not allow_large:
        raise MemoryError(f'{ne:,} elements, {nd:,} DOFs: full source solve requires explicit allow_large=True and substantial RAM')
    A11=np.array([[12,3,-6,-3],[3,12,3,0],[-6,3,12,-3],[-3,0,-3,12]])
    A12=np.array([[-6,-3,0,3],[-3,-6,-3,-6],[0,-3,-6,3],[3,-6,3,-6]])
    B11=np.array([[-4,3,-2,9],[3,-4,-9,4],[-2,-9,-4,-3],[9,4,-3,-4]])
    B12=np.array([[2,-3,4,-9],[-3,2,9,-2],[4,9,2,3],[-9,-2,3,2]])
    E0=7e6;emin=1e-9;nu=.35
    ke=E0*.01/(1-nu**2)/24*(np.block([[A11,A12],[A12.T,A11]])+nu*np.block([[B11,B12],[B12.T,B11]]))
    nodes=np.arange((ny+1)*(nx+1)).reshape((ny+1,nx+1),order='F')
    base=(2*nodes[:-1,:-1]+2).ravel(order='F');edof=base[:,None]+np.array([0,1,2*ny+2,2*ny+3,2*ny,2*ny+1,-2,-1])
    ii=np.repeat(edof,8,axis=1).ravel();jj=np.tile(edof,(1,8)).ravel()
    vals=((emin+phi.ravel(order='F')*(E0-emin))[:,None]*ke.ravel()[None,:]).ravel()
    k=coo_matrix((vals,(ii,jj)),shape=(nd,nd)).tocsr();k=(k+k.T)*.5
    # MATLAB one-based support indices, including midpoint support convention.
    fixed=np.unique(np.r_[ny+2,2*nx*(ny+1)+ny+2,nx*(ny+1)+ny+1,nx*(ny+1)+ny+2,np.arange(nx*(ny+1)+1,nx*(ny+1)+2*ny+2,2)]).astype(int)-1
    f=np.zeros(nd);fa=50*(50*50)**2
    f[np.arange(0,2*(ny+1),2)]=fa/ny;f[0]=f[2*ny]=fa/ny/2
    right=2*nx*(ny+1);f[right+np.arange(0,2*(ny+1),2)]=-fa/ny;f[right]=f[right+2*ny]=-fa/ny/2
    free=np.setdiff1d(np.arange(nd),fixed);u=np.zeros(nd);u[free]=spsolve(k[free][:,free],f[free]);return u

def relative_loss(u,u_origin,interest):
    mask=np.pad(interest,((0,1),(0,1)),mode='edge').ravel(order='F')>0;mask=np.repeat(mask,2)
    a=np.asarray(u).ravel();b=np.asarray(u_origin).ravel();den=np.linalg.norm(b[mask])
    if den==0:raise ValueError('Zero normalization')
    return float(np.linalg.norm(a[mask]-b[mask])/den)
