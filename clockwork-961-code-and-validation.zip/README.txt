Clockwork exact-961 source and recorded validation

Frozen optimizer and solver sources are in source/. Recorded swarm-only events,
endpoint labels, strict validation, field validation, and descriptive island
attribution are in data/. Field-recovery source is supplied for inspection.
No optimization or new equilibrium solves were run for this repository update.

Run `python verify_records.py` to check the recorded ledger, endpoint label hashes,
strict-validation flags, and archive checksums. This is an artifact consistency
check, not a new finite-element solve or a reproduction of the search.

Fresh scientific reproduction additionally requires the original author-supplied
input library, masks and reference displacement. Those inputs are not redistributed.
The complete raw nodal-field cache is not included. Field-recovery source retains
its original project-relative layout and requires that original campaign layout;
it is not a standalone replay entry point. Scientific dependencies include NumPy,
SciPy, PyAMG, SymPy and matplotlib as used by the source. No newly verified pinned
environment is claimed. Do not present this archive as an independently rerun study.

The source retains historical utility branches, including a comparator dispatch;
the manuscript and data extracts report only the numerical swarm. The 961 endpoint
was selected retrospectively from an extension toward 1201, and later queries are
excluded. Author input redistribution rights and a blanket software license are
not asserted by this update.
