from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
OUT=Path(__file__).resolve().parent
DATA=OUT.parent/"swarm_optimum_fields"
report=json.loads((DATA/'validation.json').read_text());assert report['complete']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'text.color':'#193449'})
data=[np.load(DATA/'fields'/f'swarm_seed{i}.npz') for i in range(3)]
limits={}
keys=['ux','uy','umag','sigma_xx','sigma_yy','tau_xy','von_mises','principal_max','principal_min']
for key in keys:
    values=np.concatenate([d[key][d['solid']][::4] for d in data])
    if key in ['ux','uy','umag']:
        limit=max(float(abs(d[key][d['solid']]).max()) for d in data)
        rule='unclipped common maximum over all solid elements'
    else:
        limit=float(np.percentile(abs(values),99.5));rule='pooled 99.5th percentile of absolute stress; every fourth solid element sampled deterministically'
    limits[key]={'limit':limit,'rule':rule,'signed':key not in ['umag','von_mises']}
titles={'ux':r'Horizontal displacement $u_x$','uy':r'Vertical displacement $u_y$','umag':r'Displacement magnitude $|u|$',
 'sigma_xx':r'Normal stress $\sigma_{xx}/\sigma_{nom}$','sigma_yy':r'Normal stress $\sigma_{yy}/\sigma_{nom}$','tau_xy':r'Shear stress $\tau_{xy}/\sigma_{nom}$',
 'von_mises':r'Von Mises stress $\sigma_{vm}/\sigma_{nom}$','principal_max':r'In-plane principal stress $\sigma_1/\sigma_{nom}$','principal_min':r'In-plane principal stress $\sigma_2/\sigma_{nom}$'}
with PdfPages(OUT/'swarm_optimum_field_atlas.pdf') as pdf:
    fig,axs=plt.subplots(1,3,figsize=(11.3,4.5),layout='constrained')
    for i,ax in enumerate(axs):
        ax.imshow(data[i]['solid'],cmap='gray_r',origin='upper',extent=(0,30,0,30),interpolation='nearest');ax.set(title=f'Seed {i} · strict loss {report["cases"][i]["strict_loss"]:.6f}',xlabel='x / cell width',ylabel='y / cell height')
    fig.suptitle('Fixed 961-query optimum swarm designs',fontsize=16,weight='bold');pdf.savefig(fig)
    for ext in ['png','pdf']:fig.savefig(OUT/'figures'/f'designs.{ext}',dpi=240,bbox_inches='tight')
    plt.close(fig)
    for name,group,heading in [('displacements',['ux','uy','umag'],'Displacement fields'),('stress_components',['sigma_xx','sigma_yy','tau_xy'],'In-plane stress components'),('derived_stresses',['von_mises','principal_max','principal_min'],'Equivalent and principal stresses')]:
        fig,axs=plt.subplots(3,3,figsize=(7.1,7.5),layout='constrained')
        for row,key in enumerate(group):
            lim=limits[key]['limit'];signed=limits[key]['signed']
            cmap=plt.get_cmap('RdBu_r' if signed else 'inferno').copy();cmap.set_bad('#f4f6f7')
            for col in range(3):
                d=data[col];a=np.ma.array(d[key],mask=~d['solid']);ax=axs[row,col]
                im=ax.imshow(a,cmap=cmap,vmin=-lim if signed else 0,vmax=lim,origin='upper',extent=(0,30,0,30),interpolation='nearest')
                ax.set_title(f'Seed {col}',fontsize=9);ax.set_xticks([0,15,30]);ax.set_yticks([0,15,30]);ax.set_aspect('equal')
                if row==2:ax.set_xlabel('x / cell width')
                if col==0:ax.set_ylabel('y / cell height')
            cb=fig.colorbar(im,ax=axs[row,:],shrink=.8,pad=.02,extend='both' if signed and name!='displacements' else ('max' if name!='displacements' else 'neither'))
            cb.set_label(titles[key],fontsize=9)
        fig.suptitle(heading,fontsize=13,weight='bold')
        note='Original displacement units; solid-element center interpolation.\nVoid regions masked; scales shared across seeds.' if name=='displacements' else 'Solid element-center stresses / nominal traction; common 99.5% limits.\nVoid masked; compression negative; display tails saturated.'
        fig.supxlabel(note,fontsize=9);pdf.savefig(fig)
        for ext in ['png','pdf']:fig.savefig(OUT/'figures'/f'{name}.{ext}',dpi=220,bbox_inches='tight')
        plt.close(fig)
(OUT/'color_scales.json').write_text(json.dumps(limits,indent=2))
(OUT/'README.txt').write_text('FIXED SWARM OPTIMUM FIELD ATLAS\n\nThree exact 961-query endpoint designs (seeds 0, 1, 2). No optimization was launched. Each field is recovered from a new strict 1e-10 equilibrium solve and its loss compared with the preserved validation record. See validation.json.\n\nFields: design; horizontal and vertical displacement; displacement magnitude; sigma_xx, sigma_yy, tau_xy; von Mises; maximum and minimum in-plane principal stress. Principal values are in-plane; plane-stress sigma_zz is zero.\n\nDisplacements retain original model units, with no claim of calibrated mm. Stress is normalized by the nominal applied traction so the legacy repeated stiffness scaling cancels. x points right, y up. Nodal displacement is saved as u; displayed displacement is Q4 element-center interpolation on solid elements. Void-only nodal zeros from the limiting solver are placeholders, not valid recovered fields, and void is masked in all field plots.\n\nStress recovery uses source Q4 node order; quadrature reproduces the source stiffness and an affine patch test passes. Stress is post-processing, not the optimized objective. Stresses and local maxima are not mesh-converged peak estimates. Display scales are common across seeds, separately for each component. Stress color scales saturate at a deterministic pooled absolute 99.5th percentile; full unclipped arrays and extrema are retained. Displacement uses full shared extrema without clipping.\n\nNPZ archives contain full double-precision nodal u, labels, solid mask, solver statistics, and float32 display-field arrays. validation.json records double-precision extrema and loss checks.\n')
print('Saved four-page atlas and four sets of PDF/PNG figures',flush=True)
