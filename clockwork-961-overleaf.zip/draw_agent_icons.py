"""Export the exact Figure 2 glyphs for inline responsibility headings."""
from pathlib import Path
import ast
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle, Arc

root=Path(__file__).resolve().parent
source=(root/'draw_clockwork.py').read_text()
tree=ast.parse(source)
glyph=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='icon')
namespace={'np':np,'Circle':Circle,'Rectangle':Rectangle,'Arc':Arc,'ink':'#193449'}
exec(compile(ast.Module(body=[glyph],type_ignores=[]),'figure2_glyph','exec'),namespace)
for role in range(8):
    fig=plt.figure(figsize=(.4,.4))
    ax=fig.add_axes([0,0,1,1]); ax.set(xlim=(-1,1),ylim=(-1,1),aspect='equal'); ax.axis('off')
    namespace['ax']=ax
    namespace['icon'](0,0,role,c='#193449',r=1)
    fig.savefig(root/'figures'/f'agent_role_{role+1}.pdf',transparent=True)
    fig.savefig(root/'figures'/f'agent_role_{role+1}.png',transparent=True,dpi=400)
    plt.close(fig)
print('Exported eight vector glyphs from the Figure 2 source.')
