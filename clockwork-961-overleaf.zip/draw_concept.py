from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Rectangle
out=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(7.2,3.6));ax.set(xlim=(0,14),ylim=(0,7));ax.axis('off')
ink='#193449';teal='#007f86';amber='#b26720';blue='#376ba0'
def text(x,y,t,size=10,**kw):ax.text(x,y,t,fontsize=size,color=ink,ha='center',va='center',**kw)
def box(x,y,w,h,fc='white',ec=ink):ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.06,rounding_size=.13',fc=fc,ec=ec,lw=1.2))
def arrow(a,b,c=ink):ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=13,lw=1.8,color=c))
for x,c in [(0.2,blue),(4.9,teal),(9.6,amber)]:box(x,1.65,4.1,4.8,ec=c)
text(2.25,6.05,'a  Candidate library',10,weight='bold')
text(6.95,6.05,'b  Swarm search',10,weight='bold')
text(11.65,6.05,'c  Physics feedback',10,weight='bold')
# Illustrative library tiles, not actual measured candidate shapes.
for j in range(3):
 x=.65+j*1.1;box(x,4.45,.95,.95,ec=blue)
 if j==0:
  ax.add_patch(Circle((x+.475,4.925),.28,fill=False,ec=blue,lw=2))
 elif j==1:
  ax.plot([x+.15,x+.8],[4.6,5.25],color=blue,lw=2);ax.plot([x+.15,x+.8],[5.25,4.6],color=blue,lw=2)
 else:
  for d in [.23,.48,.73]:ax.plot([x+.12,x+.83],[4.45+d,4.45+d],color=blue,lw=1.5)
text(2.25,3.95,'15 local candidates',9)
text(2.25,3.30,'168 active choices',9)
text(2.25,2.55,'Random valid start\nNo supplied-solution seed',9)
# Five miniature teams, eight agents each.
for i,(x,y) in enumerate([(5.6,4.85),(6.95,4.85),(8.3,4.85),(6.25,3.55),(7.65,3.55)]):
 for j in range(8):
  t=2*np.pi*j/8;ax.add_patch(Circle((x+.38*np.cos(t),y+.38*np.sin(t)),.07,fc=teal,ec=teal))
 ax.add_patch(Circle((x,y),.11,fc='white',ec=teal,lw=1.1))
arrow((6.0,4.2),(6.8,4.2),teal);arrow((7.1,4.2),(7.9,4.2),teal)
text(6.95,2.55,'40 operators · 5 islands\nShared evaluated designs',9)
# Schematic mesh around a cavity.
for i in range(7):
 for j in range(5):
  if i in [2,3,4] and j in [1,2,3]:continue
  ax.add_patch(Rectangle((10.1+i*.43,3.25+j*.38),.43,.38,fc='#f2f6f8',ec=blue,lw=.55))
arrow((9.82,4.18),(10.08,4.18),amber);arrow((13.45,4.18),(13.16,4.18),amber)
text(11.65,2.65,'Pixel-resolved FEA\nDisplacement mismatch',9)
arrow((4.35,4.0),(4.84,4.0));arrow((9.05,4.0),(9.54,4.0))
# Returned physical evidence governs subsequent proposals.
ax.plot([11.65,11.65,6.95],[1.57,.95,.95],color=teal,lw=1.7);arrow((6.95,.95),(6.95,1.57),teal)
text(9.4,.43,'Measured feedback → update search',9)
text(2.25,.85,'961 charged queries per run\n3 independent random starts',9)
fig.savefig(out/'figures/concept.pdf',bbox_inches='tight',pad_inches=.08)
fig.savefig(out/'figures/concept.png',bbox_inches='tight',pad_inches=.08,dpi=250)
