"""Conceptual teamwork visual; exact role glyphs and actual validated endpoint geometry."""
from pathlib import Path
import ast
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch,Circle,Rectangle,Arc
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(7.25,4.25));ax.set(xlim=(0,14.4),ylim=(0,8.4));ax.axis('off')
ink='#193449';muted='#536575';teal='#007f86';orange='#b26720'
colors=['#007f86','#376ba0','#8066a1','#b26720','#557d48']
tree=ast.parse((ROOT/'draw_clockwork.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='icon')
ns={'np':np,'ax':ax,'Circle':Circle,'Rectangle':Rectangle,'Arc':Arc,'ink':ink}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'figure2_glyph','exec'),ns)
def text(x,y,s,size=9,**kw):ax.text(x,y,s,fontsize=size,color=kw.pop('color',ink),ha='center',va='center',**kw)
def arrow(a,b,c=teal,both=False,rad=0,lw=1.5,z=1):
    ax.add_patch(FancyArrowPatch(a,b,connectionstyle=f'arc3,rad={rad}',arrowstyle='<|-|>' if both else '-|>',mutation_scale=10,color=c,lw=lw,zorder=z))
def box(x,y,w,h,ec=ink,fc='white',lw=1):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.06,rounding_size=.12',fc=fc,ec=ec,lw=lw,zorder=3))
def parent(x,y,c,variant=0,size=.48):
    cells=np.roll(np.array([[0,1,0],[1,0,1],[0,1,1]]),variant%3,axis=0)
    for a in range(3):
        for b in range(3):
            ax.add_patch(Rectangle((x-size/2+b*size/3,y-size/2+a*size/3),size/3,size/3,ec='white',lw=.45,fc=c if cells[a,b] else '#dce6eb',zorder=7))
center=np.array([4.5,4.35])
positions=[(1.65,5.15),(3.9,7.15),(7.0,5.9),(6.9,2.8),(2.05,2.5)]
for i,((x,y),c) in enumerate(zip(positions,colors)):
    p=np.array([x,y]);v=center-p;v=v/np.linalg.norm(v)
    arrow(p+v*.90,center-v*1.44,c,both=True,rad=.08 if i%2 else -.08,lw=1.7)
    ax.add_patch(Circle((x,y),.88,fc=c+'0C',ec=c,lw=1.15,zorder=3))
    for j in range(8):
        theta=2*np.pi*j/8;xx=x+.65*np.cos(theta);yy=y+.65*np.sin(theta)
        ax.add_patch(Circle((xx,yy),.16,fc='white',ec=c,lw=.7,zorder=5));ns['icon'](xx,yy,j,c,r=.155)
    parent(x,y+.06,c,i,size=.51);text(x,y+1.05 if i==1 else y-1.12,f'Island {i+1}',9,weight='bold')
ax.add_patch(Circle(center,1.40,fc='#e8f5f2',ec=teal,lw=1.6,zorder=3))
for offset in [.14,.07,0]:box(center[0]-.43+offset,center[1]+.03+offset,.72,.49,ec=teal,fc='white',lw=.8)
parent(center[0]-.07,center[1]+.29,teal,size=.30)
text(center[0],center[1]-.32,'Shared memory',8,weight='bold',zorder=9);text(center[0],center[1]-.64,'Designs + losses',7,zorder=9)
text(3.35,1.04,'Center tiles: island parent designs',7.5)
arrow((8.02,4.8),(10.0,4.8),teal,lw=2);text(9.0,5.18,'Propose',8,weight='bold')
text(11.95,6.95,'Physics-tested assembly',10,weight='bold')
solid=np.load(ROOT/'data/seed0_solid_mask.npz')['solid']
ax.imshow(solid,cmap='gray_r',origin='upper',extent=(10.2,13.7,3.05,6.55),interpolation='nearest',zorder=4)
arrow((9.91,4.15),(10.33,4.15),orange,lw=1.8,z=7);arrow((14.02,4.15),(13.59,4.15),orange,lw=1.8,z=7)
text(11.95,2.68,'Full-resolution equilibrium',9,weight='bold');text(11.95,2.23,'Exterior displacement mismatch',8);text(11.95,1.81,'Validated seed-0 geometry shown',7,color=muted)
arrow((11.85,1.38),(4.65,1.82),orange,rad=-.18,lw=1.8);text(9.0,.53,'Loss + feasibility → retain / update',8,color=orange)
text(7.15,.02,'Schematic information flow · one proposal and physical solve at a time',8,color=muted)
for ext in ['pdf','png','svg']:fig.savefig(ROOT/'figures'/f'concept.{ext}',dpi=250,bbox_inches='tight',pad_inches=.08)
plt.close(fig)
