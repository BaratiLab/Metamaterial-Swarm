Clockwork swarm-only manuscript source

Compile main.tex with pdfLaTeX. Figures are supplied as vector PDF and preview PNG. Exact endpoint labels and validation records are in data/.

The field plotting script reads saved fields from the sibling swarm_optimum_fields directory; the complete raw field archive is provided separately as outputs/swarm_optimum_fields.zip. It does not launch optimization or equilibrium solves. matplotlib, numpy are required.

main.tex is the authoritative manuscript. Author declarations and target journal template selection remain pending. See SUBMISSION_REVIEW.txt.
