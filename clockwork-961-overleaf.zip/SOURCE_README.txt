Clockwork swarm-only manuscript source

Compile main.tex with pdfLaTeX. Figures are supplied as vector PDF and preview PNG. Exact endpoint labels and validation records are in data/.

The field plotting script reads saved fields from the sibling swarm_optimum_fields directory. Full raw nodal fields are retained locally and are not included in this public source package. Regenerating the field maps requires those saved solutions. The plotting script does not launch optimization or equilibrium solves. matplotlib and numpy are required.

main.tex is the authoritative manuscript. Author declarations and target journal template selection remain pending. See SUBMISSION_REVIEW.txt.

REFERENCE_NOTES.txt records the scholarly review and the connection between cited agent/optimization foundations and the implemented numerical policies. The bibliography has 25 cited references, ordered by first appearance. No numerical experiment was changed during the editorial review.
