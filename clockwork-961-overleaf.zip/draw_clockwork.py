"""Vector architecture figure; no optimization or physical evaluation."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,Circle,FancyArrowPatch,Rectangle,Arc
import numpy as np
out=Path(__file__).resolve().parent/'figures'
plt.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(7.3,3.9));ax.set(xlim=(0,14),ylim=(0,7.4));ax.axis('off')
ink='#193449';muted='#536575';teal='#007f86';orange='#b26720'
colors=['#007f86','#376ba0','#8066a1','#b26720','#557d48']
def text(x,y,s,size=10,**kw):ax.text(x,y,s,fontsize=size,color=ink,va='center',**kw)
def box(x,y,w,h,s,fc='white',ec=ink,size=10):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.07,rounding_size=.12',fc=fc,ec=ec,lw=1.3,zorder=2));text(x+w/2,y+h/2,s,size,ha='center',zorder=3)
def arr(a,b,c=ink,both=False,ls='-',lw=1.7):
 ax.add_patch(FancyArrowPatch(a,b,arrowstyle='<|-|>' if both else '-|>',mutation_scale=11,lw=lw,color=c,linestyle=ls,shrinkA=1,shrinkB=1,zorder=3))
def icon(x,y,k,c=ink,r=.255):
 # Geometric glyphs stay editable in the vector PDF.
 def ln(xs,ys,**kw):ax.plot(np.array(xs)*r+x,np.array(ys)*r+y,color=c,lw=1.25,zorder=7,**kw)
 def dot(a,b,rr=.12):ax.add_patch(Circle((x+a*r,y+b*r),rr*r,fc=c,ec=c,zorder=8))
 if k==0:
  for a,b in [(-.5,.3),(.1,.55),(.5,-.1),(-.25,-.5),(.25,-.5)]:dot(a,b)
 elif k==1:
  t=np.linspace(-.7,.7,25)
  for h in [-.4,0,.4]:ln(t,.15*np.sin(t*5)+h)
 elif k==2:
  for rr in [.24,.47,.7]:ax.add_patch(Circle((x,y),rr*r,fill=False,ec=c,lw=1,zorder=7))
 elif k==3:
  for a,h in [(-.55,.5),(-.08,1),(.4,.75)]:ax.add_patch(Rectangle((x+a*r,y-.55*r),.25*r,h*r,fc=c,zorder=7))
 elif k==4:
  ln([-.65,.65],[-.55,.55]);ln([-.65,.65],[.55,-.55]);dot(-.65,-.55);dot(-.65,.55);dot(.65,.55);dot(.65,-.55)
 elif k==5:
  ax.add_patch(Arc((x,y),1.3*r,1.3*r,theta1=30,theta2=320,ec=c,lw=1.5,zorder=7));ln([.52,.75,.37],[.34,.2,.12])
 elif k==6:
  ln([-.1,-.1],[.5,-.2]);ax.add_patch(Circle((x-.1*r,y-.43*r),.22*r,fc=c,zorder=7));ln([.25,.6],[.15,.15]);ln([.25,.55],[.45,.45])
 else:
  for a in [-.6,0,.6]:ln([a,a],[-.6,.6]);ln([-.6,.6],[a,a])
  ax.add_patch(Rectangle((x,y),.6*r,.6*r,fc=c,zorder=8))

# A representative island reveals implementation details without repeating
# Figure 1's five-island overview or physical assembly.
def label(x,y,s,size=9,c=ink,**kw):
 ax.text(x,y,s,fontsize=size,color=c,ha='center',va='center',zorder=9,**kw)
def panel(x,y,w,h,title,letter):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.06,rounding_size=.15',fc='#f5f8fa',ec='#d4dfe6',lw=.85,zorder=0))
 label(x+.30,y+h-.30,letter,10,weight='bold')
 ax.text(x+.65,y+h-.30,title,fontsize=10,color=ink,va='center',weight='bold')
panel(.10,2.75,8.45,4.40,'Inside each island','a')
panel(8.95,2.75,4.85,4.40,'Shared state','b')
roles=['Scout','Organizer','Mutator','Learner','Recombiner','Restarter','Explorer','Polisher']
for j,role in enumerate(roles):
 x=1.14+(j%4)*2.10; y=6.00-(j//4)*1.15
 ax.add_patch(Circle((x,y),.32,fc='white',ec=teal,lw=1.1,zorder=4))
 icon(x,y,j,teal,r=.29)
 label(x,y-.49,role,8.4)
# Individual random streams belong to agents; the parent is island-local.
box(.49,3.06,7.65,.66,'Island parent + score',fc='white',ec=teal,size=9)
label(4.33,3.98,'Independent random stream for each agent',8,c=muted)
box(9.35,5.28,4.05,1.02,'Elite archive',fc='#e8f5f2',ec=teal,size=10)
label(11.38,5.00,'Up to 64 resolved designs',8,c=muted)
box(9.35,3.38,4.05,1.02,'Other island parents',fc='#fff4e9',ec=orange,size=9)
label(11.38,3.10,'Recombination donors',8,c=muted)
# Short channel arrows cross the gutter, with no decorative all-to-all links.
arr((9.26,5.78),(8.57,5.78),teal,lw=1.8)
arr((9.26,3.89),(8.57,3.89),orange,lw=1.8)
label(.39,2.22,'c',10,weight='bold')
ax.text(.75,2.22,'One charged query at a time',fontsize=10,color=ink,va='center',weight='bold')
steps=[('Select agent','Round-robin'),('Propose design','Role or local polish'),('Resolve / cache','Shared objective'),('Retain evidence','Parent, archive, best')]
for k,(heading,detail) in enumerate(steps):
 x=.18+k*3.51
 box(x,.70,3.08,.96,'',fc='white',ec=orange if k==3 else '#a8bac6')
 label(x+1.54,1.32,heading,9.2,weight='bold')
 label(x+1.54,.94,detail,7.8,c=muted)
 if k<3:arr((x+3.15,1.18),(x+3.44,1.18),orange if k==2 else teal,lw=1.7)
label(7,.20,'Five copies of panel a retain distinct parents; all agents use the same objective.',8,c=muted)
for ext in ['pdf','png','svg']:
 fig.savefig(out/f'clockwork_architecture.{ext}',dpi=250,bbox_inches='tight',pad_inches=.06)
plt.close(fig)

