"""Vector architecture figure; no optimization or physical evaluation."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,Circle,FancyArrowPatch,Rectangle,Arc
import numpy as np
out=Path(__file__).resolve().parent/'figures'
plt.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(7.3,8.6));ax.set(xlim=(0,14),ylim=(0,16.4));ax.axis('off')
ink='#193449';muted='#536575';teal='#007f86';orange='#b26720'
colors=['#007f86','#376ba0','#8066a1','#b26720','#557d48']
def text(x,y,s,size=10,**kw):ax.text(x,y,s,fontsize=size,color=ink,va='center',**kw)
def box(x,y,w,h,s,fc='white',ec=ink,size=10):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.07,rounding_size=.12',fc=fc,ec=ec,lw=1.3,zorder=2));text(x+w/2,y+h/2,s,size,ha='center',zorder=3)
def arr(a,b,c=ink,both=False,ls='-',lw=1.7):
 ax.add_patch(FancyArrowPatch(a,b,arrowstyle='<|-|>' if both else '-|>',mutation_scale=11,lw=lw,color=c,linestyle=ls,shrinkA=1,shrinkB=1,zorder=3))
def icon(x,y,k,c=ink,r=.255):
 # Geometric glyphs stay editable in the vector PDF.
 def ln(xs,ys,**kw):ax.plot(np.array(xs)*r+x,np.array(ys)*r+y,color=c,lw=1.25,zorder=7,**kw)
 def dot(a,b,rr=.12):ax.add_patch(Circle((x+a*r,y+b*r),rr*r,fc=c,ec=c,zorder=8))
 if k==0:
  for a,b in [(-.5,.3),(.1,.55),(.5,-.1),(-.25,-.5),(.25,-.5)]:dot(a,b)
 elif k==1:
  t=np.linspace(-.7,.7,25)
  for h in [-.4,0,.4]:ln(t,.15*np.sin(t*5)+h)
 elif k==2:
  for rr in [.24,.47,.7]:ax.add_patch(Circle((x,y),rr*r,fill=False,ec=c,lw=1,zorder=7))
 elif k==3:
  for a,h in [(-.55,.5),(-.08,1),(.4,.75)]:ax.add_patch(Rectangle((x+a*r,y-.55*r),.25*r,h*r,fc=c,zorder=7))
 elif k==4:
  ln([-.65,.65],[-.55,.55]);ln([-.65,.65],[.55,-.55]);dot(-.65,-.55);dot(-.65,.55);dot(.65,.55);dot(.65,-.55)
 elif k==5:
  ax.add_patch(Arc((x,y),1.3*r,1.3*r,theta1=30,theta2=320,ec=c,lw=1.5,zorder=7));ln([.52,.75,.37],[.34,.2,.12])
 elif k==6:
  ln([-.1,-.1],[.5,-.2]);ax.add_patch(Circle((x-.1*r,y-.43*r),.22*r,fc=c,zorder=7));ln([.25,.6],[.15,.15]);ln([.25,.55],[.45,.45])
 else:
  for a in [-.6,0,.6]:ln([a,a],[-.6,.6]);ln([-.6,.6],[a,a])
  ax.add_patch(Rectangle((x,y),.6*r,.6*r,fc=c,zorder=8))

text(.25,16.0,'CLOCKWORK',18,weight='bold');text(.25,15.5,'40 agents • 5 cooperating islands • 8 specialist roles',11)
text(.25,14.88,'a',12,weight='bold');text(.8,14.88,'Agent communication and shared state',12,weight='bold')
# Archive-read and cross-island-parent channels are distinct.
ax.plot([.65,.65],[6.9,13.8],color=teal,lw=2)
ax.plot([10.4,10.4],[7.5,13.8],color=orange,lw=2)
for i,c in enumerate(colors):
 y=13.45-i*1.28
 ax.add_patch(FancyBboxPatch((1.2,y-.48),8.55,.96,boxstyle='round,pad=.05,rounding_size=.12',fc=c+'0D',ec=c,lw=1.15))
 text(1.43,y,f'I{i+1}',11,weight='bold',color=c) if False else None
 text(1.42,y+.10,f'I{i+1}',10,weight='bold')
 text(1.36,y-.16,f'{8*i+1}–{8*i+8}',5.5)
 for j in range(8):
  x=2.25+j*.69
  ax.add_patch(Circle((x,y),.255,fc='white',ec=c,lw=1.35,zorder=4));icon(x,y,j,c,r=.255)
 arr((7.45,y),(8.1,y),c,both=True)
 box(8.22,y-.29,1.25,.58,'Parent',ec=c,size=10)
 arr((.65,y),(1.12,y),teal)
 arr((9.82,y),(10.4,y),orange,both=True)
text(11.6,11.1,'Cross-island\nparent sharing\n\nRecombination',10,ha='center',color=orange) if False else None
ax.text(11.7,11.1,'Cross-island\nparent sharing\n\nRecombination',fontsize=10,color=orange,ha='center',va='center',linespacing=1.5)
ax.text(.18,10.9,'Archive reads',rotation=90,fontsize=10,color=teal,ha='center',va='center')
text(4.9,7.6,'Separate parents • shared eight-role repertoire',9,ha='center')
box(.2,5.62,4.05,1.12,'Shared elite archive\nLabels + physical losses\n(up to 64 designs)',fc='#eaf5f4',ec=teal,size=10)
arr((.65,6.8),(.65,6.9),teal)
text(5.05,6.2,'b',12,weight='bold');text(5.5,6.2,'Evaluation and feedback',11,weight='bold')
box(.2,3.65,3.95,1.1,'Proposal scheduler\nOne agent at a time',size=10)
box(5.05,3.5,3.85,1.4,'Physical evaluator\nGeometry + FEA\nor cached result',size=10)
box(9.8,3.65,3.95,1.1,'Acceptance update\nIsland parent + score',fc='#fff4e9',ec=orange,size=10)
arr((4.27,4.2),(4.94,4.2));arr((9.02,4.2),(9.69,4.2),orange)
arr((7.0,4.88),(7.0,5.35),teal)
ax.plot([7.0,2.2],[5.35,5.35],color=teal,lw=1.7);arr((2.2,5.35),(2.2,5.55),teal)
ax.text(7.2,5.12,'Resolved designs → archive',fontsize=9,color=teal,va='center')
arr((12.1,4.88),(12.1,7.15),orange)
ax.text(12.35,6.0,'State\nfeedback',fontsize=10,color=orange,va='center')
ax.plot([12.1,8.85],[7.15,7.15],color=orange,lw=1.7);arr((8.85,7.15),(8.85,7.65),orange)
text(.25,2.97,'c',12,weight='bold');text(.8,2.97,'Eight complementary proposal specialties',11,weight='bold')
roles=['R1 Scout: global sampling','R2 Organizer: spatial patterns','R3 Mutator: multiple scales','R4 Learner: elite frequencies','R5 Recombiner: shared designs','R6 Restarter: parent diversity','R7 Explorer: spatial neighborhoods','R8 Polisher: best-design refinement']
for j,s in enumerate(roles):
 x=.35+(j//4)*7.1;y=2.38-(j%4)*.49
 icon(x+.2,y,j,ink,r=.23);text(x+.65,y,s,9)
text(7,.20,'Stateful search operators • serial physical solves • no all-to-all messaging',9,ha='center')
fig.savefig(out/'clockwork_architecture.pdf',bbox_inches='tight',pad_inches=.06)
fig.savefig(out/'clockwork_architecture.png',dpi=250,bbox_inches='tight',pad_inches=.06)
