const { chromium } = require('playwright'); const fs = require('fs');
(async () => {
  const [,, html, json] = process.argv;
  const raw = JSON.parse(fs.readFileSync(json)); const ev = raw.events;
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1920, height: 1080 } });
  await p.goto('file://' + html + '?render=1'); await p.waitForTimeout(600);
  const R = {};
  // 1. counter at several replay times vs independent mapping
  const samples = [];
  for (const t of [37.0, 39.5, 41.99, 42.5, 47.0, 52.49, 52.6, 53.4]) {
    await p.evaluate(t => window.drawFrame(t), t);
    samples.push(await p.evaluate(() => [...document.querySelectorAll('text')].map(x => x.textContent).find(s => /^Eval \d+ \/ 961$/.test(s))));
  }
  R.counter_samples = samples;
  // 2. best curve at end: parse path, invert y -> loss, compare to distinct best values in JSON
  await p.evaluate(() => window.drawFrame(52.8));
  const d = await p.evaluate(() => document.querySelector('path[stroke-width="3.2"]').getAttribute('d'));
  const ys = [...d.matchAll(/V([\d.]+)/g)].map(m => +m[1]);
  const y0 = +d.match(/^M[\d.]+ ([\d.]+)/)[1];
  const inv = y => Math.pow(10, Math.log10(0.09) + (925 - y) / (925 - 580) * (Math.log10(1.4) - Math.log10(0.09)));
  const drawn = [inv(y0), ...ys.map(inv)];
  const truth = []; ev.forEach((e, i) => { if (i === 0 || e.best_loss !== ev[i - 1].best_loss) truth.push(e.best_loss); });
  R.curve_steps_drawn = drawn.length; R.curve_steps_json = truth.length;
  R.curve_max_rel_err = Math.max(...truth.map((v, i) => Math.abs(drawn[i] - v) / v));
  R.curve_final_drawn = drawn[drawn.length - 1]; R.final_best_json = ev[960].best_loss; R.strict_json = raw.strict_endpoint_loss;
  // 3. visible candidate dots and unresolved ticks
  R.dots_visible = await p.evaluate(() => [...document.querySelectorAll('circle')].filter(c => c.getAttribute('r') === '2.3' || c.getAttribute('r') === '3.2').filter(c => +c.getAttribute('opacity') > 0).length);
  R.dots_expected = ev.filter(e => e.loss !== null).length;
  R.unresolved_ticks = await p.evaluate(() => [...document.querySelectorAll('line[stroke="#c0392b"]')].filter(l => +l.getAttribute('opacity') > 0).length);
  R.unresolved_expected = ev.filter(e => !e.resolved).length;
  // 4. structure: agents/roles/parents
  R.structure = await p.evaluate(() => ({ agent_icons: document.querySelectorAll('rect[mask^="url(#m"]').length - 8, role_masks: document.querySelectorAll('mask').length,
    agent_labels: [...document.querySelectorAll('text')].filter(x => /^A\d+$/.test(x.textContent)).length }));
  // 5. clipping: every visible text / arrow within the 1920x1080 frame, sampled each 0.25 s
  const bad = new Set();
  for (let t = 0; t <= 59.5; t += 0.25) {
    await p.evaluate(t => window.drawFrame(t), t);
    const out = await p.evaluate(() => {
      const res = []; const vis = e => { for (let n = e; n && n.tagName !== 'svg'; n = n.parentNode) { if (n.getAttribute && (n.getAttribute('display') === 'none' || n.getAttribute('opacity') === '0')) return false; } return true; };
      for (const e of document.querySelectorAll('text, path')) {
        if (!vis(e) || (e.tagName === 'text' && !e.textContent)) continue; const r = e.getBoundingClientRect(); if (!r.width) continue;
        if (r.left < -1 || r.top < -1 || r.right > 1921 || r.bottom > 1081) res.push(e.tagName + ':' + (e.textContent || e.getAttribute('d').slice(0, 20)));
      } return res; });
    out.forEach(o => bad.add(t.toFixed(2) + ' ' + o));
  }
  R.clipped = [...bad].slice(0, 20);
  console.log(JSON.stringify(R, null, 1)); await b.close();
})();
