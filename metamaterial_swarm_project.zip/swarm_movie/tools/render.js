// usage: node render.js index.html out.mp4 startFrame endFrame(excl)
const { chromium } = require('playwright'); const { spawn } = require('child_process'); const fs = require('fs');
(async () => {
  const [,, html, out, f0, f1] = process.argv; const tmp = out.replace(/\.mp4$/, '.part.mp4');
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1920, height: 1080 } });
  await p.goto('file://' + html + '?render=1'); await p.waitForTimeout(800); await p.evaluate(() => document.fonts.ready);
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', '30', '-c:v', 'mjpeg', '-i', '-',
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '17', '-pix_fmt', 'yuv420p', '-r', '30', '-movflags', '+faststart', tmp]);
  for (let f = +f0; f < +f1; f++) {
    await p.evaluate(t => window.drawFrame(t), f / 30);
    const buf = await p.screenshot({ type: 'jpeg', quality: 92 });
    if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
  }
  ff.stdin.end(); const code = await new Promise(r => ff.on('close', r)); await b.close();
  if (code === 0) { fs.renameSync(tmp, out); console.log('done', out); } else { console.error('ffmpeg failed', code); process.exit(1); }
})();
