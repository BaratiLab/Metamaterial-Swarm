import json, sys, hashlib
src, out = sys.argv[1], sys.argv[2]
raw = open(src,'rb').read()
d = json.loads(raw)
ev = d['events']
assert len(ev)==961 and ev[-1]['evaluation']==961
ROLE = ['initial','uniform_global','correlated_field','multiscale_mutation','categorical_learning',
        'recombination','diversity_reset','annealed_neighborhood','coordinate_polish','island_local_polish']
rows=[]
for e in ev:
    rows.append([e['evaluation'], e['agent'], e['island'], ROLE.index(e['role']), ROLE.index(e['declared_specialty']),
                 e['loss'], 1 if e['resolved'] else 0, 1 if e['cache_hit'] else 0, e['best_loss'], e['label_sha256'][:12]])
# integrity
for r in rows[1:]: assert r[2]==r[1]//8 and (r[4]-1)==r[1]%8
b=[r[8] for r in rows]; assert all(b[i+1]<=b[i] for i in range(960))
for r in rows: assert (r[5] is None)==(r[6]==0)
meta={'seed':d['seed'],'budget':d['budget'],'strict_endpoint_loss':d['strict_endpoint_loss'],
      'source_sha256':hashlib.sha256(raw).hexdigest(),'roles':ROLE,
      'columns':['evaluation','agent0','island0','executed_role','declared_role','loss','resolved','cache_hit','best_loss','label_sha256_prefix']}
open(out,'w').write('window.SEED0 = '+json.dumps({'meta':meta,'rows':rows},separators=(',',':'))+';\n')
print('ok', meta['source_sha256'])
