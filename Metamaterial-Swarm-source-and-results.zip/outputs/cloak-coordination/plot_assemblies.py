from pathlib import Path
import json,os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from cloak_adapter import CloakProblem
R=Path(__file__).resolve().parent;p=CloakProblem(os.environ.get('CLOAK_PACKAGE_DIR','/Users/amirbaratifarimani/Downloads/Agent_Meta'))
base=np.load(R/'baseline_labels.npy');cases=[('Supplied assignment',base)]
for arm,title in [('numerical','Adaptive numerical'),('hybrid','Coordinated hybrid')]:cases.append((title,np.array(json.loads((R/arm/'state.json').read_text())['labels'])))
fig,axs=plt.subplots(1,3,figsize=(13,4.7),constrained_layout=True)
for ax,(title,labels) in zip(axs,cases):
 phi=p.assemble(labels);ax.imshow(phi,cmap='gray_r',interpolation='nearest',vmin=0,vmax=1)
 for i in np.flatnonzero((labels!=base).ravel()):
  y,x=divmod(int(i),13)
  for yy,xx in [(27-y,x+2),(27-y,27-x)]:ax.add_patch(Rectangle((xx*50-.5,yy*50-.5),50,50,fill=False,lw=.8,edgecolor='#e9543f'))
 ax.axis('off');ax.set_title(title+f'\n{np.count_nonzero(labels!=base)} independent cells changed; VF {phi.mean()*100:.3f}%')
fig.suptitle('Final pixel-resolved assemblies; red outlines mark changed cells',weight='bold')
fig.savefig(R/'retained_assemblies.png',dpi=220)
