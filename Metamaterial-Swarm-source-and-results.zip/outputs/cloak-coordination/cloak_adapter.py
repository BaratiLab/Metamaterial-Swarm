"""Read-only data adapter for Liwei Wang's Agent_Meta package.

MATLAB arrays retain their original dimensions. Candidate rows use row-major
half-domain locations, while MATLAB Label(:) is column-major. This adapter
reproduces Assemble.m's permutation explicitly. It does not claim to run FEM.
"""
from pathlib import Path
import argparse, json, hashlib
import numpy as np
from scipy.io import loadmat, savemat
from scipy.ndimage import label as components
import h5py

def read_mat(path):
    if h5py.is_hdf5(path):
        with h5py.File(path) as f:
            return {k:np.asarray(v).transpose(tuple(reversed(range(v.ndim))))
                    for k,v in f.items() if isinstance(v,h5py.Dataset)}
    return {k:v for k,v in loadmat(path).items() if not k.startswith('_')}

class CloakProblem:
    def __init__(self, root):
        self.root=Path(root); self.data={}
        for p in sorted((self.root/'data').glob('*.mat')):
            self.data.update(read_mat(p))
        d=self.data
        self.indicator=d['Indicator'];self.passive=self.indicator[2:-2,2:15]
        self.candidates=d['PhiIndex'].astype(np.int64)
        self.active=self.passive==1
        self.labels=read_mat(self.root/'Label_opt.mat')['Label'].astype(np.int64)
        assert self.indicator.shape==(30,30)
        assert self.passive.shape==(26,13) and self.candidates.shape==(338,15)
        assert np.array_equal(self.indicator,self.indicator[:,::-1])
        self.validate_labels(self.labels)
        assert np.all(self.candidates[self.active.ravel(order='C')]>0)
        assert self.candidates.max()<=d['ShapeSpace'].shape[2]
        interest=d['Interest'].astype(bool)
        expanded=interest[np.r_[np.arange(1500),1499]][:,np.r_[np.arange(1500),1499]]
        self.monitored=np.repeat(expanded.ravel(order='F'),2)
        self.target=d['UOrigin'].ravel(order='F')
        assert len(self.target)==4506002==len(self.monitored)
        assert np.isfinite(self.target[self.monitored]).all()
        self.target_norm=np.linalg.norm(self.target[self.monitored])
        assert self.target_norm>0

    def validate_labels(self, labels):
        a=np.asarray(labels)
        if a.shape!=(26,13) or not np.isfinite(a).all() or not np.equal(a,np.floor(a)).all():
            raise ValueError('Labels must be a finite integer array of shape 26 x 13.')
        if np.any((a<0)|(a>14)):raise ValueError('Labels must be between 0 and 14 inclusive.')

    def assemble(self, labels):
        self.validate_labels(labels);d=self.data
        half=np.zeros((1300,650),np.uint8)
        for i in range(338):
            y,x=divmod(i,13)
            if self.passive[y,x]==1:
                dataset_id=self.candidates[i,int(labels[y,x])]
                cell=d['ShapeSpace'][:,:,dataset_id-1]
            elif self.passive[y,x]==2:cell=d['OriginCell']
            else:continue
            half[(25-y)*50:(26-y)*50,x*50:(x+1)*50]=cell[::-1,:]
        phi=np.tile(d['OriginCell'],(30,30))
        phi[100:-100,100:-100]=np.concatenate((half,half[:,::-1]),axis=1)
        return phi

    def outside_loss(self, displacement):
        """Exact metric, once a compatible full MATLAB-ordered solve is supplied."""
        u=np.asarray(displacement).ravel(order='F')
        if u.size!=self.target.size or not np.isfinite(u[self.monitored]).all():
            raise ValueError('Expected finite monitored entries in 4,506,002 interleaved MATLAB-ordered DOFs.')
        return float(np.linalg.norm(u[self.monitored]-self.target[self.monitored])/self.target_norm)

    def propose(self, actions):
        """Actions use zero-based half-row-major cell IDs and zero-based labels."""
        out=self.labels.copy();used=set()
        for action in actions:
            i=action['cell']; k=action['label']
            if type(i)!=int or type(k)!=int or not 0<=i<338 or not 0<=k<15:
                raise ValueError('Invalid integer cell or label.')
            y,x=divmod(i,13)
            if not self.active[y,x]:raise ValueError(f'Cell {i} is not a cloak design cell.')
            if i in used:raise ValueError(f'Cell {i} repeated in one proposal.')
            used.add(i);out[y,x]=k
        return out

    def property_prior(self):
        labels=self.labels.copy();prior=self.data['Uenergy'].argmin(axis=1).reshape((26,13),order='C')
        labels[self.active]=prior[self.active]
        return labels

    def feature_rows(self):
        rows=[];d=self.data
        for i in np.flatnonzero(self.active.ravel(order='C')):
            y,x=divmod(int(i),13);old=int(self.labels[y,x])
            oldg=d['ShapeSpace'][:,:,self.candidates[i,old]-1]
            for k in range(15):
                dataset_id=int(self.candidates[i,k]);g=d['ShapeSpace'][:,:,dataset_id-1]
                prop=d['PropertySpace'][dataset_id-1]
                rows.append(dict(cell=int(i),row=y,column=x,label=k,current_label=old,
                    matlab_dataset_id=dataset_id,property_mismatch=float(d['Uenergy'][i,k]),
                    C11=float(prop[0]),C12=float(prop[1]),C22=float(prop[2]),C66=float(prop[3]),
                    volume_fraction=float(prop[4]),pixel_change_fraction=float(np.mean(g!=oldg))))
        return rows

    def audit(self):
        phi=self.assemble(self.labels);_,n=components(phi)
        nearest=self.property_prior()
        ids=np.arange(338).reshape((26,13),order='F')
        # Explicitly reconstruct the original MATLAB DLn(i), then Label(temp).
        labels_in_loop=np.array([self.labels.ravel(order='F')[t] for t in ids.T.ravel(order='F')])
        np.testing.assert_array_equal(labels_in_loop,self.labels.ravel(order='C'))
        assert self.outside_loss(self.target)==0
        shifted=self.target.copy();shifted[self.monitored]*=1.01
        np.testing.assert_allclose(self.outside_loss(shifted),.01,rtol=1e-10)
        outside=self.data['Interest'].astype(bool)
        assert np.all(phi[outside]==1)
        # Inactive labels are a no-op and must never dereference zero PhiIndex.
        noop=self.labels.copy();noop[~self.active]=(noop[~self.active]+1)%15
        assert np.array_equal(phi,self.assemble(noop))
        return dict(independent_design_cells=int(self.active.sum()),full_cloak_cells=int((self.indicator==1).sum()),
            half_domain_slots=338,candidates_per_cell=15,candidate_options=int(self.active.sum()*15),
            nonincumbent_replacements=int(self.active.sum()*14),fine_elements=int(phi.size),
            fine_dofs=int(self.target.size),outside_monitored_dofs=int(self.monitored.sum()),
            target_outside_norm=float(self.target_norm),max_abs_target_outside=float(abs(self.target[self.monitored]).max()),
            max_abs_target_everywhere=float(abs(self.target).max()),
            baseline_geometry_solid_components=int(n),baseline_volume_fraction=float(phi.mean()),
            property_prior_changed_cells=int(np.sum(nearest[self.active]!=self.labels[self.active])),
            matlab_index_permutation_check='passed',inactive_label_noop_check='passed',
            target_identity_loss_check='passed',known_1_percent_loss_check='passed',
            outside_solid_preservation_check='passed',full_fem_evaluated=False,
            assembly_sha256=hashlib.sha256(phi.tobytes()).hexdigest())

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data-dir',required=True);ap.add_argument('--out',required=True)
    ap.add_argument('--actions',help='Optional JSON list of {cell, label} replacements.')
    a=ap.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    p=CloakProblem(a.data_dir)
    (out/'audit.json').write_text(json.dumps(p.audit(),indent=2))
    (out/'candidate_features.json').write_text(json.dumps(p.feature_rows(),indent=2))
    savemat(out/'property_prior_labels.mat',{'Label':p.property_prior()})
    if a.actions:
        labels=p.propose(json.loads(Path(a.actions).read_text()));savemat(out/'proposal.mat',{'Label':labels})
    print(json.dumps(p.audit(),indent=2))
if __name__=='__main__':main()
