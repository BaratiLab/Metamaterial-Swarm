"""Run the frozen numerical arm without reading hybrid outcomes."""
from experiment import prepare,evaluate,load_arm
for n in range(len(load_arm('numerical')['rounds'])+1,11):
    prepare('numerical',n)
    evaluate('numerical',n)
