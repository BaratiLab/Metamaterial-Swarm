"""Commit complementary hybrid nominations before any round outcomes."""
import json,sys,hashlib
from pathlib import Path
from adaptive_selector import propose,_assignment,_flat
ROOT=Path(__file__).resolve().parent
n=int(sys.argv[1]);folder=ROOT/'hybrid'/f'round{n}'
f=json.loads((folder/'feedback.json').read_text());labels=_flat(f['current_labels'])
seen={labels}
for h in f['history']:seen.add(_assignment(_flat(h['incumbent_labels']),h['actions']))
nominees=[propose(f,f['history'])[0]]+[json.loads((folder/(role+'.json')).read_text()) for role in ['response','interfaces']]
valid={(o['cell'],o['label']) for o in f['options']}
for p in nominees:
    a=p['actions'];assert 0<len(a)<=4
    assert len({x['cell'] for x in a})==len(a)
    assert all((x['cell'],x['label']) in valid for x in a)
    assignment=_assignment(labels,a)
    assert assignment not in seen, 'Duplicate or previously measured full assignment: '+p['name']
    seen.add(assignment)
path=folder/'proposals.json'
assert not (folder/'results.json').exists()
path.write_text(json.dumps(nominees,indent=2))
(folder/'coordination.json').write_text(json.dumps(dict(round=n,roles=['numerical','response','interfaces'],checks=['candidate eligibility','<=4 distinct cells','full-assignment novelty against shared ledger and sibling proposals'],proposals_sha256=hashlib.sha256(path.read_bytes()).hexdigest()),indent=2))
print([(p['name'],p['actions']) for p in nominees])
