"""Recover Q4 stresses from saved full-resolution solutions; no new FEM solves.

All stresses are divided by the applied nominal compressive traction. The
legacy E0² h scaling cancels in this ratio. Local plots use element-center
solid stresses; macro profiles use gross-cell averages including ersatz void.
"""
from pathlib import Path
import sys,os,json,csv,gc,hashlib
import numpy as np
from numba import njit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from cloak_adapter import CloakProblem
from fem_solver import element,reflect,FA,E0,EMIN,THICKNESS
from experiment import key
WORK=Path(os.environ.get('CLOAK_WORK_DIR',str(ROOT.parents[1]/'work/cloak-coordination')))
OUT=ROOT.parent/'paper-figures';OUT.mkdir(exist_ok=True)
NU=.35
D=np.array([[1,NU,0],[NU,1,0],[0,0,(1-NU)/2]])/(1-NU**2)
NOMINAL=FA/(E0**2*THICKNESS*1500)

def B(xi,eta):
 dn=np.array([[-(1-eta),1-eta,1+eta,-(1+eta)],[-(1-xi),-(1+xi),1+xi,1-xi]])/2
 b=np.zeros((3,8));b[0,::2]=dn[0];b[1,1::2]=dn[1];b[2,::2]=dn[1];b[2,1::2]=dn[0]
 return b

@njit(cache=True)
def recover(phi,u,d,b,nominal):
 ny,nx=phi.shape;s=np.empty((ny,nx,3),np.float64)
 for x in range(nx):
  for y in range(ny):
   nodes=np.array([x*(ny+1)+y+1,(x+1)*(ny+1)+y+1,(x+1)*(ny+1)+y,x*(ny+1)+y])
   strain=np.zeros(3)
   for i in range(3):
    for j in range(8):strain[i]+=b[i,j]*u[2*nodes[j//2]+j%2]
   mult=EMIN/E0+phi[y,x]*(1-EMIN/E0)
   for i in range(3):
    ss=0.
    for j in range(3):ss+=d[i,j]*strain[j]
    s[y,x,i]=ss*mult/nominal
 return s

def verify():
 ke=sum(B(x,y).T@D@B(x,y)*.25 for x in [-1/np.sqrt(3),1/np.sqrt(3)] for y in [-1/np.sqrt(3),1/np.sqrt(3)])
 error=float(np.max(np.abs(ke-element())));assert error<1e-14,error
 nx=4;ny=3;u=np.empty(2*(nx+1)*(ny+1))
 for x in range(nx+1):
  for y in range(ny+1):
   yp=-y;i=x*(ny+1)+y;u[2*i]=.001*x+.002*yp;u[2*i+1]=.003*x-.0005*yp
 target=D@np.array([.001,-.0005,.005]);s=recover(np.ones((ny,nx)),u,D,B(0,0),1.)
 patch=float(np.max(abs(s-target)));assert patch<1e-15,patch
 # Center stress equals the mean of the four Gauss stresses for affine D.
 rng=np.random.default_rng(19);ue=rng.normal(size=8)
 mean=sum(D@B(x,y)@ue for x in [-1/np.sqrt(3),1/np.sqrt(3)] for y in [-1/np.sqrt(3),1/np.sqrt(3)])/4
 center=float(np.max(abs(mean-D@B(0,0)@ue)));assert center<1e-14
 return dict(stiffness_quadrature_max_difference=error,affine_stress_patch_max_difference=patch,center_vs_mean_gauss_max_difference=center,stress_components=['sigma_xx','sigma_yy','tau_xy'],normalization='sigma_nominal = FA / (1500 * h), with unit pixel length; reported ratio invariant to a uniform length rescaling',normalized_nominal_traction=NOMINAL,local_recovery='Q4 element center; equal to average Gauss stress, not average Gauss von Mises',physical_axes='x right, y up; stored array rows increase downward',local_void_display='masked, not plotted as stress-free measurements',macro_average='all 2500 elements per macro cell, including unchanged original ersatz void stiffness',new_equilibrium_solves=0)

def displacement_path(arm,labels):
 path=WORK/'cache'/arm/key(labels)/'half_displacement.npy'
 if not path.exists():path=WORK/'cache'/key(labels)/'half_displacement.npy'
 assert path.exists(),path
 return path

def main():
 validation=verify();p=CloakProblem(os.environ.get('CLOAK_PACKAGE_DIR','/Users/amirbaratifarimani/Downloads/Agent_Meta'));baseline=np.load(ROOT/'baseline_labels.npy')
 reference=WORK.parent/'cloak-experiment/reference_check/half_displacement.npy'
 cases=[('reference','Uniform base-cell reference',np.tile(p.data['OriginCell'],(30,30)),reference,None),('supplied','Supplied assignment',p.assemble(baseline),WORK/'verified_baseline/half_displacement.npy',baseline)]
 for arm,title in [('numerical','Adaptive numerical'),('hybrid','Coordinated hybrid')]:
  labels=np.array(json.loads((ROOT/arm/'state.json').read_text())['labels']);cases.append((arm,title,p.assemble(labels),displacement_path(arm,labels),labels))
 data={};provenance=[]
 for name,title,phi,path,labels in cases:
  u=reflect(np.load(path),1500);s=recover(phi,u,D,B(0,0),NOMINAL);vm=np.sqrt(np.maximum(s[:,:,0]**2-s[:,:,0]*s[:,:,1]+s[:,:,1]**2+3*s[:,:,2]**2,0))
  macro=s.reshape(30,50,30,50,3).mean(axis=(1,3));solid=phi.astype(bool)
  data[name]=dict(title=title,phi=phi,labels=labels,s=s,vm=vm,macro=macro)
  provenance.append(dict(case=name,displacement_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),shape=list(phi.shape),solid_elements=int(solid.sum()),solid_vm_max=float(vm[solid].max()),solid_vm_p99=float(np.percentile(vm[solid],99)),solid_vm_p995=float(np.percentile(vm[solid],99.5))))
  print('Recovered',name,flush=True);del u;gc.collect()
 external=(p.indicator[::-1,:]==2);ref=data['reference']['macro'];den=float(np.sum(ref[external,:2]**2)+2*np.sum(ref[external,2]**2));metrics={}
 for name in ['supplied','numerical','hybrid']:
  delta=data[name]['macro']-ref
  metrics[name]=dict(exterior_macro_stress_relative_frobenius_error=float(np.sqrt((np.sum(delta[external,:2]**2)+2*np.sum(delta[external,2]**2))/den)),volume_fraction=float(data[name]['phi'].mean()))
 validation['case_provenance']=provenance;validation['secondary_metrics']=metrics;validation['secondary_metric_scope']='relative Frobenius stress-tensor mismatch of gross macro-cell average stress in the 452 fixed outside cells; not the optimization loss'

 # Full-resolution stress fields, common color scales across all four cases.
 vmax=float(np.percentile(np.concatenate([a['vm'][a['phi']>0][::4] for a in data.values()]),99.5))
 smax=float(np.percentile(np.concatenate([abs(a['s'][:,:,0][a['phi']>0][::4]) for a in data.values()]),99.5))
 validation['field_color_limits']=dict(von_mises_upper=vmax,sigma_xx_symmetric_abs=smax,method='common pooled 99.5th percentile from deterministic every-fourth solid-element samples; values beyond the limit are saturated, maxima recorded separately')
 fig,axs=plt.subplots(2,4,figsize=(14.4,7.4),constrained_layout=True)
 for col,(name,a) in enumerate(data.items()):
  mask=a['phi']==0;vm=np.ma.array(a['vm'],mask=mask);sx=np.ma.array(a['s'][:,:,0],mask=mask)
  im0=axs[0,col].imshow(vm,cmap='inferno',vmin=0,vmax=vmax,interpolation='nearest');im1=axs[1,col].imshow(sx,cmap='RdBu_r',vmin=-smax,vmax=smax,interpolation='nearest')
  axs[0,col].set_title(a['title'],fontsize=11)
  for row in [0,1]:axs[row,col].axis('off')
 cb=fig.colorbar(im0,ax=axs[0,:],shrink=.85,pad=.015);cb.set_label(r'Element-center $\sigma_{\rm vm}/\sigma_{\rm nom}$')
 cb=fig.colorbar(im1,ax=axs[1,:],shrink=.85,pad=.015);cb.set_label(r'Element-center $\sigma_{xx}/\sigma_{\rm nom}$')
 fig.suptitle('Recovered stresses on the actual pixel-resolved structures',fontsize=15,weight='bold')
 for ext in ['png','pdf']:fig.savefig(OUT/f'cloak-stress-fields.{ext}',dpi=240,bbox_inches='tight')
 plt.close(fig)

 # Profiles of gross macro-cell averaged stress in fixed outside regions.
 colors={'reference':'#303F4A','supplied':'#999999','numerical':'#227DA9','hybrid':'#8954B0'};xs=np.arange(30)+.5;rows=[]
 fig,axs=plt.subplots(1,3,figsize=(13.5,4.1),constrained_layout=True)
 for name,a in data.items():
  m=a['macro'];values=[-m[1,:,0],-m[:,1,0],np.mean(np.linalg.norm(m-ref,axis=2),axis=1)]
  # Third panel is an exterior-only transverse-stress profile on the top border.
  values[2]=m[1,:,1]
  for k,v in enumerate(values):axs[k].plot(xs,v,label=a['title'],color=colors[name],lw=1.7,ls='--' if name=='reference' else '-')
  for i,x in enumerate(xs):rows.append(dict(case=name,macro_coordinate=float(x),top_compressive_sigma_xx=float(values[0][i]),left_compressive_sigma_xx=float(values[1][i]),top_sigma_yy=float(values[2][i])))
 for ax,title,xlabel,ylabel in zip(axs,['Top exterior row','Left exterior column','Top exterior row'],['x / cell width','Stored row / cell height','x / cell width'],[r'$-\langle\sigma_{xx}\rangle/\sigma_{\rm nom}$',r'$-\langle\sigma_{xx}\rangle/\sigma_{\rm nom}$',r'$\langle\sigma_{yy}\rangle/\sigma_{\rm nom}$']):
  ax.set(title=title,xlabel=xlabel,ylabel=ylabel);ax.grid(alpha=.2);ax.set_xlim(.5,29.5)
 axs[0].legend(fontsize=8);fig.suptitle('Stress profiles averaged over complete original 50 x 50-pixel cells',fontsize=14,weight='bold')
 for ext in ['png','pdf','svg']:fig.savefig(OUT/f'cloak-stress-profiles.{ext}',dpi=240,bbox_inches='tight')
 plt.close(fig)
 with (OUT/'stress-profiles.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)

 # Four measured retained stages, with the same magnified patch in each column.
 hs=json.loads((ROOT/'hybrid/state.json').read_text());evolution=[('Supplied',baseline,json.loads((ROOT/'supplied_assignment_result.json').read_text())['fine_loss'])]
 for n in [2,5,10]:
  rr=hs['rounds'][n-1];best=min(rr['proposals'],key=lambda h:h['loss']);lab=np.array(best['incumbent_labels'])
  for action in best['actions']:lab.flat[action['cell']]=action['label']
  evolution.append((f'Hybrid round {n}',lab,rr['retained_loss']))
 fig,axs=plt.subplots(2,4,figsize=(14.4,7.9),gridspec_kw={'height_ratios':[1,.86]},constrained_layout=True)
 x0,x1,y0,y1=3*50,8*50,9*50,14*50
 for col,(title,lab,loss) in enumerate(evolution):
  phi=p.assemble(lab);axs[0,col].imshow(phi,cmap='gray_r',vmin=0,vmax=1,interpolation='nearest');axs[0,col].add_patch(Rectangle((x0-.5,y0-.5),x1-x0,y1-y0,fill=False,lw=1.3,edgecolor='#D69B2D'))
  axs[0,col].set_title(f'{title}\nLoss {100*loss:.4f}%',fontsize=12)
  axs[1,col].imshow(phi[y0:y1,x0:x1],cmap='gray_r',vmin=0,vmax=1,interpolation='nearest')
  for ax in axs[:,col]:ax.axis('off')
  axs[1,col].set_title(f'{int(np.sum(lab!=baseline))} independent cells changed',fontsize=10)
  # Mark truly changed macro cells in the magnified patch, preserving binary pixels.
  changed=set()
  for i in np.flatnonzero((lab!=baseline).ravel()):
   yy,xx=divmod(int(i),13);changed.add((27-yy,xx+2));changed.add((27-yy,27-xx))
  for yy,xx in changed:
   if x0<=xx*50<x1 and y0<=yy*50<y1:axs[1,col].add_patch(Rectangle((xx*50-x0-.5,yy*50-y0-.5),50,50,fill=False,lw=.9,edgecolor='#8954B0'))
 fig.suptitle('Optimization through actual retained microstructure assignments',fontsize=15,weight='bold')
 fig.supxlabel('Bottom row: identical 5 x 5-cell patch; purple frames mark replacements relative to the supplied design',fontsize=11)
 for ext in ['png','pdf']:fig.savefig(OUT/f'cloak-structure-evolution.{ext}',dpi=260,bbox_inches='tight')
 plt.close(fig)
 (OUT/'stress-recovery-validation.json').write_text(json.dumps(validation,indent=2))
 print(json.dumps(metrics,indent=2),flush=True)

if __name__=='__main__':main()
