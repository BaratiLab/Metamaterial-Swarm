"""Real-data selector pilot. All lengths, forces and moduli are normalized.

Run: python benchmark.py prepare
     python benchmark.py evaluate --actions llm_actions.json
"""
from pathlib import Path
import argparse, hashlib, json, time, csv
import numpy as np
from scipy.io import loadmat
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import splu
from scipy.optimize import minimize
from scipy.ndimage import label as connected_components

ROOT = Path(__file__).resolve().parent
NY, NX, NC = 4, 30, 10
NU, VOID, PAIR_WEIGHT = .35, 1e-6, .03

def save_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False))

def tensor(v):
    a = np.zeros(np.asarray(v).shape[:-1] + (3, 3))
    a[..., 0, 0], a[..., 0, 1], a[..., 1, 0] = v[..., 0], v[..., 1], v[..., 1]
    a[..., 1, 1], a[..., 2, 2] = v[..., 2], v[..., 3]
    return a

CSOLID = tensor(np.array([1, NU, 1, (1-NU)/2])/(1-NU**2))

class Mesh:
    def __init__(self, nx, ny, h=1):
        self.nx, self.ny, self.h = nx, ny, h
        x, y = np.meshgrid(np.arange(nx+1)*h, np.arange(ny+1)*h)
        self.xy = np.column_stack((x.ravel(), y.ravel()))
        b = np.arange(ny)[:, None]*(nx+1) + np.arange(nx)[None, :]
        nodes = np.stack((b, b+1, b+nx+2, b+nx+1), axis=-1).reshape(-1, 4)
        self.edof = (2*nodes[..., None]+np.arange(2)).reshape(-1, 8)
        self.rows = np.repeat(self.edof, 8, axis=1).ravel()
        self.cols = np.tile(self.edof, (1, 8)).ravel()
        self.bs = []
        for eta in [-1/np.sqrt(3), 1/np.sqrt(3)]:
            for xi in [-1/np.sqrt(3), 1/np.sqrt(3)]:
                dn = np.array([[-(1-eta), (1-eta), (1+eta), -(1+eta)],
                               [-(1-xi), -(1+xi), (1+xi), (1-xi)]])/(2*h)
                B = np.zeros((3, 8))
                B[0, 0::2], B[1, 1::2] = dn[0], dn[1]
                B[2, 0::2], B[2, 1::2] = dn[1], dn[0]
                self.bs.append(B)
        self.bs = np.asarray(self.bs)
        self.det = h*h/4
        self.ndof = 2*len(self.xy)

    def assemble(self, C):
        ke = np.einsum('gai,eab,gbj->eij', self.bs, C, self.bs)*self.det
        K = coo_matrix((ke.ravel(), (self.rows, self.cols)), shape=(self.ndof, self.ndof)).tocsc()
        return K

    def compression(self, C, shortening=.12):
        K = self.assemble(C)
        left = np.flatnonzero(np.isclose(self.xy[:, 0], 0))
        right = np.flatnonzero(np.isclose(self.xy[:, 0], self.nx*self.h))
        fixed = np.unique(np.r_[2*left, 2*left+1, 2*right, 2*right[[0,-1]]+1])
        free = np.setdiff1d(np.arange(self.ndof), fixed)
        u = np.zeros(self.ndof)
        u[2*right] = -shortening
        lu = splu(K[free][:, free])
        u[free] = lu.solve(-K[free][:, fixed]@u[fixed])
        force = K@u
        residual = np.linalg.norm(force[free])/max(np.linalg.norm(force[fixed]), 1e-30)
        return u, K, free, lu, float(residual)

    def profile_dofs(self, step=1):
        bottom = np.arange(0, self.nx+1, step)
        top = self.ny*(self.nx+1)+bottom
        return np.r_[2*bottom+1, 2*top+1]

def homogenize(image, stress=False):
    """Periodic Q4 energy homogenization, engineering shear convention."""
    n = image.shape[0]
    m = Mesh(n,n,1/n)
    rho = VOID+(1-VOID)*image.ravel()
    C = rho[:, None, None]*CSOLID
    K = m.assemble(C)
    x,y = np.meshgrid(np.arange(n+1)%n,np.arange(n+1)%n)
    pn = (y*n+x).ravel()
    pd = (2*pn[:, None]+np.arange(2)).ravel()
    P = coo_matrix((np.ones(m.ndof),(np.arange(m.ndof),pd)),shape=(m.ndof,2*n*n)).tocsc()
    kp = P.T@K@P
    lu = splu(kp[2:,2:])
    ua = np.zeros((m.ndof,3))
    ua[0::2,0],ua[1::2,1] = m.xy[:,0],m.xy[:,1]
    ua[0::2,2] = m.xy[:,1]/2
    ua[1::2,2] = m.xy[:,0]/2
    q = np.zeros((2*n*n,3))
    q[2:] = lu.solve(np.asarray(-P.T@K@ua)[2:])
    u = ua+P@q
    strains = np.einsum('gai,eik->egak',m.bs,u[m.edof])
    sigma = np.einsum('eab,egbk->egak',C,strains)
    ceff = sigma.sum(axis=(0,1))*m.det
    if not stress:
        return ceff
    s = sigma.mean(axis=1).reshape(n,n,3,3)
    # Consistent positive normals on opposing sides for comparing transmission.
    tr = [s[:,0][:,[0,2]],s[:,-1][:,[0,2]],s[0][:,[2,1]],s[-1][:,[2,1]]]
    return ceff, np.asarray(tr)

def edges():
    out=[]
    for y in range(NY):
        for x in range(NX):
            i=y*NX+x
            if x+1<NX: out.append((i,i+1,1,0))
            if y+1<NY: out.append((i,i+NX,3,2))
    return out

def load_library():
    g = loadmat(ROOT/'data/Geometries.mat')['Geometries']
    p = loadmat(ROOT/'data/Properties.mat')['Properties']
    assert g.shape == (50,50,90245) and p.shape == (90245,5)
    assert np.max(abs(g.mean(axis=(0,1))-p[:,4]))<1e-12
    return g,p

def macro_target(p, seed):
    """Convex-hull feasible target field; continuous stage fixed for all selectors."""
    rng=np.random.default_rng(seed)
    # Interior anchors avoid extreme near-solid and nearly singular designs.
    mask=(p[:,4]>.45)&(p[:,4]<.86)&(p[:,3]>.02)
    idx=np.flatnonzero(mask)
    scores=[p[idx,0]/p[idx,2],p[idx,2]/p[idx,0],p[idx,3],p[idx,0]+p[idx,2]]
    ids=np.array([idx[np.argmax(scores[0])],idx[np.argmax(scores[1])],
                  idx[np.argmin(scores[2])],idx[np.argmax(scores[3])]])
    anchors=tensor(p[ids,:4])
    mesh=Mesh(NX,NY)
    dofs=mesh.profile_dofs()
    xx=np.linspace(0,1,NX+1)
    desired=np.tile(.08*np.sin(np.pi*xx)**2,2)
    scale=np.linalg.norm(desired)**2
    start=rng.normal(0,.02,(NX*NY,4))
    def calc(z, grad=True):
        z=z.reshape(-1,4)
        ez=np.exp(z-z.max(axis=1,keepdims=True)); w=ez/ez.sum(axis=1,keepdims=True)
        C=np.einsum('ea,aij->eij',w,anchors)
        u,K,free,lu,res=mesh.compression(C)
        err=u[dofs]-desired
        obj=float(err@err/scale)
        adj=np.zeros(mesh.ndof); rhs=np.zeros(mesh.ndof); rhs[dofs]=2*err/scale
        adj[free]=lu.solve(rhs[free])
        eu=np.einsum('gai,ei->ega',mesh.bs,u[mesh.edof])
        el=np.einsum('gai,ei->ega',mesh.bs,adj[mesh.edof])
        dc=-np.einsum('ega,egb->eab',el,eu)*mesh.det
        gw=np.einsum('eij,aij->ea',dc,anchors)
        dz=w*(gw-(w*gw).sum(axis=1,keepdims=True))
        return obj,dz.ravel(),C,u
    result=minimize(lambda z:calc(z)[:2],start.ravel(),jac=True,method='L-BFGS-B',
                    bounds=[(-7,7)]*start.size, options={'maxiter':100,'ftol':1e-9,'gtol':1e-6})
    obj,_,C,u=calc(result.x)
    # Selection is assessed against the achieved macro target, isolating stage 2.
    return C,u[dofs],desired,dict(seed=seed,anchor_ids_zero_based=ids.tolist(),
        optimizer_success=bool(result.success),message=str(result.message),
        iterations=int(result.nit),macro_desired_relative_error=float(np.sqrt(obj)))

def pair_costs(g, ids, tr):
    geom=np.transpose(g[:,:,ids],(2,3,0,1))
    boundaries=np.stack((geom[:,:,:,0],geom[:,:,:,-1],geom[:,:,0,:],geom[:,:,-1,:]),axis=2)
    costs=[]; geometry=[]; mechanical=[]
    for i,j,a,b in edges():
        ai,bj=boundaries[i,:,a],boundaries[j,:,b]
        xor=np.logical_xor(ai[:,None],bj[None,:]).sum(axis=-1)
        union=np.logical_or(ai[:,None],bj[None,:]).sum(axis=-1)
        gg=xor/np.maximum(union,1)
        ta,tb=tr[i,:,a],tr[j,:,b]
        diff=np.linalg.norm(ta[:,None]-tb[None,:],axis=(2,3))
        denom=np.linalg.norm(ta,axis=(1,2))[:,None]+np.linalg.norm(tb,axis=(1,2))[None,:]
        mm=np.mean(diff/np.maximum(denom,1e-12),axis=-1)
        geometry.append(gg); mechanical.append(mm); costs.append(gg+mm)
    return np.array(costs),np.array(geometry),np.array(mechanical)

def adjacency():
    adj=[[] for _ in range(NX*NY)]
    for k,(i,j,*_) in enumerate(edges()):
        adj[i].append((j,k,False));adj[j].append((i,k,True))
    return adj

def energy(labels, unary, pair):
    return float(unary[np.arange(len(labels)),labels].sum()+PAIR_WEIGHT*sum(
        pair[k,labels[i],labels[j]] for k,(i,j,*_) in enumerate(edges())))

def graph_select(unary,pair,seed=1,starts=16):
    rng=np.random.default_rng(seed); adj=adjacency(); best=None; best_e=np.inf
    for s in range(starts):
        labels=unary.argmin(axis=1) if s==0 else rng.integers(NC,size=len(unary))
        for sweep in range(80):
            changes=0
            for i in rng.permutation(len(unary)):
                e=unary[i].copy()
                for j,k,rev in adj[i]: e+=PAIR_WEIGHT*(pair[k,labels[j],:] if rev else pair[k,:,labels[j]])
                new=int(np.argmin(e)); changes+=new!=labels[i];labels[i]=new
            if changes==0:break
        en=energy(labels,unary,pair)
        if en<best_e: best,best_e=labels.copy(),en
    return best

def image_for(g,ids,labels):
    selected=ids[np.arange(len(labels)),labels]
    return np.block([[g[:,:,selected[y*NX+x]] for x in range(NX)] for y in range(NY)])

def assess(labels,ids,g,p,target,unary,pair,gg,mm,fine=True):
    selected=ids[np.arange(len(labels)),labels]
    C=tensor(p[selected,:4]); mesh=Mesh(NX,NY)
    u,_,_,_,res=mesh.compression(C)
    profile=u[mesh.profile_dofs()]
    out={'macro_relative_error':float(np.linalg.norm(profile-target)/np.linalg.norm(target)),
         'graph_energy':energy(labels,unary,pair),
         'mean_property_inf_error':float(unary[np.arange(len(labels)),labels].mean()),
         'mean_geometric_incompatibility':float(np.mean([gg[k,labels[i],labels[j]] for k,(i,j,*_) in enumerate(edges())])),
         'mean_mechanical_incompatibility':float(np.mean([mm[k,labels[i],labels[j]] for k,(i,j,*_) in enumerate(edges())])),
         'volume_fraction':float(p[selected,4].mean()),'macro_equilibrium_residual':res}
    if fine:
        img=image_for(g,ids,labels)
        meshf=Mesh(NX*50,NY*50,1/50)
        t=time.perf_counter()
        uf,_,_,_,resf=meshf.compression((VOID+(1-VOID)*img.ravel())[:,None,None]*CSOLID)
        prof=uf[meshf.profile_dofs(50)]
        out.update(fine_relative_error=float(np.linalg.norm(prof-target)/np.linalg.norm(target)),
            fine_equilibrium_residual=resf, fine_solve_seconds=time.perf_counter()-t)
        # Four-neighbor solid components; report, do not silently treat ersatz as connections.
        _,ncomp=connected_components(img,structure=np.array([[0,1,0],[1,1,1],[0,1,0]]))
        out['solid_connected_components']=int(ncomp)
        out['_fine_profile']=prof.tolist()
    out['_macro_profile']=profile.tolist()
    return out

def sanity_tests(g,p):
    m=Mesh(8,4)
    # Affine patch test verifies element ordering, constitutive convention and quadrature.
    u=np.zeros(m.ndof);u[0::2]=.01*m.xy[:,0]+.02*m.xy[:,1];u[1::2]=-.03*m.xy[:,1]
    strain=np.einsum('gai,ei->ega',m.bs,u[m.edof])
    assert np.max(abs(strain-np.array([.01,-.03,.02])))<1e-12
    uniform=homogenize(np.ones((8,8)))
    assert np.max(abs(uniform-CSOLID))<1e-10
    checks=[]
    for i in [100,10000,50000]:
        C=homogenize(g[:,:,i]);ref=tensor(p[i,:4])
        error=float(np.linalg.norm(C-ref)/np.linalg.norm(ref))
        checks.append({'dataset_id_zero_based':i,'relative_homogenization_error':error})
        assert error<.015, (i,error,C,ref)
    # Adjoint gradient against central finite differences at one macro cell.
    C=np.repeat(CSOLID[None],32,axis=0);u,K,free,lu,_=m.compression(C)
    dofs=m.profile_dofs();target=np.zeros(len(dofs));rhs=np.zeros(m.ndof);rhs[dofs]=2*(u[dofs]-target)
    a=np.zeros(m.ndof);a[free]=lu.solve(rhs[free])
    eu=np.einsum('gai,i->ga',m.bs,u[m.edof[9]]);ea=np.einsum('gai,i->ga',m.bs,a[m.edof[9]])
    analytic=-np.sum(eu[:,0]*ea[:,0])*m.det
    vals=[]
    for eps in [-1e-6,1e-6]:
        cp=C.copy();cp[9,0,0]+=eps;up,*_=m.compression(cp);vals.append(float(np.sum(up[dofs]**2)))
    fd=(vals[1]-vals[0])/2e-6
    assert abs(analytic-fd)/max(abs(fd),1e-12)<1e-5
    return {'affine_patch_test':'passed','uniform_periodic_homogenization':'passed',
            'adjoint_gradient_relative_error':float(abs(analytic-fd)/max(abs(fd),1e-12)),
            'dataset_homogenization_checks':checks}

def prepare(seed):
    g,p=load_library();print('Checking FEM and data',flush=True)
    tests=sanity_tests(g,p);save_json(ROOT/'validation.json',tests)
    print('Optimizing common macro target',flush=True)
    C,target,desired,meta=macro_target(p,seed)
    v=np.column_stack((C[:,0,0],C[:,0,1],C[:,1,1],C[:,2,2]))
    # Same candidate sets for every selector, deterministic sorting and no VAE required.
    ids=np.empty((NY*NX,NC),int)
    unary=np.empty((NY*NX,NC))
    valid=np.flatnonzero(np.linalg.eigvalsh(tensor(p[:,:4])).min(axis=1)>1e-5)
    for i in range(NY*NX):
        dist=np.max(abs(p[valid,:4]-v[i]),axis=1)
        order=np.argsort(dist,kind='stable')[:NC]
        ids[i]=valid[order];unary[i]=dist[order]
    unique=np.unique(ids);trmap={}
    print(f'Computing periodic interface stresses for {len(unique)} candidate geometries',flush=True)
    for k,j in enumerate(unique):
        ce,tr=homogenize(g[:,:,j],stress=True);trmap[int(j)]=tr
        if k%100==0:print(f'  {k}/{len(unique)}',flush=True)
    traction=np.array([[trmap[int(j)] for j in row] for row in ids])
    pair,gg,mm=pair_costs(g,ids,traction)
    np.savez_compressed(ROOT/'problem.npz',ids=ids,unary=unary,pair=pair,gg=gg,mm=mm,
                        target=target,desired=desired,Ctarget=C)
    save_json(ROOT/'problem_metadata.json',meta)
    nearest=unary.argmin(axis=1)
    t=time.perf_counter();graph=graph_select(unary,pair,seed);graph_time=time.perf_counter()-t
    methods={'nearest_property':nearest,'graph_multistart_icm':graph}
    results={}
    for name,labels in methods.items():
        print('Full-geometry FEM:',name,flush=True)
        results[name]=assess(labels,ids,g,p,target,unary,pair,gg,mm)
        save_json(ROOT/(name+'_labels.json'),labels.tolist())
        print(json.dumps({k:v for k,v in results[name].items() if not k.startswith('_')}),flush=True)
    results['graph_multistart_icm']['selection_seconds']=graph_time
    save_json(ROOT/'results.json',results)
    make_feedback(graph,ids,g,p,target,unary,pair,gg,mm)
    plot(g,ids,methods,results,target,desired)

def make_feedback(labels,ids,g,p,target,unary,pair,gg,mm):
    mesh=Mesh(NX,NY);C=tensor(p[ids[np.arange(len(labels)),labels],:4])
    u,K,free,lu,_=mesh.compression(C);dofs=mesh.profile_dofs()
    err=u[dofs]-target;scale=target@target
    rhs=np.zeros(mesh.ndof);rhs[dofs]=2*err/scale
    a=np.zeros(mesh.ndof);a[free]=lu.solve(rhs[free])
    eu=np.einsum('gai,ei->ega',mesh.bs,u[mesh.edof]);ea=np.einsum('gai,ei->ega',mesh.bs,a[mesh.edof])
    dc=-np.einsum('ega,egb->eab',ea,eu)*mesh.det
    adj=adjacency();options=[]
    for i in range(len(labels)):
        cp=tensor(p[ids[i],:4]);pred=np.einsum('ij,kij->k',dc[i],cp-C[i])
        local=[]
        for k in range(NC):
            delta=unary[i,k]-unary[i,labels[i]]; geo=mech=0
            for j,e,rev in adj[i]:
                idx=(labels[j],k) if rev else (k,labels[j]);old=(labels[j],labels[i]) if rev else (labels[i],labels[j])
                geo+=gg[e][idx]-gg[e][old];mech+=mm[e][idx]-mm[e][old]
            delta+=PAIR_WEIGHT*(geo+mech)
            if k!=labels[i]:
                local.append({'cell':int(i),'row':int(i//NX),'column':int(i%NX),'from_label':int(labels[i]),
                    'to_label':k,'dataset_id_zero_based':int(ids[i,k]),'adjoint_predicted_squared_error_change':float(pred[k]),
                    'graph_energy_change':float(delta),'geometry_change_sum':float(geo),
                    'mechanical_change_sum':float(mech),'property_error':float(unary[i,k]),'volume_fraction':float(p[ids[i,k],4])})
        options.extend(local)
    options.sort(key=lambda o:o['adjoint_predicted_squared_error_change'])
    # Candidate estimates are numerical evidence, not selected actions.
    save_json(ROOT/'feedback.json',{'schema':'one-shot batch of <=8 distinct cell replacements',
        'objective':'minimize full-geometry target displacement error; preserve compatibility',
        'baseline_labels':labels.tolist(),'target_profile':target.tolist(),
        'macro_profile':u[dofs].tolist(),'macro_squared_relative_error':float(err@err/scale),'ranked_options':options,
        'note':'Adjoint estimates use homogenized FEM; full-geometry outcome can disagree. No fine FEM outcomes for these proposals have been observed.'})
    # A deterministic comparator commits 8 top-gradient distinct-cell actions.
    used=set();actions=[]
    for option in options:
        if option['cell'] in used:continue
        if option['adjoint_predicted_squared_error_change']>=0:break
        used.add(option['cell']);actions.append({'cell':option['cell'],'to_label':option['to_label']})
        if len(actions)==8:break
    save_json(ROOT/'numerical_actions.json',{'selector':'deterministic_adjoint_top8','actions':actions})

def evaluate(path):
    g,p=load_library();z=np.load(ROOT/'problem.npz')
    ids,unary,pair,gg,mm,target=[z[k] for k in ['ids','unary','pair','gg','mm','target']]
    actions=json.loads(path.read_text());name=actions['selector']
    assert name not in ['nearest_property','graph_multistart_icm']
    replacements=actions['actions'];assert len(replacements)<=8
    assert len({a['cell'] for a in replacements})==len(replacements)
    labels=np.array(json.loads((ROOT/'graph_multistart_icm_labels.json').read_text()))
    for a in replacements:
        assert isinstance(a['cell'],int) and 0<=a['cell']<len(labels)
        assert isinstance(a['to_label'],int) and 0<=a['to_label']<NC
        labels[a['cell']]=a['to_label']
    result=assess(labels,ids,g,p,target,unary,pair,gg,mm)
    result['action_file_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    result['replacements']=len(replacements)
    results=json.loads((ROOT/'results.json').read_text());assert name not in results,'Do not overwrite committed trial'
    results[name]=result;save_json(ROOT/'results.json',results)
    save_json(ROOT/(name+'_labels.json'),labels.tolist())
    methods={k:np.array(json.loads((ROOT/(k+'_labels.json')).read_text())) for k in results}
    plot(g,ids,methods,results,target,z['desired'])
    print(json.dumps({k:v for k,v in result.items() if not k.startswith('_')},indent=2))

def plot(g,ids,methods,results,target,desired):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axs=plt.subplots(len(methods)+1,1,figsize=(15,2.1*len(methods)+3),constrained_layout=True)
    for ax,(name,labs) in zip(axs,methods.items()):
        ax.imshow(image_for(g,ids,labs),origin='lower',cmap='Blues',interpolation='nearest',extent=(0,NX,0,NY))
        ax.set_title(name.replace('_',' ')+' | full-geometry relative error '+format(results[name]['fine_relative_error'],'.4f'))
        ax.set_ylabel('y / cell size');ax.set_xticks([])
    ax=axs[-1];x=np.arange(NX+1)
    ax.plot(x,target[NX+1:],'k--',label='achieved macro target (top)')
    ax.plot(x,desired[NX+1:],color='gray',linestyle=':',label='requested arch (top)')
    for name in methods:ax.plot(x,results[name]['_fine_profile'][NX+1:],label=name.replace('_',' '))
    ax.set_xlabel('x / cell size');ax.set_ylabel('vertical displacement');ax.legend(fontsize=8,ncol=2)
    fig.savefig(ROOT/'assemblies.png',dpi=160);plt.close(fig)
    names={'nearest_property':'Nearest property','graph_multistart_icm':'Graph selection (ICM)',
           'deterministic_adjoint_top8':'Numerical repair: top 8',
           'deterministic_adjoint_trust_region':'Numerical repair: constrained',
           'llm_feedback_batch':'LLM-guided repair'}
    colors=dict(zip(methods,['#777777','#0072B2','#009E73','#E69F00','#CC79A7']))
    fig,axs=plt.subplots(2,2,figsize=(16,9),constrained_layout=True)
    values=[100*results[k]['fine_relative_error'] for k in methods]
    ax=axs[0,0];bars=ax.barh([names.get(k,k) for k in methods],values,color=[colors[k] for k in methods])
    ax.invert_yaxis();ax.set_xlim(0,max(values)*1.22);ax.set_xlabel('Full-geometry displacement error (%)')
    ax.set_title('One target; lower error is better')
    for bar,val in zip(bars,values):ax.text(val+.3,bar.get_y()+bar.get_height()/2,f'{val:.2f}%',va='center')
    best=min(methods,key=lambda k:results[k]['fine_relative_error'])
    ax=axs[0,1];ax.imshow(image_for(g,ids,methods[best]),origin='lower',cmap='Blues',
                        extent=(0,NX,0,NY),interpolation='nearest')
    ax.set_title('Best pilot assembly: '+names.get(best,best));ax.set_xlabel('x / cell size');ax.set_ylabel('y / cell size')
    for ax,offset,title in [(axs[1,0],0,'Bottom-edge response'),(axs[1,1],NX+1,'Top-edge response')]:
        ax.plot(x,target[offset:offset+NX+1],'k--',lw=2,label='Common selection target')
        for name in methods:ax.plot(x,results[name]['_fine_profile'][offset:offset+NX+1],color=colors[name],label=names.get(name,name))
        ax.set_title(title);ax.set_xlabel('x / cell size');ax.set_ylabel('Vertical displacement')
        ax.grid(alpha=.2);ax.legend(fontsize=8,loc='lower center',ncol=2)
    fig.savefig(ROOT/'comparison.png',dpi=160);plt.close(fig)
    keys=['fine_relative_error','macro_relative_error','mean_property_inf_error',
          'mean_geometric_incompatibility','mean_mechanical_incompatibility','volume_fraction',
          'solid_connected_components','fine_equilibrium_residual','fine_solve_seconds']
    with (ROOT/'metrics.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['method']+keys);w.writeheader()
        for name,r in results.items():w.writerow({'method':name,**{k:r[k] for k in keys}})

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('command',choices=['prepare','evaluate']);ap.add_argument('--seed',type=int,default=20261002)
    ap.add_argument('--actions',type=Path);args=ap.parse_args()
    if args.command=='prepare':prepare(args.seed)
    else:evaluate(args.actions)
