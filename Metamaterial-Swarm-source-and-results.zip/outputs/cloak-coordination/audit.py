"""Verify recorded budgets, novelty, numerical integrity, and commitments."""
from pathlib import Path
import json,hashlib
import numpy as np
R=Path(__file__).resolve().parent
prior=json.loads((R/'shared_prior_history.json').read_text());report={}
def key(labels):return hashlib.sha256(np.asarray(labels,dtype=np.int64).tobytes()).hexdigest()[:20]
def assignment(h):
 a=np.array(h['incumbent_labels'],dtype=np.int64)
 for x in h['actions']:a.flat[x['cell']]=x['label']
 return key(a)
for arm in ['numerical','hybrid']:
 s=json.loads((R/arm/'state.json').read_text());assert s['history'][:18]==prior
 fresh=s['history'][18:];seen={assignment(h) for h in prior};seen.add(key(np.load(R/'baseline_labels.npy')))
 for h in fresh:
  assert assignment(h)==h['geometry_key'] and h['geometry_key'] not in seen
  seen.add(h['geometry_key']);assert not h['cached'] and h['eligible'] and h['force_residual']<1e-7
  assert 0<len(h['actions'])<=4 and len({x['cell'] for x in h['actions']})==len(h['actions'])
 for row in s['rounds']:
  n=row['round'];folder=R/arm/f'round{n}';props=folder/'proposals.json';commit=json.loads((folder/'commitment.json').read_text())
  assert hashlib.sha256(props.read_bytes()).hexdigest()==commit['sha256']
  expected=min([row['starting_loss']]+[h['loss'] for h in row['proposals']]);assert expected==row['retained_loss']
 assert len(fresh)==30 and len(s['rounds'])==10
 report[arm]={'new_unique_full_solves':len(fresh),'committed_rounds':len(s['rounds']),'all_passed':True}
for n,digest in json.loads((R/'code_hashes.json').read_text()).items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==digest
(R/'audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
