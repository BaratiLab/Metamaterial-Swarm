"""Summarize only completed rounds, preserving all measured failures."""
from pathlib import Path
import json,csv,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.io import savemat
R=Path(__file__).resolve().parent
base=json.loads((R/'supplied_assignment_result.json').read_text())['fine_loss']
summary={'baseline':base,'arms':{}};rows=[]
fig,ax=plt.subplots(figsize=(8,4.7),constrained_layout=True)
for arm,color,label in [('numerical','#1976a4','Adaptive numerical'),('hybrid','#8c4ab8','Coordinated hybrid')]:
 s=json.loads((R/arm/'state.json').read_text());fresh=s['history'][s['prior_history_count']:]
 summary['arms'][arm]={'evaluations':len(fresh),'rounds':len(s['rounds']),'retained_loss':s['loss'],'relative_reduction':1-s['loss']/base,'unique_designs':len({h['geometry_key'] for h in fresh}),'max_force_residual':max([h['force_residual'] for h in fresh],default=0)}
 xx=[0]+[3*r['round'] for r in s['rounds']];yy=[base]+[r['retained_loss'] for r in s['rounds']]
 ax.plot(xx,100*np.array(yy),'-o',label=label,color=color)
 for h in fresh:
  rows.append({k:h[k] for k in ['arm','round','name','loss','predicted_delta_J','old_J','new_J','eligible','geometry_key','cached','solid_components','volume_fraction','mean_geometry_cost','force_residual','solve_seconds']})
  folder=R/arm/f"round{h['round']}";commit=json.loads((folder/'commitment.json').read_text())
  assert hashlib.sha256((folder/'proposals.json').read_bytes()).hexdigest()==commit['sha256']
 savemat(R/(arm+'_retained_labels.mat'),{'Label':np.array(s['labels'],dtype=np.int64)})
ax.set(xlabel='New full-resolution FEM evaluations per method',ylabel='Masked displacement loss (%)',title='Mechanical cloaking: coordinated hybrid versus numerical search')
ax.grid(alpha=.2);ax.legend();fig.savefig(R/'comparison.png',dpi=200);fig.savefig(R/'comparison.svg');plt.close(fig)
(R/'summary.json').write_text(json.dumps(summary,indent=2))
if rows:
 with (R/'trials.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print(json.dumps(summary,indent=2))
