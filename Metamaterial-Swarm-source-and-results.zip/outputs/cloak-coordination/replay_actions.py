"""Recompute the archived 60 proposals into a new directory."""
from pathlib import Path
import argparse,json
import numpy as np
from cloak_adapter import CloakProblem
from fem_solver import solve,reflect
ap=argparse.ArgumentParser();ap.add_argument('--package',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
out=Path(a.out);assert not out.exists(),'Use a new output directory';out.mkdir(parents=True)
root=Path(__file__).resolve().parent;p=CloakProblem(a.package);records=[]
for arm in ['numerical','hybrid']:
 for n in range(1,11):
  folder=root/arm/f'round{n}';f=json.loads((folder/'feedback.json').read_text());expected=json.loads((folder/'results.json').read_text());props=json.loads((folder/'proposals.json').read_text());p.labels=np.array(f['current_labels'])
  for prop,ref in zip(props,expected):
   labels=p.propose(prop['actions']);phi=p.assemble(labels);u,report=solve(phi[:,:750],out/arm/f'round{n}'/prop['name'])
   loss=p.outside_loss(reflect(u,1500));difference=abs(loss-ref['loss'])
   records.append(dict(arm=arm,round=n,name=prop['name'],loss=loss,archived_loss=ref['loss'],difference=difference,force_residual=report['relative_force_residual']))
   (out/'replay.json').write_text(json.dumps(records,indent=2));print(records[-1],flush=True)
   assert difference<1e-7,'Inspect convergence: replay differs from archived loss'
