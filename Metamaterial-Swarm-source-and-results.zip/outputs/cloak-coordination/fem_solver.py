"""Memory-conscious Q4 reproduction of supplied UCal.m (CA1 only)."""
import sys,time,json,gc
from pathlib import Path
import numpy as np
from numba import njit
from scipy.sparse import bsr_matrix,coo_matrix
from scipy.sparse.linalg import spsolve,cg
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'work/cloak-runtime'))
import pyamg
E0=7e6; EMIN=1e-9; THICKNESS=.01; FA=50*(50*50)**2

def element():
 a=np.array([[12,3,-6,-3],[3,12,3,0],[-6,3,12,-3],[-3,0,-3,12]])
 aa=np.array([[-6,-3,0,3],[-3,-6,-3,-6],[0,-3,-6,3],[3,-6,3,-6]])
 b=np.array([[-4,3,-2,9],[3,-4,-9,4],[-2,-9,-4,-3],[9,4,-3,-4]])
 bb=np.array([[2,-3,4,-9],[-3,2,9,-2],[4,9,2,3],[-9,-2,3,2]])
 return (np.block([[a,aa],[aa.T,a]])+.35*np.block([[b,bb],[bb.T,b]]))/(1-.35**2)/24

@njit(cache=True)
def blocks(phi,ke,fixed):
 ny,nx=phi.shape;nn=(ny+1)*(nx+1)
 ptr=np.zeros(nn+1,np.int32)
 for x in range(nx+1):
  for y in range(ny+1):
   n=x*(ny+1)+y;ptr[n+1]=ptr[n]+(min(nx,x+1)-max(0,x-1)+1)*(min(ny,y+1)-max(0,y-1)+1)
 ix=np.empty(ptr[-1],np.int32);v=np.zeros((ptr[-1],2,2))
 for x in range(nx+1):
  for y in range(ny+1):
   n=x*(ny+1)+y;k=ptr[n]
   for xx in range(max(0,x-1),min(nx,x+1)+1):
    for yy in range(max(0,y-1),min(ny,y+1)+1):
     m=xx*(ny+1)+yy;ix[k]=m
     for ex in range(max(0,max(x,xx)-1),min(nx-1,min(x,xx))+1):
      for ey in range(max(0,max(y,yy)-1),min(ny-1,min(y,yy))+1):
       li=(0 if x==ex else 1) if y==ey+1 else (3 if x==ex else 2)
       lj=(0 if xx==ex else 1) if yy==ey+1 else (3 if xx==ex else 2)
       rho=EMIN/E0+phi[ey,ex]*(1-EMIN/E0)
       for c in range(2):
        for d in range(2):v[k,c,d]+=rho*ke[li*2+c,lj*2+d]
     for c in range(2):
      for d in range(2):
       if fixed[n*2+c] or fixed[m*2+d]:v[k,c,d]=1. if n==m and c==d else 0.
     k+=1
 return ptr,ix,v

def support(nx,ny,half=True):
 nd=2*(nx+1)*(ny+1);fixed=np.zeros(nd,bool)
 if half:
  fixed[2*nx*(ny+1):nd:2]=True
  fixed[ny+1]=True;fixed[2*nx*(ny+1)+ny+1]=True
 else:
  fixed[ny+1]=True;fixed[2*nx*(ny+1)+ny+1]=True
  fixed[nx*(ny+1)+ny]=True;fixed[nx*(ny+1)+ny+1]=True
  fixed[nx*(ny+1):nx*(ny+1)+2*ny+1:2]=True
 return fixed

def force(nx,ny,half=True):
 b=np.zeros(2*(nx+1)*(ny+1));f=FA/(E0**2*THICKNESS)/ny
 b[0:2*(ny+1):2]=f;b[0]=f/2;b[2*ny]=f/2
 if not half:
  b[2*nx*(ny+1)::2]=-f;b[2*nx*(ny+1)]=-f/2;b[-2]=-f/2
 return b

def matrix(phi,half=True):
 ny,nx=phi.shape;fixed=support(nx,ny,half);ke=element()
 t=time.time();ptr,ix,data=blocks(np.ascontiguousarray(phi,dtype=float),ke,fixed)
 print('matrix blocks',len(ix),'seconds',time.time()-t,flush=True)
 return bsr_matrix((data,ix,ptr),shape=(len(fixed),len(fixed))),fixed

def reflect(u,ny):
 a=u.reshape((-1,ny+1,2));right=a[-2::-1].copy();right[:,:,0]*=-1
 return np.concatenate((a,right),axis=0).ravel()

def validate():
 rng=np.random.default_rng(41);half=rng.uniform(.3,1,(12,6));full=np.concatenate((half,half[:,::-1]),1)
 A,fix=matrix(full,False);b=force(12,12,False);b[fix]=0;u=spsolve(A.tocsc(),b)
 H,ff=matrix(half,True);bb=force(6,12,True);bb[ff]=0;v=spsolve(H.tocsc(),bb)
 relative=np.linalg.norm(u-reflect(v,12))/np.linalg.norm(u);assert relative<1e-10,relative
 # Independent element-triplet reference reproducing MATLAB edof ordering.
 rows=[];cols=[];values=[];ke=element()
 for x in range(12):
  for y in range(12):
   nodes=np.array([x*13+y+1,(x+1)*13+y+1,(x+1)*13+y,x*13+y]);ed=(2*nodes[:,None]+np.arange(2)).ravel()
   rows.extend(np.repeat(ed,8));cols.extend(np.tile(ed,8));values.extend((ke*(EMIN/E0+full[y,x]*(1-EMIN/E0))).ravel())
 R=coo_matrix((values,(rows,cols)),shape=A.shape).tocsr();free=np.flatnonzero(~fix)
 diff=R[free][:,free]-A.tocsr()[free][:,free]
 error=np.max(abs(diff.data)) if diff.nnz else 0;assert error<1e-14,error
 return dict(half_vs_full_relative_displacement_error=float(relative),independent_triplet_max_entry_error=float(error))

def solve(phi,out,tol=1e-13,maxiter=500,initial=None,target=None,monitored=None):
 out=Path(out);out.mkdir(parents=True,exist_ok=True)
 ny,nx=phi.shape;A,fixed=matrix(phi,True);nd=A.shape[0]
 b=force(nx,ny,True);b[fixed]=0
 # Symmetric diagonal equilibration preserves original algebraic problem.
 d=1/np.sqrt(A.diagonal());nb=len(A.indptr)-1
 for k in range(nb):
  sl=slice(A.indptr[k],A.indptr[k+1]);nodes=A.indices[sl]
  A.data[sl]*=d[2*k:2*k+2][None,:,None]*d.reshape(-1,2)[nodes,None,:]
 bscaled=b*d
 x=np.repeat(np.arange(nx+1),ny+1)/max(nx,ny);y=np.tile(np.arange(ny+1),nx+1)/max(nx,ny)
 B=np.zeros((nd,3));B[0::2,0]=1;B[1::2,1]=1;B[0::2,2]=y;B[1::2,2]=x;B[fixed]=0;B/=d[:,None]
 print('AMG setup',nd,'DOFs',flush=True);t=time.time()
 ml=pyamg.smoothed_aggregation_solver(A,B=B,symmetry='symmetric',strength=('symmetric',{'theta':.01}),smooth=('jacobi',{'omega':4/3,'degree':1}),max_coarse=300,max_levels=15)
 print('AMG ready',time.time()-t,'complexity',ml.operator_complexity(),flush=True)
 M=ml.aspreconditioner(cycle='V');del B,x,y;gc.collect();hist=[];start=time.time()
 def callback(z):
  k=len(hist)+1
  if k%10==0 or k==1:
   scaled=A@z-bscaled;true=scaled/d
   r=float(np.linalg.norm(true)/np.linalg.norm(b));rr=float(np.linalg.norm(scaled)/np.linalg.norm(bscaled))
   hist.append((k,r,rr));print('iteration',k,'force residual',r,'scaled',rr,'seconds',time.time()-start,flush=True)
  else:hist.append((k,None,None))
 z0=initial/d if initial is not None else None
 z,info=cg(A,bscaled,M=M,x0=z0,tol=tol,atol=0,maxiter=maxiter,callback=callback)
 refinement=[]
 for refinement_pass in range(4):
  residual=bscaled-A@z
  force_res=float(np.linalg.norm(residual/d)/np.linalg.norm(b))
  refinement.append(force_res)
  if force_res<1e-8:break
  correction,correction_info=cg(A,residual,M=M,tol=1e-8,atol=0,maxiter=min(maxiter,200))
  z+=correction
  print('refinement',refinement_pass+1,'previous force residual',force_res,flush=True)

 u=d*z;res=float(np.linalg.norm((A@z-bscaled)/d)/np.linalg.norm(b))
 np.save(out/'half_displacement.npy',u)
 report=dict(info=int(info),refinement_residuals=refinement,iterations=len(hist),relative_force_residual=res,seconds=time.time()-start,
  scaled_relative_residual=float(np.linalg.norm(A@z-bscaled)/np.linalg.norm(bscaled)),history=hist,void_ratio=EMIN/E0,shape=list(phi.shape))
 (out/'solver.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='history'}),flush=True)
 if target is not None:
  full=reflect(u,ny);residual=np.zeros_like(full)
  residual[monitored]=2*(full[monitored]-target[monitored])/np.dot(target[monitored],target[monitored])
  q=residual.reshape((-1,ny+1,2));qh=q[:nx+1].copy();partner=q[nx+1:][::-1].copy();partner[:,:,0]*=-1;qh[:nx]+=partner
  rhs=qh.ravel();rhs[fixed]=0;adj_rhs=rhs*d
  print('Scalar objective adjoint',flush=True)
  za,adj_info=cg(A,adj_rhs,M=M,tol=1e-12,atol=0,maxiter=maxiter)
  for _ in range(3):
   rr=adj_rhs-A@za
   ar=float(np.linalg.norm(rr/d)/max(np.linalg.norm(rhs),1e-30))
   if ar<1e-8:break
   dz,_=cg(A,rr,M=M,tol=1e-12,atol=0,maxiter=maxiter);za+=dz
  lam=za*d
  np.save(out/'half_adjoint.npy',lam)
  gradient=density_gradient(u,lam,phi.shape[1],phi.shape[0],element())
  np.save(out/'density_gradient.npy',gradient)
  report['adjoint_info']=int(adj_info);report['adjoint_relative_residual']=float(np.linalg.norm((A@za-adj_rhs)/d)/max(np.linalg.norm(rhs),1e-30))
  report['fine_loss']=float(np.linalg.norm(full[monitored]-target[monitored])/np.linalg.norm(target[monitored]))
  print('fine loss',report['fine_loss'],'adjoint residual',report['adjoint_relative_residual'],flush=True)
  (out/'solver.json').write_text(json.dumps(report,indent=2))
 return u,report

@njit(cache=True)
def density_gradient(u,lam,nx,ny,ke):
 grad=np.zeros((ny,nx))
 for x in range(nx):
  for y in range(ny):
   ns=np.array([x*(ny+1)+y+1,(x+1)*(ny+1)+y+1,(x+1)*(ny+1)+y,x*(ny+1)+y])
   value=0.
   for i in range(8):
    for j in range(8):value+=lam[2*ns[i//2]+i%2]*ke[i,j]*u[2*ns[j//2]+j%2]
   grad[y,x]=-value*(1-EMIN/E0)
 return grad

if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--validate',action='store_true');ap.add_argument('--full',action='store_true');ap.add_argument('--maxiter',type=int,default=500);args=ap.parse_args()
 if args.validate:print(json.dumps(validate(),indent=2))
 if args.full:
  sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'cloak-review'))
  from cloak_adapter import CloakProblem
  p=CloakProblem('/Users/amirbaratifarimani/Downloads/Agent_Meta');phi=p.assemble(p.labels);del p.data['ShapeSpace'];gc.collect()
  u,report=solve(phi[:,:750],'work/cloak-experiment/baseline',maxiter=args.maxiter)
  loss=p.outside_loss(reflect(u,1500));print('SUPPLIED LABEL LOSS',loss,flush=True)
  report['fine_loss']=loss;Path('work/cloak-experiment/baseline/result.json').write_text(json.dumps(report,indent=2))
