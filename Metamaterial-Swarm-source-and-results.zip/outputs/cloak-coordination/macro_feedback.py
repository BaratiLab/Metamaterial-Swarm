"""Homogenized proposal scores; fine FEM remains the only measured objective.
No full-geometry sensitivity claim is made by this module.
"""
from pathlib import Path
import sys
import numpy as np
from scipy.sparse.linalg import splu
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'metamaterial-selector'))
import benchmark as old
from fem_solver import FA,E0,THICKNESS

def model(p,labels):
 C=np.zeros((30,30,3,3));iso=old.CSOLID
 origin=old.homogenize(p.data['OriginCell'])
 for y in range(30):
  for x in range(30):
   kind=p.indicator[29-y,x] # storedIndicator row is vertically inverted by Assemble.
   if kind==2:C[y,x]=origin
   elif kind==0:C[y,x]=iso*(1e-9/7e6)
   else:
    row=27-y;col=x-2 if x<15 else 27-x
    i=row*13+col;k=int(labels[row,col]);prop=p.data['PropertySpace'][p.candidates[i,k]-1,:4]
    C[y,x]=old.tensor(prop)
 return C

def score(p,labels,C_override=None):
 C=model(p,labels) if C_override is None else C_override;mesh=old.Mesh(30,30);K=mesh.assemble(C.reshape(-1,3,3))
 # Row-fast Python mesh: y increases with array row; reverse physical uy sign.
 fixed=np.unique(np.r_[2*(np.arange(31)*31+15),2*(15*31+np.array([0,15,30]))+1])
 free=np.setdiff1d(np.arange(mesh.ndof),fixed);f=np.zeros(mesh.ndof)
 f[2*np.arange(31)*31]=FA/(E0**2*THICKNESS)/30
 f[2*(np.arange(31)*31+30)]=-FA/(E0**2*THICKNESS)/30
 f[[0,2*30*31]]*=.5;f[[60,2*(30*31+30)]]*=.5
 f[fixed]=0;lu=splu(K[free][:,free]);u=np.zeros(mesh.ndof);u[free]=lu.solve(f[free])
 fine=p.target.reshape(1501,1501,2);target=fine[::50,::50].transpose(1,0,2).copy();target[:,:,1]*=-1;target=target.ravel()
 interest=p.data['Interest'].astype(bool);node=interest[np.r_[np.arange(1500),1499]][:,np.r_[np.arange(1500),1499]]
 mask=np.repeat(node[::50,::50].ravel(order='C'),2)
 # Void macro stiffness can produce unconstrained modes; monitored exterior stays physical.
 residual=np.zeros_like(u);residual[mask]=u[mask]-target[mask];scale=target[mask]@target[mask]
 J=float(residual@residual/scale);rhs=2*residual/scale;lam=np.zeros_like(u);lam[free]=lu.solve(rhs[free],trans='T')
 ue=u[mesh.edof];le=lam[mesh.edof]
 eu=np.einsum('gai,ei->ega',mesh.bs,ue);el=np.einsum('gai,ei->ega',mesh.bs,le)
 grad=-np.einsum('ega,egb->eab',el,eu)*mesh.det
 return J,grad.reshape(30,30,3,3),float(np.linalg.norm((K@u-f)[free])/max(np.linalg.norm(f),1e-30))

def candidate_scores(p,labels,fine_loss):
 J,grad,_=score(p,labels);res={}
 for i in np.flatnonzero(p.active.ravel(order='C')):
  row,col=divmod(int(i),13);k0=int(labels[row,col]);c0=old.tensor(p.data['PropertySpace'][p.candidates[i,k0]-1,:4])
  y=27-row;x=col+2;gg=grad[y,x]+grad[y,29-x]
  for k in range(15):
   if k==k0:continue
   cc=old.tensor(p.data['PropertySpace'][p.candidates[i,k]-1,:4]);res[(int(i),k)]=float(np.sum(gg*(cc-c0))*fine_loss**2/max(J,1e-30))
 return res,J
