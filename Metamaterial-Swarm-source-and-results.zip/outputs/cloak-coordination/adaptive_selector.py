"""Deterministic adaptive scalar-adjoint portfolio; never calls FEM.

Exploratory defaults fixed before outcomes: per-cell pixel fraction .20,
aggregate pixel budget .40, <=4 swaps, gain trust cap .20*J. Three policies
are singleton, a bounded combinatorial trust search, and diverse beam search.
The trust search uses a finite candidate beam rather than requiring a MILP
package. All ranking uses supplied scalar/geometry evidence only. No random
numbers are used (equivalent fixed seed 20261016).
"""
import math
import statistics


def _flat(labels):
    if hasattr(labels, 'tolist'):
        labels = labels.tolist()
    return tuple(int(x) for row in labels for x in row)


def _assignment(labels, actions):
    a = list(labels)
    for x in actions:
        a[int(x['cell'])] = int(x['label'])
    return tuple(a)


def _finite(x, default=0.):
    try:
        y = float(x)
        return y if math.isfinite(y) else default
    except (TypeError, ValueError):
        return default


def propose(feedback, history):
    """Return three committed-ready proposals; inputs are never modified.

    history entries carry incumbent_labels, actions, old_J, new_J,
    predicted_delta_J and eligible. Loss is epsilon; score deltas use J=eps².
    Duplicate suppression compares full label assignments, not action strings.
    A no-op is returned only when three distinct valid proposals do not exist.
    """
    loss = _finite(feedback.get('loss'), float('nan'))
    if not math.isfinite(loss) or loss < 0:
        raise ValueError('loss must be finite and nonnegative')
    J = max(loss * loss, 1e-30)
    labels = _flat(feedback['current_labels'])
    ratios, recent = [], []
    seen = {labels}
    for h in history:
        old = _finite(h.get('old_J'), float('nan'))
        new = _finite(h.get('new_J'), float('nan'))
        pred = _finite(h.get('predicted_delta_J'))
        if pred != 0 and math.isfinite(old) and math.isfinite(new):
            rho = (old - new) / (-pred)
            if math.isfinite(rho):
                ratios.append(rho)
                recent.append((rho, bool(h.get('eligible', True) and old>new)))
        if h.get('incumbent_labels') is not None:
            seen.add(_assignment(_flat(h['incumbent_labels']), h.get('actions', [])))
    calibration = min(2., max(-2., statistics.median(ratios[-6:]))) if ratios else .25
    if abs(calibration)<.02: calibration=.02 if calibration>=0 else -.02
    # Adapt only from already revealed history; recent unsuccessful batches shrink.
    tail = [(r/calibration if success and math.isfinite(r) else -1.) for r,success in recent[-3:]]
    failures = sum(r < .1 for r in tail)
    successes = sum(r > .75 for r in tail)
    multiplier = max(.25, min(1.5, .5 ** failures * 1.25 ** successes))
    pixel_limit = .20 * multiplier
    pixel_budget = .40 * multiplier
    max_swaps = max(1, min(4, 4 // (2 ** min(failures, 2))))
    eta = max(.025, min(.40, .20 * multiplier))
    options = []
    for raw in feedback.get('options', []):
        try:
            cell, label = int(raw['cell']), int(raw['label'])
            if cell != raw['cell'] or label != raw['label']:
                continue
            delta = float(raw['delta_J'])
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
        pixels = _finite(raw.get('pixel_change_fraction'), 1.)
        if (not 0 <= cell < len(labels) or not 0 <= label < 15 or
                label == labels[cell] or not math.isfinite(delta) or
                not 0 <= pixels <= pixel_limit):
            continue
        geo = max(0., _finite(raw.get('geometry_change')))
        prop = max(0., _finite(raw.get('property_mismatch')))
        # Saturation prevents extreme near-void scores dominating all priorities.
        gain = max(-.5 * J, min(.5 * J, -delta * calibration))
        penalty = J * (.000002 * pixels / .20 + .000002 * min(geo, 5.) + .0000002 * min(prop, 5.))
        options.append(dict(cell=cell, label=label, raw=delta, gain=gain,
                            pixel=pixels, geo=geo, utility=gain-penalty))
    options.sort(key=lambda o: (-o['utility'], o['pixel'], o['cell'], o['label']))
    unique = {}
    for o in options:
        unique.setdefault((o['cell'], o['label']), o)
    options = list(unique.values())
    selected = []
    config = ('calibration=%.6g; pixel_limit=%.4g; aggregate_pixel_budget=%.4g; '
              'max_swaps=%d; calibrated_gain_cap=%.4g*J; deterministic_seed=20261016'
              % (calibration, pixel_limit, pixel_budget, max_swaps, eta))

    def actions(batch):
        return [{'cell': o['cell'], 'label': o['label']} for o in batch]

    def fresh(batch):
        return bool(batch) and _assignment(labels, actions(batch)) not in seen

    def commit(name, batch, reason):
        aa = actions(batch)
        seen.add(_assignment(labels, aa))
        selected.append(dict(name=name, actions=aa, reason=reason+'; '+config))

    singles = [o for o in options if o['gain'] > 0 and fresh([o])]
    if singles:
        # The single swap is an exploratory finite-step calibration probe, so
        # it may exceed the aggregate *predicted gain* cap applied to batches.
        commit('adaptive_singleton', [singles[0]], 'Finite-step calibration singleton; predicted gain saturated at .5*J')
    else:
        fallback = next((o for o in options if fresh([o])), None)
        commit('adaptive_singleton', [fallback] if fallback else [], 'No improving eligible singleton; finite-score fallback or no-op')

    # Diverse candidate pool: best global options plus low-pixel alternatives.
    pool = options[:64]
    keys = {(o['cell'], o['label']) for o in pool}
    for o in sorted(options, key=lambda a: (a['pixel'], -a['utility'], a['cell'], a['label']))[:32]:
        if (o['cell'], o['label']) not in keys:
            pool.append(o); keys.add((o['cell'], o['label']))
    states = [()]
    batches = []
    for depth in range(max_swaps):
        expanded = []
        for ids in states:
            cells = {pool[k]['cell'] for k in ids}
            for k in range(ids[-1]+1 if ids else 0, len(pool)):
                o = pool[k]
                if o['cell'] in cells:
                    continue
                new = ids+(k,)
                batch = [pool[z] for z in new]
                if sum(q['pixel'] for q in batch) > pixel_budget:
                    continue
                utility = sum(q['utility'] for q in batch)
                expanded.append((utility, new))
                if fresh(batch):
                    batches.append((utility, batch))
        expanded.sort(key=lambda z: (-z[0], z[1]))
        states = [z[1] for z in expanded[:64]]
    # A scalar surrogate cannot model cross-swap response interactions: only
    # exact assembly validation after commitment decides feasibility/improvement.
    trusted = [(v, b) for v, b in batches if
               0 < sum(o['gain'] for o in b) <= eta * J and
               calibration * sum(o['raw'] for o in b) < 0]
    trusted.sort(key=lambda z: (-z[0], len(z[1]), tuple((o['cell'], o['label']) for o in z[1])))
    best = next((b for _, b in trusted if fresh(b)), None)
    if best is None:
        best = next(([o] for o in options if fresh([o])), [])
    commit('adaptive_trust_combination', best, 'Bounded combinatorial beam approximation to binary trust selection; exact geometry validation pending')
    # Diverse beam search discounts concentration of utility in one large swap
    # and favors small physical edits. Slightly adverse partners may enter pool.
    diverse = []
    for utility, batch in batches:
        if fresh(batch):
            rank = utility - .10*max(abs(o['gain']) for o in batch) - J*.000001*sum(o['pixel'] for o in batch)
            diverse.append((rank, batch))
    diverse.sort(key=lambda z: (-z[0], len(z[1]), tuple((o['cell'], o['label']) for o in z[1])))
    best = next((b for _, b in diverse if fresh(b)), None)
    if best is None:
        best = next(([o] for o in options if fresh([o])), [])
    commit('adaptive_diverse_beam', best, 'Diverse small-combination beam, width64 and pool<=96, concentration penalty; no FEM lookahead')
    return selected


if __name__ == '__main__':
    # Synthetic-only checks: basic shape, bounded changes, uniqueness, adaptation,
    # nonfinite evidence, duplicate assignment suppression and empty input.
    base = [[0]*13 for _ in range(26)]
    opts = [dict(cell=i,label=1,delta_J=-.0001*(i+1),pixel_change_fraction=.01,
                 property_mismatch=.02,geometry_change=0,volume_fraction=.4)
            for i in range(12)]
    f = dict(loss=.1,current_labels=base,options=opts)
    r = propose(f, [])
    assert len(r)==3 and all(len(x['actions'])<=4 for x in r)
    assert len({_assignment(_flat(base),x['actions']) for x in r})==3
    h = [dict(incumbent_labels=base,actions=r[0]['actions'],old_J=.01,new_J=.011,
              predicted_delta_J=-.001,eligible=True)]
    rr=propose(f,h)
    assert all(len(x['actions'])<=2 for x in rr)
    assert all(_assignment(_flat(base), x['actions']) != _assignment(_flat(base),r[0]['actions']) for x in rr)
    assert propose(f,[])==r
    f['options']=opts+[dict(cell=15,label=1,delta_J=float('nan'),pixel_change_fraction=.001)]
    assert all(a['cell']!=15 for x in propose(f,[]) for a in x['actions'])
    assert len(propose(dict(loss=.1,current_labels=base,options=[]),[]))==3
    print('synthetic adaptive selector checks passed')
