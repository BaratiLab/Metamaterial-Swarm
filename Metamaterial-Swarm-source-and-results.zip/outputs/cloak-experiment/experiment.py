"""Independent-arm, matched-budget cloak proposal benchmark.
No action is evaluated before every action in its arm/round is committed.
"""
from pathlib import Path
import sys,json,hashlib,subprocess,time,gc,os
import numpy as np
from scipy.ndimage import label as components
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'cloak-review'))
from cloak_adapter import CloakProblem
from fem_solver import solve,reflect
from adaptive_selector import propose
WORK=Path(os.environ.get('CLOAK_WORK_DIR',str(HERE.parents[1]/'work/cloak-experiment')))
SOURCE=os.environ.get('CLOAK_PACKAGE_DIR','/Users/amirbaratifarimani/Downloads/Agent_Meta')
PYTHON=sys.executable

def save(path,data):path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2,allow_nan=False))
def key(labels):return hashlib.sha256(np.asarray(labels,dtype=np.int64).tobytes()).hexdigest()[:20]
def load_arm(arm):
 p=HERE/arm/'state.json'
 if p.exists():return json.loads(p.read_text())
 labels=np.load(HERE/'baseline_labels.npy').tolist();base=json.loads((HERE/'supplied_assignment_result.json').read_text())
 return dict(arm=arm,labels=labels,loss=base['fine_loss'],history=[],rounds=[])

def edge_cost(a,b,vertical=False):
 aa=a[-1,:] if vertical else a[:,-1];bb=b[0,:] if vertical else b[:,0]
 return float(np.sum(aa!=bb)/max(np.sum((aa|bb)>0),1))
def geometry_metric(phi):
 total=0.
 for y in range(30):
  for x in range(30):
   a=phi[y*50:(y+1)*50,x*50:(x+1)*50]
   if x<29:total+=edge_cost(a,phi[y*50:(y+1)*50,(x+1)*50:(x+2)*50])
   if y<29:total+=edge_cost(a,phi[(y+1)*50:(y+2)*50,x*50:(x+1)*50],True)
 return total/1740

def prepare(arm,roundnum):
 state=load_arm(arm);assert len(state['rounds'])+1==roundnum,'Prepare only the next unassessed round';labels=np.array(state['labels']);p=CloakProblem(SOURCE);phi=p.assemble(labels)
 cache=WORK/'cache'/key(labels);cache.mkdir(parents=True,exist_ok=True)
 if not (cache/'solver.json').exists():
  base=WORK/'verified_baseline'
  if np.array_equal(labels,np.load(HERE/'baseline_labels.npy')):
   import shutil
   for n in ['solver.json','half_displacement.npy']:
    shutil.copy2(base/n,cache/n)
  else:raise RuntimeError('Incumbent must have a cached solve')
 from macro_feedback import candidate_scores
 scores,macro_J=candidate_scores(p,labels,state['loss']);options=[]
 for i in np.flatnonzero(p.active.ravel(order='C')):
  y,x=divmod(int(i),13);old=int(labels[y,x]);oldg=p.data['ShapeSpace'][:,:,p.candidates[i,old]-1]
  for k in range(15):
   if k==old:continue
   g=p.data['ShapeSpace'][:,:,p.candidates[i,k]-1]
   delta=scores[(int(i),k)]
   # Exact single-swap whole-assembly geometry-cost change, recomputed locally.
   left=(27-y,x+2);right=(27-y,27-x);changes={left:g[::-1,:],right:g[::-1,::-1]};edges=set()
   for yy,xx in changes:
    for dy,dx in [(0,1),(0,-1),(1,0),(-1,0)]:
     yn,xn=yy+dy,xx+dx
     if 0<=yn<30 and 0<=xn<30:edges.add(tuple(sorted(((yy,xx),(yn,xn)))))
   dg=0.
   for aa,bb in edges:
    ya,xa=aa;yb,xb=bb
    a=phi[ya*50:(ya+1)*50,xa*50:(xa+1)*50];b=phi[yb*50:(yb+1)*50,xb*50:(xb+1)*50]
    dg+=edge_cost(changes.get(aa,a),changes.get(bb,b),ya!=yb)-edge_cost(a,b,ya!=yb)
   prop=p.data['PropertySpace'][p.candidates[i,k]-1]
   options.append(dict(cell=int(i),row=y,column=x,label=k,current_label=old,delta_J=delta,
     pixel_change_fraction=float(np.mean(g!=oldg)),property_mismatch=float(p.data['Uenergy'][i,k]),
     geometry_change=dg/1740,volume_fraction=float(prop[4]),matlab_dataset_id=int(p.candidates[i,k])))
 feedback=dict(arm=arm,round=roundnum,loss=state['loss'],current_labels=labels.tolist(),options=options,
  protocol='Independent arm; <=4 distinct-cell swaps; three committed proposals per round; homogenized macro adjoint scores scaled by incumbent fine_J/macro_J; only measured objective uses exact full-resolution FEM; no candidate FEM lookahead. All original label assignments allowed; connectivity/VF/interfaces reported, not additional hard constraints.',
  feedback_model='homogenized 30x30 orthotropic Q4 surrogate; finite labels; macro adjoint, not full-geometry adjoint',macro_relative_error=float(np.sqrt(macro_J)),
  incumbent_geometry_mean=geometry_metric(phi),incumbent_volume_fraction=float(phi.mean()),
  history=state['history'])
 folder=HERE/arm/f'round{roundnum}';folder.mkdir(parents=True,exist_ok=True);save(folder/'feedback.json',feedback)
 if arm=='numerical':
  props=propose(feedback,state['history']);save(folder/'proposals.json',props)
  print('Numerical proposals committed',[(v['name'],v['actions']) for v in props],flush=True)
 print('Feedback ready',arm,roundnum,'error',state['loss'],'negative scores',sum(o['delta_J']<0 for o in options),'range',min(o['delta_J'] for o in options),max(o['delta_J'] for o in options),flush=True)

def solve_job(cache,adjoint=False):
 cmd=[PYTHON,str(HERE/'experiment.py'),'solve',str(cache)]
 if adjoint:cmd.append('--adjoint')
 result=subprocess.run(cmd,env={**__import__('os').environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'})
 if result.returncode:raise RuntimeError('FEM job failed')

def evaluate(arm,roundnum):
 state=load_arm(arm);assert len(state['rounds'])+1==roundnum,'Evaluate only next unassessed round';folder=HERE/arm/f'round{roundnum}';feedback=json.loads((folder/'feedback.json').read_text());props=json.loads((folder/'proposals.json').read_text());assert len(props)==3
 assert not (folder/'results.json').exists(),'Round already evaluated'
 labels=np.array(state['labels']);p=CloakProblem(SOURCE);p.labels=labels.copy();committed=[];lookup={(o['cell'],o['label']):o for o in feedback['options']}
 for prop in props:
  actions=prop['actions'];assert len(actions)<=4;lab=p.propose(actions)
  assert all((a['cell'],a['label']) in lookup for a in actions)
  committed.append((prop,lab,key(lab)))
 save(folder/'commitment.json',dict(sha256=hashlib.sha256((folder/'proposals.json').read_bytes()).hexdigest(),geometries=[v[2] for v in committed],committed_unix=time.time()))
 np.save(WORK/'target.npy',p.target);np.save(WORK/'monitored.npy',p.monitored)
 best=state['loss'];bestlabels=labels.copy();records=[]
 for prop,lab,cachekey in committed:
  cache=WORK/'cache'/cachekey;cache.mkdir(parents=True,exist_ok=True);phi=p.assemble(lab)
  nc=int(components(phi)[1]);volume=float(phi.mean());geo=geometry_metric(phi)
  if not (cache/'solver.json').exists():
   np.save(cache/'half_phi.npy',phi[:,:750]);solve_job(cache)
   cached=False
  else:cached=True
  result=json.loads((cache/'solver.json').read_text());u=np.load(cache/'half_displacement.npy');loss=p.outside_loss(reflect(u,1500))
  eligible=bool(np.isfinite(loss) and result['relative_force_residual']<1e-7)
  record=dict(arm=arm,round=roundnum,name=prop['name'],actions=prop['actions'],reason=prop.get('reason',''),
   incumbent_labels=labels.tolist(),old_J=state['loss']**2,new_J=loss**2,loss=loss,
   predicted_delta_J=sum(lookup[(a['cell'],a['label'])]['delta_J'] for a in prop['actions']),
   eligible=eligible,geometry_key=cachekey,cached=cached,solid_components=nc,volume_fraction=volume,mean_geometry_cost=geo,
   force_residual=result['relative_force_residual'],solve_seconds=result['seconds'])
  records.append(record);save(folder/'partial_results.json',records)
  print('OUTCOME',arm,roundnum,prop['name'],'loss',loss,'residual',result['relative_force_residual'],'eligible',eligible,'cached',cached,flush=True)
  if eligible and loss<best:best=loss;bestlabels=lab.copy()
 state['history']+=records;state['rounds'].append(dict(round=roundnum,starting_loss=state['loss'],retained_loss=best,proposals=records));state['loss']=best;state['labels']=bestlabels.tolist()
 save(folder/'results.json',records);save(HERE/arm/'state.json',state)
 print('RETAINED',arm,roundnum,best,flush=True)

def solve_cache(path,adjoint=False):
 cache=Path(path);phi=np.load(cache/'half_phi.npy');initial=np.load(cache/'half_displacement.npy') if (cache/'half_displacement.npy').exists() else np.load(WORK/'verified_baseline/half_displacement.npy')
 target=np.load(WORK/'target.npy') if adjoint else None;monitor=np.load(WORK/'monitored.npy') if adjoint else None
 u,result=solve(phi,cache,initial=initial,target=target,monitored=monitor)

if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':prepare(sys.argv[2],int(sys.argv[3]))
 elif action=='evaluate':evaluate(sys.argv[2],int(sys.argv[3]))
 elif action=='solve':solve_cache(sys.argv[2],'--adjoint' in sys.argv)
