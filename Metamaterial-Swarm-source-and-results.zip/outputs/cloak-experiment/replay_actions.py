"""Re-evaluate archived literal actions in a NEW output directory.
Usage: python replay_actions.py --package /path/Agent_Meta --out /path/fresh-replay
This performs 18 full-resolution candidate solves and can take tens of minutes.
"""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from cloak_adapter import CloakProblem
from fem_solver import solve,reflect

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--package',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();out=Path(a.out)
 if out.exists():raise FileExistsError('Choose a new directory; archived evidence is never overwritten.')
 out.mkdir(parents=True);root=Path(__file__).resolve().parent;p=CloakProblem(a.package);records=[]
 for arm in ['numerical','swarm']:
  for n in [1,2,3]:
   folder=root/arm/f'round{n}';feedback=json.loads((folder/'feedback.json').read_text());expected=json.loads((folder/'results.json').read_text());props=json.loads((folder/'proposals.json').read_text());p.labels=np.array(feedback['current_labels'])
   for prop,reference in zip(props,expected):
    labels=p.propose(prop['actions']);phi=p.assemble(labels);path=out/arm/f'round{n}'/prop['name'];u,report=solve(phi[:,:750],path)
    loss=p.outside_loss(reflect(u,1500));delta=abs(loss-reference['loss']);record=dict(arm=arm,round=n,name=prop['name'],loss=loss,archived_loss=reference['loss'],absolute_difference=delta,force_residual=report['relative_force_residual']);records.append(record);print(record,flush=True)
    (out/'replay.json').write_text(json.dumps(records,indent=2));assert delta<1e-7,'Replay loss disagrees; inspect solver convergence.'
if __name__=='__main__':main()
