from pathlib import Path
import sys,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parents[1]/'work/cloak-experiment'
sys.path[:0]=[str(ROOT),str(ROOT.parent/'cloak-review')]
from cloak_adapter import CloakProblem
from fem_solver import reflect
from experiment import key
p=CloakProblem('/Users/amirbaratifarimani/Downloads/Agent_Meta');target=p.target.reshape(1501,1501,2).transpose(1,0,2);mask=p.monitored.reshape(1501,1501,2)[:,:,0].T
amplitude=np.sqrt(np.sum(target[mask]**2)/mask.sum());cases=[('Supplied assignment',WORK/'verified_baseline/half_displacement.npy')]
for arm,title in [('numerical','Adaptive numerical'),('swarm','Swarm')]:
 labels=np.array(json.loads((ROOT/arm/'state.json').read_text())['labels']);cases.append((title,WORK/'cache'/key(labels)/'half_displacement.npy'))
fields=[];losses=[]
for title,path in cases:
 u=reflect(np.load(path),1500);field=u.reshape(1501,1501,2).transpose(1,0,2);err=np.linalg.norm(field-target,axis=2)/amplitude*100
 fields.append(np.ma.array(err,mask=~mask));losses.append(p.outside_loss(u))
vmax=float(np.percentile(np.concatenate([v.compressed() for v in fields]),99))
fig,axs=plt.subplots(1,3,figsize=(13,4.5),constrained_layout=True)
for ax,(title,_),field,loss in zip(axs,cases,fields,losses):
 im=ax.imshow(field,origin='upper',cmap='magma',vmin=0,vmax=vmax,interpolation='nearest');ax.axis('off');ax.set_title(f'{title}\nGlobal loss {loss*100:.4f}%')
cb=fig.colorbar(im,ax=axs,shrink=.8,pad=.02);cb.set_label('Pointwise error / target RMS amplitude (%)\nCommon scale; values above 99th percentile saturated')
fig.suptitle('Outside-region displacement mismatch at original pixel resolution',weight='bold')
fig.savefig(ROOT/'outside_error_fields.png',dpi=220,bbox_inches='tight')
