from pathlib import Path
import sys,json
import numpy as np
from numba import njit
sys.path[:0]=[str(Path(__file__).resolve().parent),str(Path(__file__).resolve().parents[1]/'cloak-review')]
from fem_solver import element,force,support,E0,EMIN
from cloak_adapter import CloakProblem
@njit(cache=True)
def internal_force(phi,u,ke):
 ny,nx=phi.shape;f=np.zeros(2*(nx+1)*(ny+1))
 for x in range(nx):
  for y in range(ny):
   nodes=np.array([x*(ny+1)+y+1,(x+1)*(ny+1)+y+1,(x+1)*(ny+1)+y,x*(ny+1)+y])
   rho=EMIN/E0+phi[y,x]*(1-EMIN/E0)
   for i in range(8):
    total=0.
    for j in range(8):total+=ke[i,j]*u[2*nodes[j//2]+j%2]
    f[2*nodes[i//2]+i%2]+=rho*total
 return f

def check(phi,u):
 ny,nx=phi.shape;f=force(nx,ny);fixed=support(nx,ny);r=internal_force(phi,u,element())-f
 reactions=np.zeros_like(r);reactions[fixed]=r[fixed]
 balance=(f+reactions).reshape(-1,2).sum(axis=0)
 return dict(free_residual=float(np.linalg.norm(r[~fixed])/np.linalg.norm(f)),
   relative_net_force_imbalance=float(np.linalg.norm(balance)/np.sum(abs(f))),
   half_support_reaction_x=float(reactions[0::2].sum()),half_support_reaction_y=float(reactions[1::2].sum()))
if __name__=='__main__':
 root=Path(__file__).resolve().parent;work=root.parents[1]/'work/cloak-experiment';p=CloakProblem('/Users/amirbaratifarimani/Downloads/Agent_Meta');report={}
 cases=[('supplied',p.labels,work/'verified_baseline/half_displacement.npy')]
 from experiment import key
 for arm in ['numerical','swarm']:
  f=root/arm/'state.json'
  if f.exists():
   labels=np.array(json.loads(f.read_text())['labels']);cases.append((arm,labels,work/'cache'/key(labels)/'half_displacement.npy'))
 for name,labels,path in cases:
  report[name]=check(p.assemble(labels)[:,:750],np.load(path));assert report[name]['free_residual']<1e-7;assert report[name]['relative_net_force_imbalance']<1e-7
 (root/'force_balance.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
