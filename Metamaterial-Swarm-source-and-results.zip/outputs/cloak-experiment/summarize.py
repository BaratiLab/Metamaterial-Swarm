from pathlib import Path
import json,csv,hashlib,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
base=json.loads((ROOT/'supplied_assignment_result.json').read_text())
results=[];arms={}
for arm in ['numerical','swarm']:
 p=ROOT/arm/'state.json'
 if p.exists():
  arms[arm]=json.loads(p.read_text());results+=arms[arm]['history']
if results:
 columns=['arm','round','name','loss','old_J','new_J','predicted_delta_J','eligible','cached','solid_components','volume_fraction','mean_geometry_cost','force_residual','solve_seconds','geometry_key']
 with (ROOT/'trials.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore');w.writeheader();w.writerows(results)
summary=dict(baseline=base['fine_loss'],reference_target_error=json.loads((ROOT/'reference_check.json').read_text())['reference_target_relative_error'],arms={})
for arm,state in arms.items():
 summary['arms'][arm]=dict(retained_loss=state['loss'],relative_reduction_from_baseline=1-state['loss']/base['fine_loss'],rounds=len(state['rounds']),proposal_slots=len(state['history']),unique_assignments=len({h['geometry_key'] for h in state['history']}),new_solves=sum(not h['cached'] for h in state['history']))
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2))
fig,ax=plt.subplots(1,2,figsize=(12,4.8),constrained_layout=True)
for arm,col,label in [('numerical','#245B91','Adaptive numerical'),('swarm','#7753A6','Swarm')]:
 if arm not in arms:continue
 state=arms[arm];x=[0]+[r['round'] for r in state['rounds']];y=[base['fine_loss']]+[r['retained_loss'] for r in state['rounds']]
 ax[0].plot(x,np.array(y)*100,'o-',c=col,label=label,lw=2)
 for h in state['history']:
  ax[1].scatter(-h['predicted_delta_J'],h['old_J']-h['new_J'],c=col,marker='o' if arm=='numerical' else '^',s=50,alpha=.8)
ax[0].set(xlabel='Round',ylabel='Full-resolution masked displacement error (%)',title='Independent trajectories; retain only improvements',xticks=[0,1,2,3]);ax[0].legend();ax[0].grid(alpha=.2)
ax[1].axhline(0,c='gray',lw=1);ax[1].axvline(0,c='gray',lw=1);ax[1].set(xlabel='Predicted reduction in squared error',ylabel='Measured reduction in squared error',title='Homogenized feedback versus exact FEM');ax[1].ticklabel_format(style='sci',axis='both',scilimits=(0,0));ax[1].grid(alpha=.2)
fig.suptitle('Mechanical cloaking: matched proposal budgets on one supplied target',weight='bold')
fig.savefig(ROOT/'comparison.png',dpi=200,bbox_inches='tight');fig.savefig(ROOT/'comparison.svg',bbox_inches='tight');plt.close(fig)
# Full-resolution reconstructed geometries from the saved retained labels.
sys.path.insert(0,str(ROOT.parent/'cloak-review'));from cloak_adapter import CloakProblem
p=CloakProblem('/Users/amirbaratifarimani/Downloads/Agent_Meta');fig,ax=plt.subplots(1,3,figsize=(13,4.7),constrained_layout=True)
for a,name,labels,loss in [(ax[0],'Supplied assignment',p.labels,base['fine_loss'])]+[(ax[j+1],arm,np.array(arms[arm]['labels']),arms[arm]['loss']) for j,arm in enumerate(['numerical','swarm']) if arm in arms]:
 a.imshow(p.assemble(labels),cmap='gray_r',interpolation='nearest')
 from matplotlib.patches import Rectangle
 for row,col in np.argwhere((labels!=p.labels)&p.active):
  for x in [int(col+2),int(27-col)]:a.add_patch(Rectangle((x*50-.5,(27-int(row))*50-.5),50,50,fill=False,edgecolor='#D24848',linewidth=1))
 a.set_title(f'{name}\nerror {loss*100:.4f}%');a.axis('off')
fig.savefig(ROOT/'retained_assemblies.png',dpi=220,bbox_inches='tight');plt.close(fig)
print(json.dumps(summary,indent=2))
