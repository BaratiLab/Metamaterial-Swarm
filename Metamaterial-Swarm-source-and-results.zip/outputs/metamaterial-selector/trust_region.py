"""Commit a stronger deterministic repair comparator before evaluating repairs.

One binary optimization of adjoint estimates with explicit compatibility and
step-size budgets. Budgets were fixed after inspecting shared baseline feedback
and before observing any repair result; they are exploratory, not preregistered.
"""
import json
from pathlib import Path
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint

root=Path(__file__).resolve().parent
d=json.loads((root/'feedback.json').read_text())
budget=.4*d['macro_squared_relative_error']
opts=[o for o in d['ranked_options'] if o['adjoint_predicted_squared_error_change']<0
      and o['graph_energy_change']<.025 and o['geometry_change_sum']<=.3]
gain=-np.array([o['adjoint_predicted_squared_error_change'] for o in opts])
cost=np.array([max(0,o['graph_energy_change']) for o in opts])
cells=sorted({o['cell'] for o in opts})
A=np.array([gain,cost,np.ones(len(opts))]+[[int(o['cell']==c) for o in opts] for c in cells])
upper=np.r_[budget,.08,8,np.ones(len(cells))]
r=milp(-gain,integrality=np.ones(len(opts)),bounds=Bounds(0,1),
       constraints=LinearConstraint(A,np.zeros(len(upper)),upper),options={'time_limit':30})
assert r.success, r.message
chosen=np.flatnonzero(r.x>.5)
out={'selector':'deterministic_adjoint_trust_region',
     'policy':'maximize summed adjoint gain with gain <=40% current squared error, total graph increase <=0.08, <=8 swaps, one label per cell, individual geometry increase <=0.3 and graph increase <0.025',
     'predicted_gain':float(gain[chosen].sum()),'macro_squared_error_budget':budget,
     'graph_cost_sum':float(cost[chosen].sum()),
     'actions':[{'cell':opts[k]['cell'],'to_label':opts[k]['to_label']} for k in chosen]}
(root/'trust_region_actions.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
