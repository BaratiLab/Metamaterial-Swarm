"""Check that the reported ranking is not an artifact of ersatz void stiffness."""
import json
import numpy as np
import benchmark as b

g,p=b.load_library();z=np.load(b.ROOT/'problem.npz')
original=json.loads((b.ROOT/'results.json').read_text())
rows=[]
for method in ['graph_multistart_icm','deterministic_adjoint_top8','llm_feedback_batch']:
    labels=np.array(json.loads((b.ROOT/(method+'_labels.json')).read_text()))
    b.VOID=1e-7
    print('Void sensitivity:',method,flush=True)
    r=b.assess(labels,z['ids'],g,p,z['target'],z['unary'],z['pair'],z['gg'],z['mm'])
    old=original[method]['fine_relative_error'];new=r['fine_relative_error']
    rows.append({'method':method,'void_1e_minus6_error':old,'void_1e_minus7_error':new,
                 'absolute_error_change':abs(old-new),
                 'profile_relative_change':float(np.linalg.norm(np.array(r['_fine_profile'])-original[method]['_fine_profile'])/np.linalg.norm(z['target'])),
                 'fine_equilibrium_residual':r['fine_equilibrium_residual']})
    assert rows[-1]['profile_relative_change']<.002, rows[-1]
b.save_json(b.ROOT/'void_sensitivity.json',rows)
print(json.dumps(rows,indent=2))
