"""Await agent commitments, evaluate, and prepare the next shared round."""
import time
import swarm_benchmark as s

for roundnum in [1,2,3]:
    folder=s.ROOT/f'round{roundnum}'
    started=time.monotonic()
    while not all((folder/f'agent_{name}.json').exists() for name in ['response','interfaces','robust']):
        if time.monotonic()-started>900:raise TimeoutError(f'Round {roundnum}: agent commitments missing')
        time.sleep(1)
    s.evaluate(roundnum)
    if roundnum<3:s.prepare(roundnum+1)
print('All three committed rounds completed',flush=True)
