# Three-round agent swarm experiment

Starting full-geometry error: **4.863%**, using the strongest numerical repair from the original pilot. Final retained error: **3.922%**.

| Round | Starting error | Best eligible agent proposal | Best eligible numerical proposal | Retained choice | Retained error |
|---|---:|---:|---:|---|---:|
| 1 | 4.863% | 3.975% | 4.866% | agent_interfaces | 3.975% |
| 2 | 3.975% | 4.033% | 4.216% | retain_incumbent | 3.975% |
| 3 | 3.975% | 3.922% | 4.216% | agent_interfaces | 3.922% |

## What was tested

Three independent LLM subagents proposed repairs specializing in response matching, interface compatibility, and cautious small changes. Three deterministic numerical policies greedily minimized linearized full-geometry profile error with batch limits of one, four, and eight swaps. Every proposal was restricted to the same original ten candidates per location and at most eight changed cells.

Each round used the same starting assembly for all six proposals. First-order response vectors were computed from the actual 300,000-element assembly using one forward solve and displacement-response adjoints, replacing the original pilot's homogenized feedback. All six literal action files were committed before any candidate outcome was evaluated. Each group received three full-FEM candidate assessments per round: **nine each across three rounds**. There were no hidden candidate-FEM evaluations. Derivative validation on a smaller independent model agreed with finite differences to relative error 3.21e-09.

After each round, the lowest-error eligible assembly was shared as the next incumbent. This is a common-incumbent proposal competition, not two independent optimization trajectories. Both groups could benefit from the other group's accepted proposals. Equal candidate-FEM counts do not equate token costs, selection computation, or wall-clock time.

The numerical round-three proposals repeated round two exactly because the incumbent was unchanged and the numerical policies were fixed. Thus nine numerical assessments covered six unique incumbent/action pairs. The agents adapted their policies using previous outcomes; the numerical policies did not. This limits causal attribution of the gain to LLM reasoning. Separately committed proposer roles are not independent statistical replicates.

Agent proposals included agent-designed numerical searches over the supplied estimates. The interface specialist enumerated small combinations under pixel-change and interface filters, then revised those filters using measured outcomes. Consequently this evaluates a hybrid agent-guided search portfolio, not language-only selection or intrinsic intelligence independently of the search algorithm.

Eligibility required one connected solid component, mean geometric mismatch no greater than 0.20, mean mechanical mismatch no greater than 0.35, and volume fraction within 0.015 of the starting value. Retention additionally required lower measured displacement error. These criteria were specified before the new rounds.

Connectivity means one four-neighbor binary solid component. It does not establish mechanical robustness, buckling resistance, minimum printable feature size, or fabrication reliability.

## Interpretation and limits

The observations above distinguish actual measured assembly performance from each proposal's first-order predicted error. Finite topology changes can invalidate linearized predictions even when infinitesimal derivatives pass validation. The numerical comparator is a fixed three-policy greedy portfolio; it is not a global optimizer or a trained graph neural network. No GNN comparison was run.

This remains one target, one fixed library, and one inherited-model agent team. The exact model snapshot and decoding settings are unavailable. The outcome does not establish statistical superiority, and it cannot be compared directly with the original paper's different dataset, material parameters, and DD-MRF solver.

![Three-round comparison](swarm_comparison.png)

Per-round feedback, actions, action hashes, and complete outcomes are preserved in `round1/`, `round2/`, and `round3/`. `trial_metrics.csv` contains all 18 trials, including rejected ones. `history.json` records acceptance decisions and the final assembly. The original pilot outputs are unchanged.
