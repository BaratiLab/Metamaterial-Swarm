# First selector experiment: October 2, 2026

**The experiment works, but the LLM did not outperform the numerical selectors in this first pilot.** A numerical repair reduced the graph baseline's displacement error by approximately 51%; the LLM repair increased it by approximately 9%.

We downloaded the authors' public [90,245-cell dataset](https://doi.org/10.6084/m9.figshare.17141975.v1), verified its checksums, and built a plane-stress finite-element model of a 4 x 30 cell beam. Every selector used the same target stiffness field and the same ten candidates per cell. The final assembled geometries retained the original 50 x 50 pixels per cell: 300,000 finite elements in each full-geometry assessment.

## Measured results

Lower displacement error is better. The common target is the achieved macro response; error is the displacement-vector norm of the deviation divided by the target norm, measured along both outer edges at cell boundaries.

| Method | Full-geometry error | Macro-model error | Geometric incompatibility | Mechanical incompatibility |
|---|---:|---:|---:|---:|
| Independent nearest-property selection | 20.73% | 2.39% | 0.2510 | 0.2893 |
| Graph selection, 16-start ICM | 9.93% | 4.40% | 0.1355 | 0.2172 |
| Numerical repair, top eight adjoint estimates | **4.86%** | 14.34% | 0.1430 | 0.2510 |
| Numerical repair, constrained adjoint estimates | 8.54% | 3.66% | 0.1378 | 0.2186 |
| LLM-guided repair | 10.82% | 3.73% | 0.1384 | 0.2168 |

All five assembled solid geometries had one four-neighbor connected component. Volume fractions were between 0.6331 and 0.6359. Lower displacement error in the best numerical repair came with increased interface mismatch, so it is not a Pareto improvement across every metric.

The three repair methods started from the identical graph assignment, committed eight candidate changes each, and received one full-geometry assessment each. The LLM was this session's assistant choosing replacements from computed mechanical evidence. Its reasoning and literal selected cell IDs are saved in `llm_actions.json`; this was not an automated API model benchmark. All three action files existed before any repair outcome was evaluated; evaluated action hashes are recorded in `results.json`.

![Measured comparison](comparison.png)

## Interpretation

The macro model and the assembled geometry do not rank the repair methods consistently. The LLM's conservative choices improved the macro error from 4.40% to 3.73%, while worsening the actual assembled response from 9.93% to 10.82%. Conversely, the top-eight numerical batch performed poorly in the macro model but best in the fine model. This is direct evidence that the homogenized feedback was an inadequate guide for these discrete repairs. It does not show that LLM selection is intrinsically incapable of helping.

The result supports keeping full-geometry physics in the evaluation loop. The next experiment should compute repair sensitivities or local-response estimates from the **assembled geometry**, provide identical evidence to numerical and LLM selectors, and test several held-out target profiles with repeated model runs. The useful research contribution would be demonstrably better assembly decisions under physical and manufacturing constraints, rather than language-guided selection alone.

## Checks completed

- Q4 affine patch test and homogeneous periodic-cell test passed.
- Three independent homogenization comparisons agreed with supplied stiffness tensors to relative errors of 0.0003%-0.0006%.
- The adjoint gradient agreed with central finite differences to relative error 1.37e-7.
- Graph-energy single-swap calculations agreed with full recomputation to absolute error below 1e-15.
- Free-DOF equilibrium residuals in all primary fine solves were below 2.4e-10.
- Reducing ersatz void stiffness from 1e-6 to 1e-7 changed graph, best numerical, and LLM displacement errors by less than 0.0022 percentage points; their ranking was unchanged. This checks sensitivity to regularization, not fabrication or mesh convergence.

## Limits of the conclusion

This is one target and one LLM decision batch. It demonstrates implementation feasibility and provides a negative first comparison for the LLM strategy. It cannot establish statistical superiority, generalization, or model-independent performance.

It is also **not an exact reproduction of the 2020 paper**. The public dataset uses constituent Poisson ratio 0.35 and 90,245 geometries, versus 0.49 and approximately 250,000 in the paper. The continuous macro parameterization and stated loading conditions are specific to this pilot. The graph solver is ICM, not the paper's DD-MRF. Consequently, even the 4.86% result cannot be claimed to beat the paper's reported 6% beam result.

The continuous macro optimization reached its 100-iteration limit with 0.87% error relative to the requested arch; that residual is excluded from the primary selector comparison by using the achieved response as the common target. No external LLM latency or token cost was measured. Exact model snapshot and decoding settings were unavailable for this in-session decision.

See `README.md` for the full protocol and run commands, `metrics.csv` for the measured table, `validation.json` and `void_sensitivity.json` for checks, and `benchmark.py` for the implementation.
