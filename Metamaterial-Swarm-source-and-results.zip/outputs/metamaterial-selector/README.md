# Metamaterial selector: real-data pilot

Read `RESULTS.md` for the first measured outcome: the LLM batch did not improve the graph baseline; a numerical repair did. These are single-target pilot findings.

A subsequent three-agent, three-round experiment is recorded in `swarm/RESULTS.md`. Its final retained error is 3.922%, compared with the initial strongest numerical repair's 4.863%. It uses assembled-geometry feedback and a common-incumbent proposal competition. Numerical policies remain fixed while agents adapt; no GNN comparison or general superiority claim is made. The original pilot outputs are preserved.

This experiment tests the **selection stage** of a heterogeneous metamaterial design workflow. Every selector receives the same optimized target stiffness field and the same ten candidate geometries per macro cell. No VAE is retrained.

## Data and attribution

Source: Liwei Wang, Jagannadh Boddapati, Ke Liu, Ping Zhu, Chiara Daraio, and Wei Chen, **2D orthotropic metamaterial micorstructrue dataset**, Figshare, https://doi.org/10.6084/m9.figshare.17141975.v1, CC BY 4.0. The downloaded metadata and file checksums are in `data/provenance.json`. The download verified every supplied MD5 checksum. There are 90,245 binary 50 x 50 geometries; their volume fractions agree with the supplied property table.

Related paper: Wang et al., *Deep generative modeling for mechanistic-based learning and design of metamaterial systems*, Computer Methods in Applied Mechanics and Engineering 372 (2020) 113377, https://doi.org/10.1016/j.cma.2020.113377.

**This is a paper-inspired experiment, not an exact reproduction.** The paper used approximately 250,000 cells and constituent Poisson ratio 0.49; the public 2021 dataset has 90,245 cells and Poisson ratio 0.35. We use the public data's parameters. The paper's 0.0600 beam RRMSE is not directly comparable to this experiment's errors.

## Fixed problem

- Domain: 30 x 4 cells; each cell retains its original 50 x 50 pixel geometry. The final model has 300,000 Q4 elements and 603,402 displacement degrees of freedom.
- Material: normalized Young's modulus 1, Poisson ratio 0.35, plane stress; engineering shear convention.
- Loading: left edge clamped; all right-edge horizontal displacements prescribed at -0.12; the top and bottom right corners have zero vertical displacement. These boundary conditions are explicitly defined for the pilot, rather than claimed as an exact copy of Fig. 16.
- Macro stage: L-BFGS-B over softmax mixtures of four library stiffness tensors. A convex mixture is feasible in tensor space but need not be exactly realized by one library geometry. Requested vertical displacement is 0.08 sin(pi x / 30)^2 on both outer edges. Every method is tested against the **achieved macro displacement target**, isolating selection error from the macro optimization's residual error. The requested arch is also retained and plotted.
- Candidate retrieval: ten closest positive-definite stiffness tensors per cell, using the maximum absolute error across C11, C12, C22, and C66. Deterministic sorting.
- Full-geometry assessment: one pixel per finite element, no geometric downsampling. Void has an ersatz stiffness of 1e-6, which regularizes the solve but does not represent physical bridges. Four-neighbor solid component counts are reported independently.

## Selectors

1. `nearest_property`: independent nearest-property selection.
2. `graph_multistart_icm`: 16-start iterated conditional modes minimizing unary property mismatch plus neighboring geometric and mechanical incompatibility. Pair weight is fixed in advance at 0.03. Mechanical descriptors come from periodically equilibrated unit-cell stresses under three unit strains. **This is an approximate graph baseline, not the paper's dual-decomposition MRF algorithm.**
3. `deterministic_adjoint_top8`: a numerical feedback comparator. Starting from the graph selection, choose the eight distinct cells with the most negative macro-FEM adjoint estimates, in one committed batch.
4. `deterministic_adjoint_trust_region`: binary optimization of the numerical adjoint estimates under a total predicted-gain budget of 40% of the current squared macro error, a total single-swap graph-cost budget of 0.08, and at most eight distinct-cell changes. Individual geometric mismatch increases are limited to 0.3 and graph increases to less than 0.025. This gives the numerical comparison a policy similar to the LLM's conservative repair strategy. The exploratory budgets were fixed after baseline inspection and before repair outcomes; they are not preregistered.
5. The LLM pilot uses the current assistant to choose a batch of at most eight changes from the identical numerical feedback, considering estimated response gain, boundary compatibility, and spatial relationships. Its literal action file is committed before evaluating any feedback selector. This is an assistant-in-the-loop pilot; it is not an automated, repeated API benchmark or a pure language-only selector.

The LLM's role is selection from numerical evidence. The finite-element solver supplies the mechanical predictions; do not attribute those predictions to the LLM. Each feedback selector receives one proposal batch and one full-geometry FEM assessment, starting from the same graph result. Shared preparation costs are excluded from selection timing. LLM inference latency and token cost are not measured in this pilot, so no speed or cost superiority can be claimed.

## Metrics and validation

Primary selection metric: Euclidean displacement error divided by the norm of the common target, measured at macro-cell boundaries along both the top and bottom edges. This normalization is defined here and is not asserted to match every detail of the paper's RRMSE implementation.

Also report mean property mismatch, geometric and mechanical incompatibility, volume fraction, solid connected components, and free-DOF equilibrium residual. Reducing displacement error while degrading connectivity does not establish an engineering improvement.

`validation.json` records an affine Q4 patch test, a homogeneous periodic-cell check, a central finite-difference check of the adjoint gradient, and three independent homogenization comparisons against the public dataset. Three sampled cells validate conventions, not the entire database. Full assemblies retain an ersatz void phase; disconnected solids are a material limitation of any resulting pilot design.

## Run

Install `requirements.txt` into an environment of your choice, then:

```bash
python benchmark.py prepare --seed 20261002
python trust_region.py
python benchmark.py evaluate --actions numerical_actions.json
python benchmark.py evaluate --actions trust_region_actions.json
python benchmark.py evaluate --actions llm_actions.json
python check_void.py
```

`prepare` recreates the common problem, baselines, feedback, and deterministic action file. Running it overwrites those preparation outputs. `evaluate` rejects duplicate selector names, invalid candidate labels, duplicate changed cells, and batches larger than eight. It stores the SHA-256 hash of each evaluated action file. All cell, candidate, and dataset indices are zero based. Numerical result files are generated by the solver, not manually populated.

The original MAT files, `problem.npz`, committed action files, complete results, metrics CSV, and comparison figure are included. An automated model comparison would next require a fixed model/version, decoding settings, a scripted prompt and response schema, several held-out target profiles, repeated runs, equal evaluation budgets, the paper's DD-MRF implementation or a validated equivalent, and a void-stiffness sensitivity check. A single pilot cannot demonstrate statistical superiority over the paper.
