"""Three-round common-incumbent competition: 3 agents vs 3 numerical proposals.

No original pilot outputs are overwritten. Every round commits proposals before
any of their fine FEM outcomes are observed. Response vectors are first-order
linearizations of the full assembled geometry, not homogenized tensors.
"""
import argparse, json, hashlib, time
from pathlib import Path
import numpy as np
from scipy.ndimage import label as components
import benchmark as b

ROOT=b.ROOT/'swarm'
MAX_SWAPS=8

def sensitivity(mesh,density,step,target):
    u,K,free,lu,res=mesh.compression(density[:,None,None]*b.CSOLID)
    dofs=mesh.profile_dofs(step);profile=u[dofs]
    # Multiple adjoints, one per sampled displacement; process RHS in chunks.
    lambdas=np.zeros((mesh.ndof,len(dofs)))
    inverse=np.full(mesh.ndof,-1,int);inverse[free]=np.arange(len(free))
    for start in range(0,len(dofs),8):
        stop=min(start+8,len(dofs));rhs=np.zeros((len(free),stop-start))
        for j,dof in enumerate(dofs[start:stop]):
            if inverse[dof]>=0:rhs[inverse[dof],j]=1
        lambdas[free,start:stop]=lu.solve(rhs,trans='T')
    del lu,K
    return u,lambdas,profile,float(res)

def validate_response_derivative():
    mesh=b.Mesh(12,8)
    rho=np.linspace(.4,.95,96)
    u,lam,profile,_=sensitivity(mesh,rho,1,np.zeros(26))
    es=np.einsum('gai,i->ga',mesh.bs,u[mesh.edof[45]])
    ls=np.einsum('gai,ik->gak',mesh.bs,lam[mesh.edof[45]])
    derivative=-np.einsum('gak,ab,gb->k',ls,b.CSOLID,es)*mesh.det
    pp=[]
    for eps in [-1e-5,1e-5]:
        rr=rho.copy();rr[45]+=eps;up,*_=mesh.compression(rr[:,None,None]*b.CSOLID);pp.append(up[mesh.profile_dofs()])
    fd=(pp[1]-pp[0])/2e-5
    rel=float(np.linalg.norm(fd-derivative)/np.linalg.norm(fd))
    assert rel<1e-5,rel
    return rel

def initial():
    ROOT.mkdir(exist_ok=True)
    assert not (ROOT/'history.json').exists(),'Do not overwrite an existing swarm experiment'
    lab=json.loads((b.ROOT/'deterministic_adjoint_top8_labels.json').read_text())
    result=json.loads((b.ROOT/'results.json').read_text())['deterministic_adjoint_top8']
    b.save_json(ROOT/'incumbent_labels.json',lab)
    b.save_json(ROOT/'history.json',{'protocol':{
        'rounds':3,'agent_proposals_per_round':3,'numerical_proposals_per_round':3,
        'max_swaps_per_proposal':8,'starting_selector':'deterministic_adjoint_top8',
        'starting_fine_error':result['fine_relative_error'],
        'candidate_library':'same fixed ten candidates per cell as original pilot',
        'feedback':'full-geometry linearized profile change; common incumbent',
        'acceptance':'fine error decreases; one solid component; mean geometry <=0.20; mean mechanics <=0.35; VF within 0.015 of initial',
        'numerical_policies':['greedy_single','greedy_batch4','greedy_batch8'],
        'model_snapshot':'subagents inherit current Codex model; exact snapshot and decoding settings unavailable',
        'cost_scope':'equal full-FEM candidate counts; token costs and all selection wall times not equated',
        'initial_volume_fraction':result['volume_fraction'],
        'response_derivative_validation_relative_error':validate_response_derivative()},
        'incumbent':result,'rounds':[]})

def prepare(roundnum):
    folder=ROOT/f'round{roundnum}';folder.mkdir(exist_ok=True)
    assert not (folder/'feedback.json').exists(),'Round feedback already committed'
    g,p=b.load_library();z=np.load(b.ROOT/'problem.npz')
    labs=np.array(json.loads((ROOT/'incumbent_labels.json').read_text()))
    b.save_json(folder/'incumbent_labels.json',labs.tolist())
    image=b.image_for(g,z['ids'],labs)
    mesh=b.Mesh(b.NX*50,b.NY*50,1/50)
    t=time.perf_counter();print('Full-geometry solve and response adjoints',flush=True)
    u,lam,profile,res=sensitivity(mesh,b.VOID+(1-b.VOID)*image.ravel(),50,z['target'])
    difference=profile-z['target'];scale=z['target']@z['target'];adj=b.adjacency();opts=[]
    pixel_indices=np.arange(b.NX*50*b.NY*50).reshape(b.NY*50,b.NX*50)
    for i in range(b.NX*b.NY):
        row,col=divmod(i,b.NX)
        eids=pixel_indices[row*50:(row+1)*50,col*50:(col+1)*50].ravel()
        es=np.einsum('gai,ei->ega',mesh.bs,u[mesh.edof[eids]])
        ls=np.einsum('gai,eik->egak',mesh.bs,lam[mesh.edof[eids]])
        grad=-(1-b.VOID)*np.einsum('egak,ab,egb->ek',ls,b.CSOLID,es)*mesh.det
        old=g[:,:,z['ids'][i,labs[i]]].ravel().astype(float)
        for k in range(b.NC):
            if k==labs[i]:continue
            new=g[:,:,z['ids'][i,k]].ravel().astype(float)
            response=(new-old)@grad
            predicted=float(np.linalg.norm(difference+response)/np.sqrt(scale))
            cost=float(z['unary'][i,k]-z['unary'][i,labs[i]]);geo=mech=0
            for j,e,rev in adj[i]:
                idx=(labs[j],k) if rev else (k,labs[j]);orig=(labs[j],labs[i]) if rev else (labs[i],labs[j])
                geo+=z['gg'][e][idx]-z['gg'][e][orig];mech+=z['mm'][e][idx]-z['mm'][e][orig]
            cost+=b.PAIR_WEIGHT*(geo+mech)
            opts.append({'cell':i,'row':row,'column':col,'from_label':int(labs[i]),'to_label':k,
                'dataset_id_zero_based':int(z['ids'][i,k]),'predicted_linear_error':predicted,
                'response_delta':response.tolist(),'response_norm_relative':float(np.linalg.norm(response)/np.sqrt(scale)),
                'graph_energy_change':cost,'geometry_change_sum':float(geo),'mechanical_change_sum':float(mech),
                'pixel_change_fraction':float(np.mean(new!=old)), 'property_error':float(z['unary'][i,k]),
                'volume_fraction':float(p[z['ids'][i,k],4])})
    opts.sort(key=lambda o:o['predicted_linear_error'])
    feedback={'round':roundnum,'fine_error':float(np.linalg.norm(difference)/np.sqrt(scale)),
        'incumbent_labels':labs.tolist(),'target_profile':z['target'].tolist(),'fine_profile':profile.tolist(),
        'options':opts,'equilibrium_residual':res,'feedback_seconds':time.perf_counter()-t,
        'instructions':'Propose <=8 distinct cells; exact labels must be listed here. No full-FEM candidate testing before commit. Response changes are first-order only; near-void strain may make them unreliable. Independent subagents and numeric policies share all evidence.'}
    b.save_json(folder/'feedback.json',feedback)
    print('Feedback ready; incumbent error',feedback['fine_error'],'best single linear estimate',opts[0]['predicted_linear_error'],flush=True)
    numerical(folder,z,feedback)

def linear_error(feedback,actions):
    lookup={(o['cell'],o['to_label']):o for o in feedback['options']}
    delta=np.array(feedback['fine_profile'])-feedback['target_profile']
    for a in actions:delta+=lookup[(a['cell'],a['to_label'])]['response_delta']
    return float(np.linalg.norm(delta)/np.linalg.norm(feedback['target_profile']))

def numerical(folder,z,feedback):
    # Deterministic greedy discrete least-squares on the full response vectors.
    # Three distinct step-size policies receive one assessment each per round.
    response=np.array([o['response_delta'] for o in feedback['options']])
    norm=np.linalg.norm(feedback['target_profile'])
    cells=np.array([o['cell'] for o in feedback['options']])
    for limit in [1,4,8]:
        chosen=[];used=set();current=feedback['fine_error']
        residual=np.array(feedback['fine_profile'])-feedback['target_profile']
        for step in range(limit):
            values=np.linalg.norm(residual[None,:]+response,axis=1)/norm
            values[np.isin(cells,list(used))]=np.inf
            k=int(np.argmin(values))
            if values[k]>=current-1e-12:break
            option=feedback['options'][k]
            chosen.append({'cell':option['cell'],'to_label':option['to_label']})
            residual+=response[k];current=float(values[k]);used.add(option['cell'])
        b.save_json(folder/f'numerical{limit}.json',{'selector':f'numerical_greedy{limit}',
            'group':'numerical','actions':chosen,'predicted_linear_error':current,
            'policy':f'greedy minimize linearized full-geometry profile error with <= {limit} distinct swaps'})

def evaluate(roundnum):
    folder=ROOT/f'round{roundnum}';assert not (folder/'results.json').exists(),'Cannot overwrite round outcomes'
    files=[folder/f'numerical{k}.json' for k in [1,4,8]]+[folder/f'agent_{n}.json' for n in ['response','interfaces','robust']]
    assert all(f.exists() for f in files),'All six proposals must be committed before evaluation'
    feedback=json.loads((folder/'feedback.json').read_text());opts={(o['cell'],o['to_label']) for o in feedback['options']}
    committed=[]
    for f in files:
        obj=json.loads(f.read_text());actions=obj['actions'];assert len(actions)<=MAX_SWAPS
        assert len({a['cell'] for a in actions})==len(actions)
        assert all((a['cell'],a['to_label']) in opts for a in actions)
        committed.append((f,obj,hashlib.sha256(f.read_bytes()).hexdigest()))
    b.save_json(folder/'commitment_manifest.json',[{'file':f.name,'sha256':digest} for f,_,digest in committed])
    g,p=b.load_library();z=np.load(b.ROOT/'problem.npz');history=json.loads((ROOT/'history.json').read_text())
    initialvf=history['protocol']['initial_volume_fraction'];baseline=history['incumbent']
    base=np.array(feedback['incumbent_labels']);best=baseline;bestlabs=base.copy();winner='retain_incumbent';results={}
    for f,obj,digest in committed:
        labs=base.copy()
        for a in obj['actions']:labs[a['cell']]=a['to_label']
        print('Assessing',obj['selector'],flush=True)
        result=b.assess(labs,z['ids'],g,p,z['target'],z['unary'],z['pair'],z['gg'],z['mm'])
        result.update(group=obj['group'],action_file_sha256=digest,swaps=len(obj['actions']),
            predicted_linear_error=linear_error(feedback,obj['actions']))
        valid=result['solid_connected_components']==1 and result['mean_geometric_incompatibility']<=.20 and result['mean_mechanical_incompatibility']<=.35 and abs(result['volume_fraction']-initialvf)<=.015
        result['eligible']=bool(valid);results[obj['selector']]=result
        b.save_json(folder/(obj['selector']+'_labels.json'),labs.tolist())
        b.save_json(folder/'partial_results.json',results)
        print(obj['selector'],'fine error',result['fine_relative_error'],'eligible',valid,flush=True)
        if valid and result['fine_relative_error']<best['fine_relative_error']:
            best=result;bestlabs=labs.copy();winner=obj['selector']
    b.save_json(folder/'results.json',results);b.save_json(ROOT/'incumbent_labels.json',bestlabs.tolist())
    history['rounds'].append({'round':roundnum,'starting_error':baseline['fine_relative_error'],
        'winner':winner,'incumbent_error':best['fine_relative_error'],
        'best_agent_error':min((r['fine_relative_error'] for r in results.values() if r['group']=='agent' and r['eligible']),default=None),
        'best_numerical_error':min((r['fine_relative_error'] for r in results.values() if r['group']=='numerical' and r['eligible']),default=None)})
    history['incumbent']=best;b.save_json(ROOT/'history.json',history)
    print(json.dumps(history['rounds'][-1],indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('command',choices=['initial','prepare','evaluate']);ap.add_argument('--round',type=int,default=1)
    args=ap.parse_args()
    if args.command=='initial':initial()
    elif args.command=='prepare':prepare(args.round)
    else:evaluate(args.round)
