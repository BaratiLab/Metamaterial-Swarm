import csv,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import swarm_benchmark as s

history=json.loads((s.ROOT/'history.json').read_text())
rows=[]
for roundnum in [1,2,3]:
    folder=s.ROOT/f'round{roundnum}'
    trials=json.loads((folder/'results.json').read_text())
    for method,result in trials.items():
        rows.append({'round':roundnum,'method':method,**{k:result[k] for k in [
            'group','fine_relative_error','predicted_linear_error','swaps','eligible',
            'mean_geometric_incompatibility','mean_mechanical_incompatibility','volume_fraction',
            'solid_connected_components','fine_equilibrium_residual','fine_solve_seconds']}})
with (s.ROOT/'trial_metrics.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
start=100*history['protocol']['starting_fine_error'];rounds=history['rounds']
fig,axs=plt.subplots(1,2,figsize=(13,5),constrained_layout=True)
ax=axs[0]
ax.plot(range(4),[start]+[100*r['incumbent_error'] for r in rounds],'ko-',label='Shared best assembly')
for group,color in [('agent','#CC79A7'),('numerical','#0072B2')]:
    for row in [r for r in rows if r['group']==group]:
        ax.scatter(row['round'],100*row['fine_relative_error'],color=color,marker='o' if row['eligible'] else 'x',alpha=.65)
    ax.scatter([],[],color=color,label='Agent proposals' if group=='agent' else 'Numerical proposals')
ax.set_xticks(range(4));ax.set_xlabel('Round (0 = starting assembly)');ax.set_ylabel('Full-geometry error (%)')
ax.set_title('Equal candidate-evaluation budget');ax.legend(fontsize=9);ax.grid(alpha=.2)
ax=axs[1];feedback=json.loads((s.ROOT/'round1/feedback.json').read_text());target=feedback['target_profile'];final=history['incumbent']['_fine_profile']
for offset,label,style in [(0,'Bottom','-'),(31,'Top','--')]:
    ax.plot(range(31),target[offset:offset+31],color='black',linestyle=style,label=label+' target')
    ax.plot(range(31),feedback['fine_profile'][offset:offset+31],color='#777777',linestyle=style,label=label+' initial')
    ax.plot(range(31),final[offset:offset+31],color='#009E73',linestyle=style,label=label+' final')
ax.set_title('Initial and final assembled responses');ax.set_xlabel('x / cell size');ax.set_ylabel('Vertical displacement');ax.legend(fontsize=8,ncol=2);ax.grid(alpha=.2)
fig.savefig(s.ROOT/'swarm_comparison.png',dpi=170);plt.close(fig)
comparison='\n'.join(f'| {r["round"]} | {100*r["starting_error"]:.3f}% | '+
    (f'{100*r["best_agent_error"]:.3f}%' if r['best_agent_error'] is not None else 'No eligible proposal')+' | '+
    (f'{100*r["best_numerical_error"]:.3f}%' if r['best_numerical_error'] is not None else 'No eligible proposal')+
    f' | {r["winner"]} | {100*r["incumbent_error"]:.3f}% |' for r in rounds)
best_agent=min((r['fine_relative_error'] for r in rows if r['group']=='agent' and r['eligible']),default=None)
best_num=min((r['fine_relative_error'] for r in rows if r['group']=='numerical' and r['eligible']),default=None)
summary=f'''# Three-round agent swarm experiment

Starting full-geometry error: **{start:.3f}%**, using the strongest numerical repair from the original pilot. Final retained error: **{100*history['incumbent']['fine_relative_error']:.3f}%**.

| Round | Starting error | Best eligible agent proposal | Best eligible numerical proposal | Retained choice | Retained error |
|---|---:|---:|---:|---|---:|
{comparison}

## What was tested

Three independent LLM subagents proposed repairs specializing in response matching, interface compatibility, and cautious small changes. Three deterministic numerical policies greedily minimized linearized full-geometry profile error with batch limits of one, four, and eight swaps. Every proposal was restricted to the same original ten candidates per location and at most eight changed cells.

Each round used the same starting assembly for all six proposals. First-order response vectors were computed from the actual 300,000-element assembly using one forward solve and displacement-response adjoints, replacing the original pilot's homogenized feedback. All six literal action files were committed before any candidate outcome was evaluated. Each group received three full-FEM candidate assessments per round: **nine each across three rounds**. There were no hidden candidate-FEM evaluations. Derivative validation on a smaller independent model agreed with finite differences to relative error {history['protocol']['response_derivative_validation_relative_error']:.2e}.

After each round, the lowest-error eligible assembly was shared as the next incumbent. This is a common-incumbent proposal competition, not two independent optimization trajectories. Both groups could benefit from the other group's accepted proposals. Equal candidate-FEM counts do not equate token costs, selection computation, or wall-clock time.

The numerical round-three proposals repeated round two exactly because the incumbent was unchanged and the numerical policies were fixed. Thus nine numerical assessments covered six unique incumbent/action pairs. The agents adapted their policies using previous outcomes; the numerical policies did not. This limits causal attribution of the gain to LLM reasoning. Separately committed proposer roles are not independent statistical replicates.

Agent proposals included agent-designed numerical searches over the supplied estimates. The interface specialist enumerated small combinations under pixel-change and interface filters, then revised those filters using measured outcomes. Consequently this evaluates a hybrid agent-guided search portfolio, not language-only selection or intrinsic intelligence independently of the search algorithm.

Eligibility required one connected solid component, mean geometric mismatch no greater than 0.20, mean mechanical mismatch no greater than 0.35, and volume fraction within 0.015 of the starting value. Retention additionally required lower measured displacement error. These criteria were specified before the new rounds.

Connectivity means one four-neighbor binary solid component. It does not establish mechanical robustness, buckling resistance, minimum printable feature size, or fabrication reliability.

## Interpretation and limits

The observations above distinguish actual measured assembly performance from each proposal's first-order predicted error. Finite topology changes can invalidate linearized predictions even when infinitesimal derivatives pass validation. The numerical comparator is a fixed three-policy greedy portfolio; it is not a global optimizer or a trained graph neural network. No GNN comparison was run.

This remains one target, one fixed library, and one inherited-model agent team. The exact model snapshot and decoding settings are unavailable. The outcome does not establish statistical superiority, and it cannot be compared directly with the original paper's different dataset, material parameters, and DD-MRF solver.

![Three-round comparison](swarm_comparison.png)

Per-round feedback, actions, action hashes, and complete outcomes are preserved in `round1/`, `round2/`, and `round3/`. `trial_metrics.csv` contains all 18 trials, including rejected ones. `history.json` records acceptance decisions and the final assembly. The original pilot outputs are unchanged.
'''
(s.ROOT/'RESULTS.md').write_text(summary)
print(summary[:2500])
