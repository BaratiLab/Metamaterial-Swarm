function report = run_cloak_checked(packageDir, labelFile, outputFile)
% Non-destructive evaluator for the supplied Agent_Meta package.
% This retains the exact Assemble/UCal material, load, and void conventions.
% Full solve: 2.25 million elements, 4,506,002 DOFs. Provision RAM first.
% Example:
% report = run_cloak_checked('/path/Agent_Meta');
% report = run_cloak_checked('/path/Agent_Meta', '/path/proposal.mat', 'result.mat');
if nargin < 2 || isempty(labelFile)
    labelFile = fullfile(packageDir, 'Label_opt.mat');
end
if nargin < 3, outputFile = ''; end
assert(isfolder(packageDir), 'Package directory not found.');
oldPath = path; cleanup = onCleanup(@() path(oldPath)); %#ok<NASGU>
addpath(packageDir, '-begin');
D = struct;
names = {'Indicator','ShapeSpace','OriginCell','UOrigin','Interest','PhiIndex'};
for k=1:numel(names)
    tmp=load(fullfile(packageDir,'data',[names{k},'.mat']),names{k});
    assert(isfield(tmp,names{k}), 'Missing expected MAT variable.');
    D.(names{k})=tmp.(names{k});
end
S=load(labelFile,'Label');assert(isfield(S,'Label'),'MAT file needs Label.');
Label=S.Label;
assert(isequal(size(Label),[26 13]),'Label must be 26 by 13.');
assert(isreal(Label)&&all(isfinite(Label(:)))&&all(Label(:)==fix(Label(:))), 'Labels must be finite real integers.');
assert(all(Label(:)>=0 & Label(:)<=14),'Labels must lie in 0..14.');
passive=D.Indicator(3:end-2,3:15);active=reshape(passive',[],1)==1;
assert(isequal(size(D.PhiIndex),[338 15]),'PhiIndex must be 338 by 15.');
ids=D.PhiIndex(active,:);
assert(all(ids(:)>=1 & ids(:)<=size(D.ShapeSpace,3) & ids(:)==fix(ids(:))), 'Invalid active lookup indices.');
assert(isequal(D.Indicator,fliplr(D.Indicator)),'Expected horizontal mirror symmetry.');
tic;
Phi=Assemble(D.Indicator,D.ShapeSpace,D.OriginCell,D.PhiIndex,Label);
assert(isequal(size(Phi),[1500 1500]),'Unexpected assembled dimensions.');
Interest=D.Interest([1:end,end],[1:end,end])>0;
mask=reshape([Interest(:)';Interest(:)'],[],1);
target=D.UOrigin(:); assert(numel(target)==numel(mask),'Target length mismatch.');
assert(all(isfinite(target(mask))), 'Nonfinite monitored target.');
normal=norm(target(mask));assert(normal>0,'Target norm is zero.');
U=UCal(Phi);
assert(numel(U)==numel(mask)&&all(isfinite(U(mask))),'Invalid monitored solution.');
report=struct('loss',norm(U(mask)-target(mask))/normal, ...
    'elapsed_seconds',toc,'design_cells',sum(active), ...
    'elements',numel(Phi),'dofs',numel(U),'monitored_dofs',sum(mask), ...
    'volume_fraction',mean(Phi(:)), 'label_file',labelFile, ...
    'note','Original UCal material/load/void scaling retained.');
disp(report);
if ~isempty(outputFile)
    assert(~isfile(outputFile),'Refusing to overwrite an existing result.');
    save(outputFile,'report','Label','-v7');
end
end
