from pathlib import Path
import json,csv
p=Path('outputs/overleaf-metamaterial-selector/main.tex')
s=p.read_text(); Path('work/main-before-manuscript.tex').write_text(s)
s=s.replace('LLM-Guided Selection of Heterogeneous Metamaterial Cells:\\\\A Controlled Real-Data Pilot','Physics-Guided Multi-Agent Selection of Heterogeneous Metamaterials:\\\\A Discrete Assembly Case Study')
s=s.replace('\\author{Research pilot report}','\\author{}').replace('\\date{October 2, 2026}','\\date{}')
a=s.index('\\begin{abstract}');b=s.index('\\end{abstract}',a)+len('\\end{abstract}')
s=s[:a]+r'''\begin{abstract}
Discrete assembly of heterogeneous mechanical metamaterials requires local stiffness matching together with compatible interfaces and accurate structural response. We investigate large language model (LLM) agents as selectors of existing unit-cell geometries on a discretized domain. A public library of 90,245 orthotropic microstructures supplies ten candidates at each location of a $4\times30$-cell beam; assembled responses are evaluated using 300,000 quadrilateral finite elements. Independent property matching and multistart graph selection yield relative boundary-displacement errors of 20.73\% and 9.93\%, respectively. An initial numerical repair reaches 4.86\%, whereas a single LLM-guided batch using homogenized feedback worsens the graph result to 10.82\%. We subsequently construct assembled-geometry response sensitivities and compare three specialized LLM agents with three fixed numerical policies over three common-incumbent rounds. With nine full-geometry candidate assessments per group, the retained error decreases from 4.86\% to 3.92\%, a 19.4\% relative reduction. All assessed follow-up proposals satisfy the specified connectivity, interface, and volume-fraction bounds. Complete proposal outcomes and numerical verification checks accompany the study. The result supports the feasibility of an LLM-guided search portfolio for this target, while the single-target scope, adaptive-policy mismatch, and unspecified model snapshot prevent claims of general superiority over numerical optimization or graph neural networks.
\end{abstract}
\noindent\textbf{Keywords:} mechanical metamaterials; discrete assembly; large language models; multi-agent search; adjoint sensitivity; finite elements.
''' +s[b:]
s=s.replace('\\section{Research question and scope}','\\section{Introduction}')
s=s.replace('This report describes an exploratory, assistant-in-the-loop experiment.','This study describes an exploratory, assistant-in-the-loop experiment.')
pos=s.index('\\section{Data and mechanical model}')
s=s[:pos]+r'''
The distinction between unit-cell generation and unit-cell assembly is central. Once a candidate library is available, selecting a locally accurate tensor does not guarantee that the tiled structure reproduces the desired displacement field. The displacement objective depends on equilibrium of the entire assembly, and compatibility penalties depend on pairs of neighboring labels. Consequently, domain discretization provides a structured action space for an agent, but it does not remove the need for a mechanical evaluator.

We examine two questions. First, does a single agent improve graph selection when given homogenized adjoint feedback? Second, can a portfolio of specialized agents improve a stronger numerical incumbent when given response sensitivities from its actual geometry? The first comparison gives a negative result; the second gives a measurable improvement in a shared-incumbent competition. Reporting both exposes the role of feedback fidelity and avoids interpreting one successful proposal as a universal optimizer advantage.

The contributions are an implemented library-based selection problem with fixed candidates, a full-geometry response-vector interface for discrete repair, and an auditable comparison of committed agent and numerical proposals. The contribution is a computational case study rather than a new trained surrogate, a new generative architecture, or a proof of optimality. We do not claim the first use of LLMs in metamaterial design.

\section{Related work and positioning}
\subsection{Data-driven microstructure design and assembly}
The framework of Wang et al.~\cite{wang2020} integrates learned microstructure representations with target property design and compatibility-aware assembly. Their staged formulation motivates our decision to keep continuous target optimization separate from discrete label selection. Wang et al.~\cite{cloak2022} subsequently demonstrate database-driven tiling for aperiodic mechanical cloaks. That study also provides the provenance of the public library used here~\cite{dataset}. These works establish the relevance of neighborhood-aware assembly; our implementation uses a simpler multistart ICM solver and different material parameters, so the present experiment is not a replication of their reported structural performance.

\subsection{Language-guided design and optimization}
TrussGPT~\cite{trussgpt} combines a pretrained language interface with a specialized Transformer generator and a tokenizer for truss structures. Its generation problem differs from our choice among fixed binary microstructures at spatial locations. Our agents neither synthesize new unit-cell topologies nor train a generative model. They inspect structured mechanical evidence and may construct numerical searches over candidate combinations.

Optimization by prompting~\cite{opro} uses previously evaluated solutions as context for subsequent LLM proposals. Our feedback loop shares this use of observed outcomes, but physical feasibility and objective values are computed by finite elements. The language model controls a search procedure; it is not the constitutive model or equilibrium solver. This separation permits rejection of a persuasive but mechanically unsuccessful proposal.

\subsection{Scope of the comparator claims}
A graph objective is not a graph neural network (GNN). Our graph baseline uses explicitly defined unary and pairwise costs with coordinate descent; no trainable message-passing model is evaluated. Similarly, the numerical follow-up policies are fixed greedy procedures rather than all-purpose numerical optimization. The appropriate comparison is therefore between the particular proposal systems described below. Assessing a general LLM advantage would require stronger adaptive numerical methods, a trained GNN selector with controlled training data, and evaluation on held-out design targets.

''' +s[pos:]
# add equilibrium and explicit discrete formulation
pos=s.index('\\section{Shared target and candidate sets}')
s=s[:pos]+r'''
The element stiffness is assembled as
\begin{equation}
\mathbf K_e=\sum_{q=1}^{4}\mathbf B_q^{\mathsf T}\mathbf C_e\mathbf B_q\,w_q,
\qquad \mathbf K_{ff}\mathbf u_f=\mathbf f_f-\mathbf K_{fc}\mathbf u_c,
\label{eq:equilibrium}
\end{equation}
using $2\times2$ Gauss quadrature. The prescribed vector $\mathbf u_c$ is held fixed during differentiation; the adjoints have zero entries at constrained degrees of freedom. Both forward and adjoint computations use the same element formulation. Traction-free edges carry no additional external force in the compression solve.

''' +s[pos:]
pos=s.index('\\section{Selection and repair methods}')
s=s[:pos]+r'''
\subsection{Discrete response objective}
Let $G_{i\ell}$ denote the binary geometry associated with candidate $\ell\in\{0,\ldots,9\}$ at cell $i$. Tiling these geometries constructs the pixel field $\rho(\boldsymbol\ell)$. The full selection problem can be written as
\begin{equation}
\min_{\boldsymbol\ell\in\{0,\ldots,9\}^{120}}
\frac{\|\mathbf P_{\mathrm{fine}}\mathbf u(\rho(\boldsymbol\ell))-\mathbf u^*\|_2}
{\|\mathbf u^*\|_2},\qquad
\mathbf u\ \text{satisfies Eq.~\eqref{eq:equilibrium}}.
\label{eq:discrete}
\end{equation}
The unrestricted label space contains $10^{120}$ assignments. Our procedures operate on local candidate replacements, without exhaustive exploration or an optimality certificate. Interface penalties guide the initial assembly, while connectivity and specified compatibility bounds serve as acceptance conditions in the follow-up. These are distinct uses of compatibility, and neither guarantees fabrication feasibility.

''' +s[pos:]
s=s.replace('\\section{Results}','\\section{Initial comparison: homogenized repair feedback}')
s=s.replace('\\section{Follow-up: three-agent repair portfolio}','\\section{Multi-agent repair with assembled-geometry feedback}')
# response model derivation and procedure before followup results
pos=s.index('\\subsection{Measured follow-up results}')
s=s[:pos]+r'''
\subsection{Response-vector construction and proposal scoring}
For monitored coordinate $s$, define $\boldsymbol\lambda_{s,f}$ by
\begin{equation}
\mathbf K_{ff}^{\mathsf T}\boldsymbol\lambda_{s,f}=\mathbf P_{s,f}^{\mathsf T}.
\end{equation}
The full-geometry feedback uses 62 sampled coordinates. Constrained coordinates have zero response derivatives, and response adjoints are processed in blocks of eight using the forward factorization. Each candidate change is summarized by a vector $\mathbf d_{i\ell}\in\mathbb R^{62}$ obtained by contracting pixel sensitivities with the difference between the candidate and incumbent geometry. There are $120(10-1)=1080$ available single-cell replacements per round.

For a batch $A$ containing distinct cells, the shared first-order score is
\begin{equation}
\widehat\epsilon(A)=\frac{\left\|\mathbf r+\sum_{(i,\ell)\in A}\mathbf d_{i\ell}\right\|_2}{\|\mathbf u^*\|_2},
\qquad \mathbf r=\mathbf P_{\mathrm{fine}}\mathbf u-\mathbf u^*.
\label{eq:batch}
\end{equation}
The feedback also records the fraction of altered pixels, property mismatch, volume fraction, and graph and interface changes. Summing response vectors models interaction in displacement space but neglects higher-order changes in stiffness and equilibrium. Binary changes from void to solid, or the reverse, are finite perturbations; a validated differential does not make Eq.~\eqref{eq:batch} exact.

\begin{table}[htbp]
\centering\small
\caption{Operational roles in the proposal portfolio. All methods use identical round feedback and submit literal candidate labels before fine evaluation.}
\begin{tabular}{@{}p{.23\linewidth}p{.70\linewidth}@{}}\toprule
Proposer & Selection procedure\\\midrule
Response agent & Emphasizes combined displacement correction and revises response calibration using measured outcomes.\\
Interface agent & Enumerates small candidate combinations in Python under chosen pixel-change and interface filters; revises filters after outcomes.\\
Cautious agent & Favors small batches and conservative geometry changes using the same response information.\\
Numerical policies & Fixed greedy minimization of Eq.~\eqref{eq:batch}, with batch caps of one, four, or eight and no repeated cell.\\\bottomrule
\end{tabular}
\end{table}

\begin{figure}[htbp]
\centering\fbox{\begin{minipage}{.91\linewidth}\small
\textbf{Common-incumbent proposal competition}\par\medskip
\begin{enumerate}
\item Load the same target, candidate sets, and strongest initial numerical assembly for both groups.
\item Solve the incumbent geometry and form the 1080 candidate response vectors and compatibility features.
\item Three agents and three numerical policies each submit a batch of at most eight distinct-cell replacements. Save all actions and their SHA-256 commitments.
\item Evaluate all six batches with the same fine finite-element solver. Reject proposals that fail connectivity, interface, or volume bounds.
\item Retain the lowest-error eligible proposal only if it improves the incumbent. Give the retained geometry and all round outcomes to the next round.
\item Repeat through round three and retain every assessed proposal in the record.
\end{enumerate}
\end{minipage}}
\caption{Executed three-round protocol. Proposal commitment prevents access to within-round candidate outcomes before submission; earlier-round outcomes remain available.}
\label{fig:protocol}
\end{figure}

''' +s[pos:]
# enhanced measurable results
pos=s.index('This follow-up demonstrates an agent contribution')
s=s[:pos]+r'''
The final accepted round-three batch changes $(33,4)$, $(101,9)$, and $(57,4)$ relative to the retained round-one assembly. There are six distinct changed cells relative to the initial numerical incumbent. The final mean geometric and mechanical mismatches are 0.14339 and 0.25141, and its volume fraction is 0.63560. Its macro error is 14.91\%, which reinforces that the fine-response improvement does not imply improvement of the homogenized prediction.

The 18 follow-up candidate solves took between 14.22 and 15.54 seconds each in the recorded environment. These timings describe only the recorded forward assessments; they exclude feedback formation, periodic cell preparation, agent inference, and proposal search. They do not support an end-to-end speedup claim. The final ersatz-sensitivity solve is an additional verification assessment outside both nine-proposal search budgets.

''' +s[pos:]
s=s.replace('\\section{Validation and interpretation}','\\section{Numerical verification}')
pos=s.index('\\section{Limitations and next experiment}')
s=s[:pos]+r'''
\section{Discussion}
\subsection{What the agent contribution consists of}
The accepted proposals show that an LLM-guided procedure can identify useful local changes within a fixed discretized candidate space. Its useful output is an actionable label list together with a selection strategy that can be evaluated mechanically. In this study, the best-performing agent wrote a small combination search with compatibility filters. The result is consequently a hybrid of language-guided strategy choice and numerical evaluation of structured evidence.

There is no evidence that a language model can infer the fine mechanical response accurately without the solver. The initial failed batch illustrates this distinction: coherent reasoning about homogenized feedback produced a worse measured assembly. In the follow-up, retaining proposals only after fine evaluation protected the shared incumbent from unsuccessful suggestions, including all round-two proposals.

\subsection{Prediction error and conservative search}
The linearized response model substantially underestimates several measured errors. For example, the round-one numerical eight-swap batch predicts 2.08\% but yields 5.46\%; the accepted three-swap agent batch predicts 1.64\% but yields 3.98\%. Small predicted error is therefore not a reliable certificate of a successful finite replacement. The same distinction applies to agent proposals: their predicted and measured outcomes are both reported in Appendix~\ref{app:trials}.

The best round-three interface-agent proposal predicts 3.84\% and measures 3.92\%, but this isolated agreement does not establish a calibrated surrogate. A next-step numerical comparator could fit a response scaling factor from previous measured outcomes, enforce pixel-change trust regions, and search small combinations under the same filters. Those controls would help separate the value of adaptive search from the presence of an LLM.

\subsection{Fairness of the budget comparison}
Equal candidate-assessment counts control one expensive resource, not the complete optimization effort. Both groups share the incumbent, feedback solves, and earlier outcomes. The agents can revise their selection code, while the fixed numerical policies cannot; the repeated round-three numerical proposals further reduce their effective search diversity. Accordingly, the reported 19.4\% gain is relative to the initial numerical incumbent, and the within-round comparisons refer only to the specific fixed policies. It is not a statistically supported advantage over adaptive numerical optimization.

''' +s[pos:]
s=s.replace('\\section{Limitations and next experiment}','\\section{Limitations and future evaluation}')
pos=s.index('\\appendix')
s=s[:pos]+r'''
\section*{Data, code, and computational transparency}
The source geometries and property data are publicly available under CC BY 4.0 at the Figshare DOI in Ref.~\cite{dataset}. The companion computational archive contains the Python solver and selectors, original data with provenance, fixed target and candidate arrays, initial and follow-up metrics, literal proposal files, commitment manifests, and validation outputs. At manuscript preparation, the experiment archive is a local supplementary deliverable rather than an independently archived public repository. A permanent code-and-results identifier should be supplied with a submission.

The numerical outcomes can be replayed using saved actions. Re-generating the agent decisions requires information unavailable in this exploratory session, including the exact underlying model snapshot and decoding configuration. The numerical artifacts and finite-element outcomes therefore have a stronger reproducibility basis than the stochastic language-model decision process.

\section*{Use of AI tools}
LLM agents were used both as experimental proposal generators and to assist code development and manuscript drafting. Their mechanically evaluated proposals are part of the study, not independent human assessments. Responsibility for the final scientific claims, code review, and submission belongs to the human authors. Author identities, contributions, funding, and competing-interest declarations are deferred in this working manuscript and must be completed by the authors before submission.

''' +s[pos:]
# append table from exact saved metrics before bib
pos=s.index('\\begin{thebibliography}')
rows=list(csv.DictReader(Path('outputs/metamaterial-selector/swarm/trial_metrics.csv').open()))
table=r'''\section{Complete follow-up proposal outcomes}\label{app:trials}
\begin{table}[htbp]
\centering\small
\caption{All 18 assessed proposals. Predicted and measured errors are percentages. Every proposal was eligible under the stated bounds. Repeated numerical proposals in round three are retained explicitly. These rows are not independent statistical replicates.}
\begin{tabular}{@{}clrrr@{}}\toprule
Round & Proposer & Swaps & Predicted & Measured\\\midrule
'''
names={'numerical_greedy1':'Numerical cap 1','numerical_greedy4':'Numerical cap 4','numerical_greedy8':'Numerical cap 8','agent_response':'Response agent','agent_interfaces':'Interface agent','agent_robust':'Cautious agent'}
for r in rows:
 table+=f"{r['round']} & {names[r['method']]} & {r['swaps']} & {float(r['predicted_linear_error'])*100:.3f} & {float(r['fine_relative_error'])*100:.3f} " +r'\\'+'\n'
table+=r'''\bottomrule\end{tabular}
\end{table}

\section{Acceptance and interpretation of connectivity}
Mean interface costs are averaged over the 206 neighboring macro-cell pairs: 116 horizontal and 90 vertical pairs. The follow-up eligibility set is
\begin{equation}
\mathcal F=\left\{\boldsymbol\ell:
N_{\mathrm{solid}}=1,\ \overline g\leq0.20,\ \overline m\leq0.35,
\ |V(\boldsymbol\ell)-0.63585333|\leq0.015\right\}.
\end{equation}
Connectedness refers to four-neighbor adjacency of solid pixels in the full tiled image. It neither enforces a minimum ligament width nor rules out fragile necks, stress concentrations, or mechanisms. The interface costs are proxies derived from geometry and periodic-cell traction fields, not certified strength or stability constraints. No nonlinear simulation or fabrication experiment is reported.

'''
s=s[:pos]+table+s[pos:]
s=s.replace('\\begin{thebibliography}{9}',r'''\begin{thebibliography}{9}
\bibitem{cloak2022}
L. Wang, J. Boddapati, K. Liu, P. Zhu, C. Daraio, and W. Chen.
Mechanical cloak via data-driven aperiodic metamaterial design.
\emph{Proceedings of the National Academy of Sciences}, 119(13):e2122185119, 2022.
\href{https://doi.org/10.1073/pnas.2122185119}{doi:10.1073/pnas.2122185119}.

\bibitem{trussgpt}
J. Lin, B. Zhang, T. Ma, et al.
TrussGPT: large language model-driven inverse design framework for truss metamaterials.
\emph{npj Computational Materials}, 12:301, 2026.
\href{https://doi.org/10.1038/s41524-026-02175-x}{doi:10.1038/s41524-026-02175-x}.

\bibitem{opro}
C. Yang, X. Wang, Y. Lu, H. Liu, Q. V. Le, D. Zhou, and X. Chen.
Large language models as optimizers.
\emph{International Conference on Learning Representations}, 2024.
\href{https://arxiv.org/abs/2309.03409}{arXiv:2309.03409}.
''')
p.write_text(s)
print(len(s),'characters')
