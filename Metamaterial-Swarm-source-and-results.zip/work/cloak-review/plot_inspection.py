import sys
from pathlib import Path
sys.path.insert(0,str(Path('outputs/cloak-review').resolve()))
from cloak_adapter import CloakProblem
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap
p=CloakProblem('/Users/amirbaratifarimani/Downloads/Agent_Meta');phi=p.assemble(p.labels)
fig,axes=plt.subplots(1,3,figsize=(15,5),constrained_layout=True)
a=axes[0];a.imshow(p.indicator,origin='lower',cmap=ListedColormap(['white','#9867AD','#B9D8DD']),vmin=0,vmax=2)
a.axvline(14.5,ls='--',c='#253B55',lw=1);a.set_title('Domain classification\nwhite: void · purple: cloak · blue: outside');a.set(xlabel='Cell column',ylabel='Stored indicator row')
a=axes[1];a.imshow(phi,origin='upper',cmap='gray_r',interpolation='nearest');a.set_title('Assembly from supplied labels\n2.25 million pixel elements · one solid component');a.axis('off')
a=axes[2];masked=np.ma.array(p.labels,mask=~p.active);im=a.imshow(masked,origin='lower',vmin=0,vmax=14,cmap='viridis');a.set_title('Independent design variables\n168 active cells · labels 0–14');a.set(xlabel='Half-domain column',ylabel='Stored half-domain row');fig.colorbar(im,ax=a,fraction=.04)
fig.suptitle('Liwei Wang cloaking package — inspected geometry, no FEM performance claim',fontsize=15,weight='bold')
fig.savefig('outputs/cloak-review/package-inspection.png',dpi=220,bbox_inches='tight');fig.savefig('outputs/cloak-review/package-inspection.svg',bbox_inches='tight')
