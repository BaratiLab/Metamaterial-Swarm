from pathlib import Path
import numpy as np,h5py,json
from scipy.io import loadmat
from scipy.ndimage import label
r=Path('/Users/amirbaratifarimani/Downloads/Agent_Meta')
def mat(name):
 p=r/name
 if h5py.is_hdf5(p):
  with h5py.File(p) as f:return {k:np.asarray(v).T for k,v in f.items() if isinstance(v,h5py.Dataset)}
 return {k:v for k,v in loadmat(p).items() if not k.startswith('_')}
d={}
for p in r.rglob('*.mat'):d.update(mat(p.relative_to(r)))
I=d['Indicator'];L=d['Label'];ix=d['PhiIndex'].astype(int);P=I[2:-2,2:15];mask=P.ravel(order='C')==1
selected=ix[np.arange(338),L.ravel(order='C')]
print('shapes',[(k,v.shape) for k,v in d.items()]);print('halfregion',np.unique(P,return_counts=True));print('indicator symmetry',np.array_equal(I,I[:,::-1]))
print('PhiIndex zeros active',np.sum(ix[mask]==0),'inactive',np.sum(ix[~mask]==0),'selected active',selected[mask].min(),selected[mask].max());print('active unique geometry',len(np.unique(selected[mask])))
# MATLAB loop i visits half cells in C order, Label(temp) uses their F-order node IDs.
S=np.zeros((1300,650),np.uint8)
for i in range(338):
 y,x=divmod(i,13)
 cell=d['ShapeSpace'][:,:,selected[i]-1] if P[y,x]==1 else d['OriginCell'] if P[y,x]==2 else np.zeros((50,50),np.uint8)
 S[(25-y)*50:(26-y)*50,x*50:(x+1)*50]=cell[::-1,:]
phi=np.tile(d['OriginCell'],(30,30));phi[100:-100,100:-100]=np.concatenate([S,S[:,::-1]],axis=1)
interest=d['Interest']>0;node=interest[np.r_[np.arange(1500),1499]][:,np.r_[np.arange(1500),1499]]
u=d['UOrigin'].ravel();uv=u.reshape((1501,1501,2),order='C') # MATLAB x columns, y row, two interleaved DOFs -> x,y,component
valid=np.repeat(node.T.ravel(),2)
print('UOrigin overall',np.quantile(np.abs(u),[0,.5,.9,.99,1]));print('UOrigin interest',np.quantile(np.abs(u[valid]),[0,.5,.9,.99,1]));print('normoutside',np.linalg.norm(u[valid]),'mask pixels',interest.sum(),'nodes',node.sum())
cc,n=label(phi);counts=np.bincount(cc.ravel());print('assembledvf',phi.mean(),'components',n,'largestsolid',np.sort(counts[1:])[-8:]);print('Interest touches phi void',np.sum(interest&~phi.astype(bool)));print('outside baselinevf',d['OriginCell'].mean());print('Interest origin exact',np.sum(interest & (np.tile(d['OriginCell'],(30,30))==0)))
print('targetoutside fixed node deflection',u[[1501,2*1500*1501+1501,1500*1501+1500,1500*1501+1501]])
np.savez_compressed('work/cloak-review/audit_arrays.npz',indicator=I,passive=P,labels=L,phi=phi,interest=interest,target=u,candidates=ix,energy=d['Uenergy'],origin=d['OriginCell'])
