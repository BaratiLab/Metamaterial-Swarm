from pathlib import Path
import json,numpy as np,re,zipfile
p=Path('outputs/overleaf-metamaterial-selector/main.tex');s=p.read_text()
# Domain schematic, with changed cells from accepted actions.
fig=r'''\begin{figure}[htbp]
\centering\begin{tikzpicture}[x=.30cm,y=.30cm]
\fill[gray!8] (0,0) rectangle (30,4);
'''
for i in [94,61,93,33,101,57]:
 y,x=divmod(i,30);fig+=f'\\fill[magenta!60] ({x},{y}) rectangle ({x+1},{y+1});\n'
fig+=r'''\draw[step=1,gray!55,thin] (0,0) grid (30,4);
\draw[thick] (0,0) rectangle (30,4);
\draw[very thick] (0,0) -- (0,4);
\node[anchor=east,font=\small,align=right] at (-.5,2) {Clamped\\$u_x=u_y=0$};
\draw[<- ,thick] (30,2) -- (33,2);
\node[anchor=west,font=\small] at (30.5,4.9) {$u_x=-0.12$};
\node[font=\small] at (15,-1.1) {$30$ cells; each geometry has $50\times50$ pixels};
\node[font=\small] at (15,5.5) {Vertical response sampled on both outer edges};
\end{tikzpicture}
\caption{Discretized beam and loading. Colored cells are the six locations changed by accepted agent proposals relative to the initial numerical incumbent. The schematic shows locations, not the unit-cell microstructures. The right-edge corner vertical displacements are fixed at zero.}
\label{fig:domain}
\end{figure}

'''
s=s.replace('\\section{Shared target and candidate sets}',fig+'\\section{Shared target and candidate sets}')
# Plot the final retained responses from numerical records, no external dependency.
z=np.load('outputs/metamaterial-selector/problem.npz');h=json.loads(Path('outputs/metamaterial-selector/swarm/history.json').read_text())
r=json.loads(Path('outputs/metamaterial-selector/results.json').read_text())
fig=r'''\begin{figure}[htbp]\centering
'''
for j,title in enumerate(['Bottom edge','Top edge']):
 fig+=r'\begin{tikzpicture}\begin{axis}[width=.91\linewidth,height=4.4cm,xmin=0,xmax=30,xlabel={$x$/cell size},ylabel={$u_y$},grid=major,grid style={gray!15},title={'+title+r'},legend style={font=\footnotesize,at={(.5,1.18)},anchor=south,legend columns=3},tick label style={font=\small}]'+'\n'
 for values,style,name in [(z['target'],'black,dashed','Common target'),(r['deterministic_adjoint_top8']['_fine_profile'],'teal','Initial numerical'),(h['incumbent']['_fine_profile'],'magenta','Retained agent')]:
  coords=' '.join(f'({x},{float(v):.9f})' for x,v in enumerate(values[j*31:(j+1)*31]))
  fig+=r'\addplot['+style+r',line width=1pt] coordinates {'+coords+r'};'
  if j==0:fig+=r'\addlegendentry{'+name+'}'
  fig+='\n'
 fig+=r'\end{axis}\end{tikzpicture}\par\medskip'+'\n'
fig+=r'''\caption{Measured boundary responses of the initial numerical incumbent and final retained agent assembly against the common target. Both edge profiles contribute to the reported 62-coordinate error.}
\label{fig:finalprofiles}
\end{figure}

'''
s=s.replace('The final accepted round-three batch changes',fig+'The final accepted round-three batch changes')
s=s.replace('The Overleaf upload contains','The companion manuscript package contains')
s=s.replace('\\section{Acceptance and interpretation of connectivity}','\\clearpage\n\\section{Acceptance and interpretation of connectivity}')
s=s.replace('\\begin{thebibliography}{9}','\\clearpage\n\\begin{thebibliography}{9}')
# Order inline bibliography by first occurrence in manuscript.
a=s.index('\\bibitem');b=s.index('\\end{thebibliography}')
blocks=re.findall(r'\\bibitem\{([^}]+)\}([\s\S]*?)(?=\\bibitem|\Z)',s[a:b]);lookup=dict(blocks)
s=s[:a]+''.join('\\bibitem{'+k+'}'+lookup[k] for k in ['wang2020','cloak2022','dataset','trussgpt','opro'])+s[b:]
p.write_text(s)
Path('outputs/overleaf-metamaterial-selector/COMPILATION.txt').write_text('The expanded manuscript compiled successfully with the Codex native LaTeX compiler on 2026-10-02. Overleaf compilation is checked separately in Safari.\n')
print(len(s),'characters')
