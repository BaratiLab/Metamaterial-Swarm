from pathlib import Path
p=Path('outputs/overleaf-metamaterial-selector/main.tex');s=p.read_text()
macros=r'''
% Pictorial symbols are editable vector drawings, not simulated microstructures.
\newcommand{\robotglyph}[3]{%
\begin{scope}[shift={#1},scale=#2]
\draw[draw=#3,line width=1.1pt,fill=#3!10,rounded corners=3pt] (-.55,-.1) rectangle (.55,.65);
\draw[draw=#3,line width=1pt] (0,.65)--(0,.92);
\fill[#3] (0,.95) circle (.07);
\fill[#3] (-.24,.35) circle (.085);\fill[#3] (.24,.35) circle (.085);
\draw[#3,line width=1pt] (-.19,.12)--(.19,.12);
\draw[draw=#3,fill=#3!18,rounded corners=2pt] (-.38,-.65) rectangle (.38,-.18);
\draw[#3,line width=1.4pt] (-.38,-.3)--(-.67,-.48) (.38,-.3)--(.67,-.48);
\draw[#3,line width=1.5pt] (-.21,-.65)--(-.21,-.91) (.21,-.65)--(.21,-.91);
\fill[#3] (-.21,-.38) circle (.065);\fill[#3] (.21,-.38) circle (.065);
\end{scope}}
\newcommand{\tileglyph}[3]{%
\begin{scope}[shift={#1},scale=#2]
\fill[#3!8] (-.5,-.5) rectangle (.5,.5);
\draw[#3,line width=1.3pt] (-.5,-.5) rectangle (.5,.5);
\draw[#3,line width=2pt] (0,-.45)--(.45,0)--(0,.45)--(-.45,0)--cycle;
\draw[#3,line width=1pt] (-.5,-.5)--(-.24,-.24) (.5,-.5)--(.24,-.24) (-.5,.5)--(-.24,.24) (.5,.5)--(.24,.24);
\end{scope}}
\newcommand{\beamglyph}[3]{%
\begin{scope}[shift={#1},scale=#2]
\fill[#3!8] (-1.8,-.45) rectangle (1.8,.45);
\draw[#3,thick] (-1.8,-.45) rectangle (1.8,.45);
\foreach \x in {-1.35,-.9,-.45,0,.45,.9,1.35}{\draw[#3!55] (\x,-.45)--(\x,.45);}
\draw[#3!55] (-1.8,0)--(1.8,0);
\foreach \x in {-1.575,-1.125,-.675,-.225,.225,.675,1.125,1.575}{
\draw[#3!65,line width=.7pt] (\x,-.39)--(\x+.17,-.225)--(\x,-.06)--(\x-.17,-.225)--cycle;
\draw[#3!65,line width=.7pt] (\x,.06)--(\x+.17,.225)--(\x,.39)--(\x-.17,.225)--cycle;}
\draw[#3,very thick] (-1.88,-.58)--(-1.88,.58);
\draw[conceptflow,draw=#3] (2.35,0)--(1.85,0);
\end{scope}}
\newcommand{\profileglyph}[3]{%
\begin{scope}[shift={#1},scale=#2]
\draw[black!40,thin] (-1,-.5)--(-1,.65) (-1,-.5)--(1.1,-.5);
\draw[#3,dashed,thick] (-.95,-.45) .. controls (-.4,1.0) and (.4,1.0) .. (.95,-.45);
\draw[#3,line width=1.4pt] (-.95,-.45) .. controls (-.38,.86) and (.45,.95) .. (.95,-.45);
\end{scope}}
\newcommand{\shieldglyph}[3]{%
\begin{scope}[shift={#1},scale=#2]
\draw[#3,fill=#3!12,thick] (0,.65)--(.55,.45)--(.48,-.27)--(0,-.65)--(-.48,-.27)--(-.55,.45)--cycle;
\draw[#3,line width=2pt] (-.27,0)--(-.07,-.2)--(.3,.23);
\end{scope}}
'''
s=s.replace('\\title{',macros+'\n\\title{',1)
concept=r'''\begin{figure}[p]
\centering\resizebox{.96\linewidth}{!}{%
\begin{tikzpicture}[font=\sffamily\small]
\foreach \x/\col in {0/conceptblue,5/conceptteal,10/conceptamber}{
\draw[rounded corners=8pt,draw=\col!45,fill=\col!4,thick] (\x-2.1,-1.8) rectangle (\x+2.1,1.8);}
\node[font=\sffamily\bfseries] at (0,1.35) {UNIT-CELL LIBRARY};
\tileglyph{(-.72,.12)}{1.1}{conceptblue}\tileglyph{(.72,.12)}{1.1}{conceptpurple}
\node[conceptnote] at (0,-1.2) {90,245 geometries};
\node[font=\sffamily\bfseries] at (5,1.35) {DISCRETE ASSEMBLY};
\beamglyph{(5,.12)}{.85}{conceptteal}
\node[conceptnote] at (5,-1.2) {120 cells; 10 choices per cell};
\node[font=\sffamily\bfseries] at (10,1.35) {TARGET RESPONSE};
\profileglyph{(10,.12)}{1.2}{conceptamber}
\node[conceptnote] at (10,-1.2) {Loading + boundary profile};
\draw[conceptflow] (2.1,0)--(2.9,0);
\draw[conceptflow,draw=conceptamber] (7.9,0)--(7.1,0);
\node[conceptnote] at (5,-2.35) {Macro optimization and fixed candidate retrieval};
\draw[rounded corners=8pt,draw=conceptteal!50,fill=conceptteal!4,thick] (.2,-6.8) rectangle (4.8,-3.2);
\node[font=\sffamily\bfseries] at (2.5,-3.65) {PHYSICS FEEDBACK};
\profileglyph{(2.5,-4.75)}{1.2}{conceptteal}
\node[conceptnote,text width=4cm] at (2.5,-6.15) {Fine FEM + response adjoints\\Compatibility features};
\draw[rounded corners=8pt,draw=conceptpurple!50,fill=conceptpurple!4,thick] (6.2,-6.8) rectangle (10.8,-3.2);
\node[font=\sffamily\bfseries] at (8.5,-3.65) {ROBOT PROPOSAL TEAM};
\robotglyph{(7.1,-4.95)}{.8}{conceptblue}
\robotglyph{(8.5,-4.95)}{.8}{conceptpurple}
\robotglyph{(9.9,-4.95)}{.8}{conceptteal}
\node[conceptnote] at (8.5,-6.25) {Response \quad Interface \quad Cautious};
\draw[conceptflow] (5,-1.8)--(5,-2.7)-|(2.5,-3.2);
\draw[conceptflow,draw=conceptteal] (4.8,-5)--(6.2,-5);
\node[conceptnote,text width=1.5cm] at (5.5,-4.25) {shared\\evidence};
\draw[rounded corners=8pt,draw=conceptamber!50,fill=conceptamber!4,thick] (1.4,-12) rectangle (8.6,-8.2);
\node[font=\sffamily\bfseries] at (5,-8.7) {VALIDATE AND RETAIN};
\beamglyph{(4.3,-10)}{1}{conceptteal}
\shieldglyph{(7,-10)}{.85}{conceptteal}
\node[conceptnote] at (5,-11.3) {Commit proposals $\rightarrow$ simulate $\rightarrow$ keep eligible improvement};
\draw[conceptflow,draw=conceptpurple] (8.5,-6.8)--(8.5,-7.4)-|(5,-8.2);
\draw[conceptfeedback] (1.4,-10)--(-.5,-10)|-(.2,-5);
\node[conceptnote,rotate=90] at (-.9,-7.6) {next incumbent};
\node[font=\sffamily\bfseries\large,text=conceptteal] at (5,-12.7) {Observed case: $4.86\%\ \longrightarrow\ 3.92\%$};
\end{tikzpicture}}
\caption{Pictorial concept of physics-guided unit-cell selection. Patterned tiles and the beam are schematic illustrations, not the actual library geometries. Robot symbols represent computational LLM roles. Candidate retrieval follows continuous macro design; the agents use assembled-geometry feedback to propose existing labels, and fine finite elements determine whether a proposal improves. The percentage reduction is the measured single-target result.}
\label{fig:concept}
\end{figure}'''
swarm=r'''\begin{figure}[p]
\centering\resizebox{.96\linewidth}{!}{%
\begin{tikzpicture}[font=\sffamily\small]
\draw[rounded corners=8pt,draw=conceptblue!45,fill=conceptblue!4,thick] (-6.7,-1.5) rectangle (6.7,1.5);
\node[font=\sffamily\bfseries] at (0,1.05) {SHARED ROUND STATE};
\beamglyph{(-3.5,-.05)}{.8}{conceptblue}
\profileglyph{(3.4,-.05)}{.9}{conceptteal}
\node[conceptnote,text width=3cm] at (0,-.25) {Same geometry, candidates,\\target, and prior outcomes};
\foreach \x/\c/\role/\task in {-4.5/conceptblue/Response/Match displacement,0/conceptpurple/Interface/Preserve compatibility,4.5/conceptteal/Cautious/Limit uncertain changes}{
\robotglyph{(\x,-3.4)}{1.15}{\c}
\node[font=\sffamily\bfseries,text=\c] at (\x,-4.8) {\role};
\node[conceptnote] at (\x,-5.2) {\task};
\draw[conceptflow] (\x,-1.5)--(\x,-2.15);}
\draw[rounded corners=8pt,draw=conceptpurple!45,fill=conceptpurple!4,thick] (-6.7,-8) rectangle (2.7,-6.1);
\node[font=\sffamily\bfseries] at (-2,-6.5) {COMMIT THREE PROPOSALS};
\tileglyph{(-3.8,-7.2)}{.65}{conceptblue}
\tileglyph{(-2,-7.2)}{.65}{conceptpurple}
\tileglyph{(-.2,-7.2)}{.65}{conceptteal}
\node[conceptnote] at (-2,-7.8) {At most eight distinct-cell changes per proposal};
\draw[conceptflow,draw=conceptblue] (-4.5,-5.5)--(-4.5,-6.1);
\draw[conceptflow,draw=conceptpurple] (0,-5.5)--(0,-6.1);
\draw[conceptflow,draw=conceptteal] (4.5,-5.5)--(4.5,-5.8)-|(2.1,-6.1);
\draw[rounded corners=8pt,draw=black!30,fill=black!3] (3.3,-8.5) rectangle (6.7,-6.5);
\node[font=\sffamily\bfseries] at (5,-6.9) {NUMERICAL CONTROLS};
\draw[black!55,rounded corners=2pt,fill=white] (4.65,-8.1) rectangle (5.35,-7.2);
\draw[black!40] (4.75,-7.45) rectangle (5.25,-7.3);
\foreach \x in {4.8,5,5.2}{\foreach \y in {-7.7,-7.95}{\fill[black!50] (\x,\y) circle (.045);}}
\node[conceptnote] at (5,-8.3) {Fixed greedy caps: 1, 4, 8};
\draw[rounded corners=8pt,draw=conceptamber!45,fill=conceptamber!4,thick] (-6.7,-12) rectangle (6.7,-9.3);
\node[font=\sffamily\bfseries] at (0,-9.75) {COMMON PHYSICAL EVALUATOR};
\begin{scope}[shift={(-3.7,-10.65)}]
\fill[conceptamber!10] (-1,-.6) rectangle (1,.6);
\draw[step=.2,conceptamber!50,thin] (-1,-.6) grid (1,.6);
\draw[conceptamber,thick] (-1,-.6) rectangle (1,.6);
\end{scope}
\shieldglyph{(3.7,-10.65)}{.95}{conceptteal}
\node[conceptnote,text width=3.8cm] at (0,-10.7) {Six fine-FEM assessments\\Error + eligibility checks};
\node[conceptnote] at (0,-11.65) {Connectivity \quad Interface bounds \quad Volume bounds};
\draw[conceptflow] (-2,-8)--(-2,-9.3);
\draw[conceptflow,draw=black!55] (5,-8.5)--(5,-9.3);
\draw[rounded corners=8pt,draw=conceptteal!45,fill=conceptteal!5,thick] (-6.7,-15.25) rectangle (6.7,-12.9);
\node[font=\sffamily\bfseries] at (0,-13.35) {BEST ELIGIBLE IMPROVEMENT};
\beamglyph{(-2.7,-14.25)}{.8}{conceptteal}
\node[conceptnote,text width=4.6cm] at (2.5,-14.25) {Update the shared incumbent.\\If none improves, keep the current assembly.};
\draw[conceptflow] (0,-12)--(0,-12.9);
\draw[conceptfeedback] (-6.7,-14.2)--(-7.45,-14.2)|-(-6.7,0);
\node[conceptnote,rotate=90] at (-7.8,-7.1) {next round: evidence and measured outcomes};
\node[conceptnote] at (0,-15.9) {Three rounds; nine assessments per group. All outcomes are retained.};
\end{tikzpicture}}
\caption{Robot-role illustration of the executed multi-agent portfolio. Each agent independently reads the shared mechanical evidence and commits candidate replacements before within-round outcomes are observed. Agent and numerical proposals pass through one finite-element evaluator and retention rule. Cooperation occurs through shared evidence and the common incumbent, not direct robot communication or voting. The agents adapt their search strategies; numerical controls remain fixed. Tile motifs and robot icons are schematic.}
\label{fig:protocol}
\end{figure}'''
for label,fig in [('fig:concept',concept),('fig:protocol',swarm)]:
 b=s.index('\\label{'+label+'}');a=s.rfind('\\begin{figure}',0,b);e=s.index('\\end{figure}',b)+len('\\end{figure}');s=s[:a]+fig+s[e:]
p.write_text(s)
