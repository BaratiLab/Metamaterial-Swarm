from pathlib import Path
import json, shutil

root=Path('/Users/amirbaratifarimani/Documents/Codex/2026-10-02/files-mentioned-by-the-user-1')
src=root/'outputs/metamaterial-selector'
out=root/'outputs/overleaf-metamaterial-selector'
r=json.loads((src/'results.json').read_text())
target=json.loads((src/'feedback.json').read_text())['target_profile']
names=['nearest_property','graph_multistart_icm','deterministic_adjoint_top8','deterministic_adjoint_trust_region','llm_feedback_batch']
labels=['Nearest property','Graph selection','Numerical top eight','Constrained numerical','LLM-guided repair']
colors=['gray','blue','teal','orange','magenta']
table='\n'.join(f'{label} & {100*r[n]["fine_relative_error"]:.2f} & {100*r[n]["macro_relative_error"]:.2f} & {r[n]["mean_geometric_incompatibility"]:.4f} & {r[n]["mean_mechanical_incompatibility"]:.4f} \\\\' for n,label in zip(names,labels))
bars='\n'.join(r'\addplot[fill='+color+r'!65,draw=none,bar shift=0] coordinates {('+f'{100*r[n]["fine_relative_error"]:.4f},{5-i}'+')};' for i,(n,color) in enumerate(zip(names,colors)))
def coords(data):return ' '.join(f'({i},{v:.9f})' for i,v in enumerate(data))
plots=[]
for offset,title in [(0,'Bottom edge'),(31,'Top edge')]:
    p=r'\begin{tikzpicture}\begin{axis}[width=.91\linewidth,height=5.0cm,xmin=0,xmax=30,ymin=0,ymax=.10,xlabel={$x$/cell size},ylabel={Vertical displacement},title={'+title+r'},grid=major,grid style={gray!15},tick label style={font=\small}]'+'\n'
    p+=r'\addplot[black,dashed,line width=1.2pt] coordinates {'+coords(target[offset:offset+31])+ '};\n'
    for n,color in zip(names,colors):p+=r'\addplot['+color+r',line width=.9pt] coordinates {'+coords(r[n]['_fine_profile'][offset:offset+31])+ '};\n'
    p+=r'\end{axis}\end{tikzpicture}'
    plots.append(p)

text=r'''\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage{amsmath,amssymb,booktabs,array}
\usepackage{xcolor}
\usepackage{pgfplots}
\pgfplotsset{compat=1.18}
\usepackage{microtype}
\usepackage[hidelinks]{hyperref}
\usepackage{enumitem}
\setlist{nosep,leftmargin=*}
\setlength{\emergencystretch}{2em}
\title{LLM-Guided Selection of Heterogeneous Metamaterial Cells:\\A Controlled Real-Data Pilot}
\author{Research pilot report}
\date{October 2, 2026}
\begin{document}
\maketitle
\begin{abstract}
We investigate whether a large language model (LLM) can improve the discrete selection of unit cells in a heterogeneous mechanical metamaterial. A common macro-scale target and ten candidate geometries per location are supplied to all methods. Using a public library of 90,245 orthotropic cells, we assemble a $4\times30$-cell beam and assess its response with 300,000 quadrilateral finite elements. Independent property matching yields 20.73\% relative displacement error, whereas a multistart graph selector yields 9.93\%. Three methods then propose eight replacements from the same graph assignment using shared numerical feedback. Unconstrained and constrained numerical repairs yield 4.86\% and 8.54\% error, respectively; the assistant-guided LLM repair yields 10.82\%. Thus, the LLM does not improve the graph baseline in this single-target pilot. The discrepancy between homogenized predictions and assembled responses motivates feedback computed from the full geometry. These findings establish implementation feasibility, rather than statistical superiority or an exact reproduction of the motivating paper.
\end{abstract}

\section{Research question and scope}
Wang et al.~\cite{wang2020} propose a framework that combines variational autoencoder representations, mechanical-property prediction, macro-scale property optimization, and graph-based assembly of compatible microstructures. Domain discretization makes the assembly stage a discrete selection problem: one unit cell is assigned to each macro element, while neighboring choices affect interface geometry and mechanical transmission.

Our question is whether an LLM, acting as a selector supplied with mechanical evidence, can improve this assembly stage. We hold the candidate library, optimized target field, and loading conditions fixed. No generative model is retrained. The LLM chooses replacements among existing candidates; finite-element calculations provide the physical predictions.

This report describes an exploratory, assistant-in-the-loop experiment. It uses one target profile, one preparation seed, and one LLM decision batch. It does not constitute an automated benchmark of a fixed model snapshot, and no claim of improved performance over the original paper is made.

\section{Data and mechanical model}
\subsection{Public microstructure library}
The public dataset of Wang et al.~\cite{dataset} contains 90,245 binary $50\times50$ microstructures and their independently stored stiffness components $C_{11}$, $C_{12}$, $C_{22}$, and $C_{66}$, together with volume fraction. The constituent material has normalized Young's modulus $E=1$ and Poisson's ratio $\nu=0.35$. The downloaded files were checked against their published MD5 checksums. Pixel-derived volume fractions agree with the supplied property table.

In the plane-stress, engineering-shear convention, each orthotropic stiffness tensor is
\begin{equation}
\mathbf C=\begin{bmatrix}
C_{11}&C_{12}&0\\ C_{12}&C_{22}&0\\0&0&C_{66}
\end{bmatrix}.
\end{equation}
Only tensors with minimum eigenvalue greater than $10^{-5}$ are eligible for candidate retrieval.

\subsection{Domain, loading, and discretization}
The beam occupies a normalized $30\times4$ domain, partitioned into 120 square macro cells. The left edge is clamped. All right-edge horizontal displacements are prescribed at $-0.12$; the top and bottom right corners have zero vertical displacement. These boundary conditions are explicitly defined for this pilot.

The macro model uses four-node quadrilateral elements. For final assessment, each original pixel is represented by one element of side length $1/50$, giving 300,000 elements and 603,402 displacement degrees of freedom. Constitutive response is linear elastic and plane stress. Void is represented by an ersatz stiffness fraction $\eta=10^{-6}$:
\begin{equation}
\mathbf C_e=\left[\eta+(1-\eta)\rho_e\right]\mathbf C_{\mathrm{solid}},
\qquad \rho_e\in\{0,1\}.
\end{equation}
This regularization supports the numerical solve; solid connectivity is checked separately using four-neighbor pixel adjacency.

\section{Shared target and candidate sets}
\subsection{Continuous macro stage}
The requested vertical profile on both outer edges is
\begin{equation}
u_y^{\mathrm{requested}}(x)=0.08\sin^2\left(\frac{\pi x}{30}\right).
\end{equation}
The continuous stage parameterizes the local tensor as a softmax-weighted mixture of four tensors drawn from the library:
\begin{equation}
\mathbf C_i^*=\sum_{a=1}^{4}w_{ia}\mathbf C^{(a)},\qquad
w_{ia}=\frac{\exp(z_{ia})}{\sum_b\exp(z_{ib})}.
\end{equation}
The logits lie in $[-7,7]$ and are optimized using L-BFGS-B with adjoint gradients and preparation seed 20261002. A convex mixture remains positive definite, but need not be realizable by a single library geometry. The solver reached its 100-iteration limit, with approximately 0.87\% relative error against the requested arch. Convergence beyond this stopping limit was not established.

To isolate discrete selection from the residual error of this continuous stage, the primary comparison uses its \emph{achieved} boundary displacement vector, $\mathbf u^*$, as the common selection target. This definition is essential to interpreting the reported percentages.

\subsection{Candidate retrieval}
At each location, we select the ten eligible library tensors with the smallest maximum absolute difference from the target's four independent components. Sorting is deterministic. For candidate label $\ell$ at location $i$, the unary cost is
\begin{equation}
\theta_i(\ell)=\left\|\mathbf c_{i\ell}-\mathbf c_i^*\right\|_\infty,
\quad \mathbf c=(C_{11},C_{12},C_{22},C_{66})^{\mathsf T}.
\end{equation}
Every selector uses these identical candidate sets and unary costs.

\section{Selection and repair methods}
\subsection{Independent and graph baselines}
The independent baseline minimizes $\theta_i$ separately at each cell. The graph baseline instead minimizes
\begin{equation}
\mathcal E(\boldsymbol\ell)=\sum_i\theta_i(\ell_i)
+0.03\sum_{(i,j)\in\mathcal A}
\left[g_{ij}(\ell_i,\ell_j)+m_{ij}(\ell_i,\ell_j)\right],
\end{equation}
where $\mathcal A$ contains horizontally and vertically adjacent pairs. The geometric cost $g_{ij}$ is the number of unmatched solid pixels along a shared boundary divided by the solid union on that boundary, with a denominator floor of one. The mechanical cost $m_{ij}$ compares interface traction fields from periodic cell solves under three unit-strain load cases. It averages the relative Euclidean traction mismatch across those cases, normalizing by the sum of the two traction norms.

We approximately minimize this objective using 16-start iterated conditional modes (ICM), beginning with the independent assignment for one start and random labels for the others. Coordinate updates are repeated until no label changes or 80 sweeps are reached. The lowest-energy result is retained. This solver is not the dual-decomposition Markov random field algorithm used in the motivating paper.

\subsection{Common mechanical feedback}
Each repair method starts from the same graph assignment and receives candidate-wise first-order changes in the squared macro displacement error. With
\begin{equation}
J=\frac{\|\mathbf P\mathbf u-\mathbf u^*\|_2^2}{\|\mathbf u^*\|_2^2},
\end{equation}
$\mathbf P$ extracts the monitored boundary degrees of freedom. An adjoint solve gives
\begin{equation}
\mathbf K_{ff}^{\mathsf T}\boldsymbol\lambda_f
=\left(\frac{\partial J}{\partial\mathbf u}\right)_f,
\qquad
\frac{\partial J}{\partial\mathbf C_i}
=-\sum_q \boldsymbol\varepsilon_{\lambda,iq}
\otimes\boldsymbol\varepsilon_{u,iq}\,w_q.
\end{equation}
Here $f$ denotes free degrees of freedom and $w_q$ contains quadrature weights and the Jacobian determinant. Contracting this derivative with a candidate tensor change estimates $\Delta J$. The feedback also includes property mismatch, single-swap graph-energy changes, geometric and mechanical mismatch changes, volume fraction, and cell coordinates. These are homogenized-model estimates, not measured full-geometry repair outcomes.

\subsection{Numerical repair policies}
The top-eight numerical policy takes the most negative estimated $\Delta J$ at eight distinct cells. It commits all replacements in one batch, without updating the sensitivities between replacements.

The constrained numerical policy maximizes summed estimated gain through binary optimization, subject to: a gain budget of 40\% of the graph assignment's current squared macro error; a total nonnegative single-swap graph-cost budget of 0.08; no more than eight distinct-cell changes; individual geometric-cost increase at most 0.3; and individual graph-cost increase below 0.025. These exploratory budgets were chosen after baseline inspection and before observing any repair outcomes. They were not preregistered.

\subsection{LLM-guided repair}
The current Codex assistant examined the shared numerical evidence and the baseline macro and full-geometry profiles. It selected eight replacements, favoring modest predicted gains, low added interface mismatch, and spatially separated corrections. Its reasoning was that several of the largest first-order gains exceeded the entire current squared macro error, making a combined batch susceptible to overshoot.

The selected zero-based cell/label pairs were $(31,3)$, $(93,7)$, $(58,9)$, $(101,9)$, $(106,8)$, $(108,4)$, $(4,9)$, and $(104,9)$. The literal action file and all numerical comparator action files were saved before any repair outcome was evaluated. Each method received one full-geometry assessment of its committed batch. Action-file SHA-256 hashes were recorded with the results.

The exact underlying model snapshot and decoding settings were unavailable for this in-session decision. Consequently, numerical runs can be recreated from the stored actions, but the LLM decision itself is not a fully specified repeatable model experiment. LLM latency and token cost were not measured.

\section{Results}
The primary metric is
\begin{equation}
\epsilon_{\mathrm{fine}}=
\frac{\|\mathbf P_{\mathrm{fine}}\mathbf u_{\mathrm{fine}}-\mathbf u^*\|_2}{\|\mathbf u^*\|_2},
\end{equation}
evaluated at 31 macro-cell-boundary nodes on each of the top and bottom edges. The macro error is defined analogously. This normalization is specified for the pilot and is not assumed to reproduce every detail of the original paper's RRMSE.

\begin{table}[htbp]
\centering\small
\caption{Single-target results. Errors are percentages; interface costs are dimensionless averages. Lower values are preferred.}
\label{tab:results}
\begin{tabular}{@{}lrrrr@{}}\toprule
Method & Fine error & Macro error & Geometric & Mechanical\\\midrule
TABLE_ROWS
\bottomrule\end{tabular}
\end{table}

Graph selection reduced fine error from 20.73\% to 9.93\%. Numerical top-eight repair reduced it further to 4.86\%, approximately 51\% below the graph baseline. The constrained numerical repair yielded 8.54\%. The LLM repair instead increased the fine error to 10.82\%, approximately 9\% above the graph baseline.

All five solid assemblies consisted of one four-neighbor connected component. Their volume fractions ranged from 0.6331 to 0.6359. The best numerical repair increased both average interface costs relative to the graph baseline; therefore, its displacement gain is not an improvement across every reported objective.

\begin{figure}[htbp]
\centering
\begin{tikzpicture}
\begin{axis}[xbar,width=.97\linewidth,height=6.1cm,bar width=13pt,xmin=0,xmax=24,
ytick={1,2,3,4,5},yticklabels={LLM-guided repair,Constrained numerical,Numerical top eight,Graph selection,Nearest property},
xlabel={Full-geometry displacement error (\%)},tick label style={font=\small},
nodes near coords,point meta=x,nodes near coords style={font=\small},
every node near coord/.append style={/pgf/number format/fixed,/pgf/number format/precision=2}]
BAR_PLOTS
\end{axis}\end{tikzpicture}
\caption{Measured full-geometry errors for the common target. These are individual pilot outcomes, without uncertainty estimates.}
\end{figure}

\begin{figure}[p]
\centering
PROFILE_BOTTOM
\par\medskip
PROFILE_TOP
\par\smallskip
{\small \textcolor{black}{Dashed black: common target};
\textcolor{gray}{gray: nearest property};
\textcolor{blue}{blue: graph};
\textcolor{teal}{teal: numerical top eight};
\textcolor{orange}{orange: constrained numerical};
\textcolor{magenta}{magenta: LLM}.}
\caption{Full-geometry responses on both monitored outer edges. Coordinates are embedded in the source from the saved solver outputs, so this document compiles without external figure files.}
\label{fig:profiles}
\end{figure}

\section{Validation and interpretation}
The Q4 affine patch test and homogeneous periodic-cell test passed. Three independently recomputed cell tensors agreed with the supplied data to relative errors between $3.16\times10^{-6}$ and $6.26\times10^{-6}$. This sample checks constitutive conventions; it does not validate the entire library. A central finite-difference test agreed with the adjoint gradient to relative error $1.37\times10^{-7}$. Single-swap graph-energy changes agreed with full energy recomputation to absolute error below $10^{-15}$. Free-degree-of-freedom equilibrium residuals were below $2.4\times10^{-10}$ in all primary fine solves.

Reducing ersatz void stiffness from $10^{-6}$ to $10^{-7}$ changed the graph, top-eight numerical, and LLM fine errors by less than 0.0022 percentage points. Their ranking was unchanged. This is a regularization-sensitivity check; mesh convergence, nonlinear stability, and fabrication feasibility were not established.

The macro and fine models ranked the repairs differently. The LLM improved macro error from 4.40\% to 3.73\%, while worsening fine error from 9.93\% to 10.82\%. Conversely, the numerical top-eight batch worsened macro error to 14.34\% while producing the lowest fine error. These observations demonstrate that homogenized feedback did not reliably rank the discrete repairs in this experiment. They do not identify a unique causal mechanism or establish that LLM selection cannot be useful.

\section{Limitations and next experiment}
This is one target and one LLM decision batch, with no repeated-model statistics or held-out target evaluation. The public dataset uses $\nu=0.35$ and 90,245 geometries, whereas the 2020 study used $\nu=0.49$ and approximately 250,000. The continuous parameterization, stated loading conditions, and ICM assembly solver differ from the original framework. The 4.86\% result therefore cannot be claimed to beat the paper's reported 6\% beam error.

The next controlled experiment should compute repair sensitivities or local-response estimates from the assembled geometry, give numerical and LLM selectors identical evidence, and keep evaluation budgets equal. Several target profiles, multiple LLM runs with a fixed model version, explicit decoding settings, and manufacturing constraints are needed to test whether an LLM contributes beyond numerical optimization. A validated DD-MRF baseline would strengthen comparison with the motivating work.

\section{Conclusion}
An LLM can participate in unit-cell selection on a discretized metamaterial domain using structured candidates and mechanical feedback. This pilot implements that role on real geometries, but finds no performance advantage for its LLM repair. Numerical repair provides the strongest displacement result in the tested case. The useful outcome is a working controlled benchmark and evidence that assembled-geometry feedback should be tested before making broader claims of improved LLM selection.

\appendix
\section{Reproducibility materials}
The companion experiment archive contains the original MAT files and provenance, Python implementation, fixed candidate sets, complete numerical outputs, literal replacement actions, validation checks, and run manifest. The numerical implementation uses NumPy and SciPy; the recorded SciPy version is 1.11.1. Preparation uses seed 20261002, with \texttt{OPENBLAS\_NUM\_THREADS=1} and \texttt{OMP\_NUM\_THREADS=1}. All experiment indices are zero based.

The Overleaf upload contains this self-contained \texttt{main.tex}, the recorded metrics and checks, and a supplementary raster comparison figure. It does not include the complete simulation dataset or code; those remain in the separate experiment archive. Select pdfLaTeX and compile \texttt{main.tex}. The bibliography is inline, so no BibTeX step is required.

\begin{thebibliography}{9}
\bibitem{wang2020}
L. Wang, Y.-C. Chan, F. Ahmed, Z. Liu, P. Zhu, and W. Chen.
Deep generative modeling for mechanistic-based learning and design of metamaterial systems.
\emph{Computer Methods in Applied Mechanics and Engineering}, 372:113377, 2020.
\href{https://doi.org/10.1016/j.cma.2020.113377}{doi:10.1016/j.cma.2020.113377}.

\bibitem{dataset}
L. Wang, J. Boddapati, K. Liu, P. Zhu, C. Daraio, and W. Chen.
\emph{2D orthotropic metamaterial micorstructrue dataset}.
Figshare, version 1, 2021. CC BY 4.0.
\href{https://doi.org/10.6084/m9.figshare.17141975.v1}{doi:10.6084/m9.figshare.17141975.v1}.
\end{thebibliography}
\end{document}
'''
text=text.replace('TABLE_ROWS',table).replace('BAR_PLOTS',bars).replace('PROFILE_BOTTOM',plots[0]).replace('PROFILE_TOP',plots[1])
(out/'main.tex').write_text(text)
for f in ['metrics.csv','validation.json','void_sensitivity.json','run_manifest.json','llm_actions.json']:
    shutil.copy2(src/f,out/f)
shutil.copy2(src/'comparison.png',out/'supplementary-comparison.png')
(out/'UPLOAD.txt').write_text('OVERLEAF UPLOAD\n\n1. In Overleaf choose New Project > Upload Project.\n2. Select overleaf-metamaterial-selector.zip.\n3. Set main.tex as the main document and pdfLaTeX as the compiler.\n4. Recompile.\n\nThe source is self-contained: its plots embed the saved numerical coordinates.\nNo external figure files, BibTeX step, or shell escape are required.\nThe supplementary PNG is included for reference.\nThis upload is a pilot report, not an exact reproduction of the 2020 paper.\n')
print(out/'main.tex')
