from pathlib import Path
import zipfile,hashlib,json,shutil,ast
R=Path(__file__).resolve().parents[2];O=R/'outputs';P=O/'overleaf-metamaterial-selector';G=O/'github-upload';F=O/'paper-figures'
(P/'COMPILATION.txt').write_text('16 October 2026: existing Overleaf project 6ac0388d32d25cfdeb69eca6 compiled the updated source with Errors 0 and Warnings 0. Downloaded 19-page PDF text and all rendered pages inspected, including authors and Figures 4–6. The built-in standalone compiler cannot load the two external PNG project assets; its preview is therefore not verified for this multi-file version. Use Overleaf or a normal project compiler. No local TeX installation was used.\n')
(P/'UPLOAD.txt').write_text('Updated 16 October 2026. Existing Overleaf project synchronized. Compile main.tex with pdfLaTeX; keep cloak-structure-evolution.png and cloak-stress-fields.png alongside it. Other diagrams and stress profiles are editable TikZ/PGFPlots in main.tex. Liwei Wang is first author; Amir Barati Farimani is corresponding author. Four CMU affiliations and public correspondence email included. Funding, conflicts, and final author contributions require author confirmation before submission. Original Agent_Meta inputs are separate.\n')
read=(G/'README.md').read_text().replace('[Standalone LaTeX source](main.tex): embeds all manuscript diagrams and plots; compile with pdfLaTeX without external graphics or BibTeX.','[LaTeX source](main.tex): compile with pdfLaTeX and the two PNG files alongside it; no BibTeX database is required.').replace('Author identities and journal declarations remain deferred and must be completed before submission.','Liwei Wang is first author; Amir Barati Farimani is corresponding author, with CMU Mechanical Engineering, Chemical Engineering, Materials Science and Engineering, and Machine Learning affiliations. Final contributions, funding, and conflict declarations still require author review.').replace('rewritten standalone manuscript','rewritten manuscript and required image assets').replace('We thank Liwei Wang for the separate cloak assignment, evaluator, and summary; this does not imply endorsement of the new claims.','Liwei Wang supplied the separate cloak assignment, evaluator, and summary and is listed as first author of the working manuscript; all authors must review the final claims.')
read=read.replace('## Complete source distribution','''## Actual structures and recovered stresses

![Actual retained structures](cloak-structure-evolution.png)

![Stress fields on actual geometries](cloak-stress-fields.png)

![Exterior stress profiles](cloak-stress-profiles.png)

The new figures use original pixel geometries and saved fine displacement fields, with no new equilibrium solves. Q4 center-stress recovery passes stiffness quadrature and affine-patch checks. Local fields share color limits; clipped extrema are disclosed. Stress was not an optimization objective: fixed-exterior tensor mismatch is 11.6298% supplied, 11.8811% numerical, and 11.5985% hybrid. The displacement improvement does not imply a comparable stress improvement. Data and recovery checks are in the source archive; high-resolution publication exports are in [paper-figures.zip](paper-figures.zip).

## Complete source distribution''') if '## Actual structures and recovered stresses' not in read else read
read=read.replace('including all project-authored Python/MATLAB code, recorded proposals, outcomes, figure-generation source, and rewritten paper.','including all project-authored Python/MATLAB code, recorded proposals, outcomes, figure-generation source, and rewritten paper. Rendered PNG/PDF/SVG assets are distributed in the separate publication-figure and Overleaf archives to keep each upload below GitHub’s per-file limit; required paper PNGs are also at repository root.')
(G/'README.md').write_text(read)
for name in ['main.tex','metamaterial-swarm-paper.pdf','cloak-structure-evolution.png','cloak-stress-fields.png']:shutil.copy2(P/name,G/name)
shutil.copy2(F/'cloak-stress-profiles.png',G/'cloak-stress-profiles.png')
def bundle(dest,files,base):
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for f in sorted(files):z.write(f,f.relative_to(base))
bundle(O/'overleaf-metamaterial-selector.zip',[p for p in P.rglob('*') if p.is_file()],P)
shutil.copy2(O/'overleaf-metamaterial-selector.zip',G/'overleaf-metamaterial-selector.zip')
bundle(G/'paper-figures.zip',[p for p in F.rglob('*') if p.is_file() and not p.name.startswith('embedded-raster')],F)
bundle(G/'cloak-coordination-results.zip',[p for p in (O/'cloak-coordination').rglob('*') if p.is_file() and '__pycache__' not in str(p)],O/'cloak-coordination')
roots=['metamaterial-selector','cloak-experiment','cloak-review','cloak-coordination','overleaf-metamaterial-selector','agent-figures','paper-figures'];files=[]
for name in roots:
 files += [p for p in (O/name).rglob('*') if p.is_file() and p.suffix not in ['.png','.pdf','.svg','.pyc'] and '__pycache__' not in str(p) and not p.name.startswith('embedded-raster')]
files += [p for p in (R/'work').rglob('*.py') if 'cloak-runtime' not in str(p) and '__pycache__' not in str(p)]
files += [R/'work/manuscript-revision/stress-paper-section.tex']
files=sorted(set(files)); records=[]
for p in files:
 if p.suffix=='.py':ast.parse(p.read_text())
 records.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(G/'MANIFEST.json').write_text(json.dumps(records,indent=2))
bundle(G/'Metamaterial-Swarm-source-and-results.zip',files,R)
for p in G.iterdir():
 assert p.stat().st_size<25_000_000,(p,p.stat().st_size)
 print(p.name,p.stat().st_size)
record={'main_sha256':hashlib.sha256((P/'main.tex').read_bytes()).hexdigest(),'pdf_sha256':hashlib.sha256((P/'metamaterial-swarm-paper.pdf').read_bytes()).hexdigest(),'pages':19,'overleaf_errors':0,'overleaf_warnings':0,'native_preview':'external project images unsupported','source_files':len(files),'stress_new_solves':0}
(R/'work/manuscript-revision/revision-verification.json').write_text(json.dumps(record,indent=2))
