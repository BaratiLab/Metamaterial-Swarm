"""One editable scene exported to TikZ, SVG, PDF, and PNG for Figure 1."""
from pathlib import Path
import json, math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,Rectangle,Circle,Polygon,FancyArrowPatch
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/paper-figures';OUT.mkdir(exist_ok=True)
C={'ink':'#193248','muted':'#526777','blue':'#227DA9','purple':'#8954B0','teal':'#168C88','amber':'#C68A29','line':'#CBD8DF','pale':'#F4F8FA','white':'#FFFFFF','green':'#298367','red':'#BF606A'}
scene=[]
def box(x,y,w,h,fill='white',stroke='line',radius=.15,lw=.8):scene.append(dict(t='box',x=x,y=y,w=w,h=h,fill=C.get(fill,fill),stroke=C.get(stroke,stroke),r=radius,lw=lw))
def line(points,color='ink',lw=.9,dash=False,arrow=False):scene.append(dict(t='line',pts=points,color=C.get(color,color),lw=lw,dash=dash,arrow=arrow))
def circle(x,y,r,fill='white',stroke='ink',lw=.8):scene.append(dict(t='circle',x=x,y=y,r=r,fill=C.get(fill,fill),stroke=C.get(stroke,stroke),lw=lw))
def polygon(points,fill='white',stroke='ink',lw=.8):scene.append(dict(t='poly',pts=points,fill=C.get(fill,fill),stroke=C.get(stroke,stroke),lw=lw))
def text(x,y,s,size=8,color='ink',bold=False,align='center',rotation=0):scene.append(dict(t='text',x=x,y=y,s=s,size=size,color=C.get(color,color),bold=bold,align=align,rotation=rotation))
def robot(x,y,c,scale=.8):
 def b(dx,dy,w,h,**kw):box(x+dx*scale,y+dy*scale,w*scale,h*scale,**kw)
 b(-.49,-.08,.98,.67,fill='white',stroke=c,radius=.13)
 line([(x,y+.59*scale),(x,y+.82*scale)],c,1.1);circle(x,y+.88*scale,.065*scale,c,c)
 for dx in [-.22,.22]:circle(x+dx*scale,y+.31*scale,.067*scale,c,c)
 line([(x-.16*scale,y+.09*scale),(x+.16*scale,y+.09*scale)],c,1.2)
 b(-.31,-.62,.62,.43,fill='white',stroke=c,radius=.08)
 circle(x,y-.38*scale,.085*scale,c,c)
 line([(x-.31*scale,y-.31*scale),(x-.58*scale,y-.44*scale)],c,1.3)
 line([(x+.31*scale,y-.31*scale),(x+.57*scale,y-.20*scale)],c,1.3)
 for dx in [-.17,.17]:line([(x+dx*scale,y-.62*scale),(x+dx*scale,y-.84*scale)],c,1.4)
def tile(x,y,c,size=.75,kind=0):
 box(x-size/2,y-size/2,size,size,stroke=c,radius=.025)
 a=.42*size
 if kind==0:
  line([(x,y-a),(x+a,y),(x,y+a),(x-a,y),(x,y-a)],c,1.2)
  for sx in [-1,1]:
   for sy in [-1,1]:line([(x+sx*size/2,y+sy*size/2),(x+sx*a/2,y+sy*a/2)],c,.65)
 elif kind==1:
  circle(x,y,.26*size,'white',c,1.2)
  line([(x-size/2,y),(x-.26*size,y)],c,1.1);line([(x+.26*size,y),(x+size/2,y)],c,1.1)
  line([(x,y-size/2),(x,y-.26*size)],c,1.1);line([(x,y+.26*size),(x,y+size/2)],c,1.1)
 else:
  line([(x-size/2,y-size/2),(x+size/2,y+size/2)],c,1.1);line([(x-size/2,y+size/2),(x+size/2,y-size/2)],c,1.1)
def cloak(x,y,size=2.0):
 # Schematic discretization: colors indicate selectable cloak cells, not FEM fields.
 n=12;h=size/n
 for iy in range(n):
  for ix in range(n):
   dx=ix+0.5-n/2;dy=iy+0.5-n/2;r=(dx*dx+dy*dy)**.5
   if r<2.1:continue
   col='line' if r>4.7 else ['blue','teal','purple','amber'][(ix+iy*2)%4]
   box(x-size/2+ix*h,y-size/2+iy*h,h,h,fill='white',stroke=col,radius=0,lw=.35)
   if r<4.7:line([(x-size/2+ix*h,y-size/2+iy*h),(x-size/2+(ix+1)*h,y-size/2+(iy+1)*h)],col,.35)
 for side in [-1,1]:line([(x+side*(size/2+.48),y),(x+side*(size/2+.05),y)],'ink',1,arrow=True)
def curveplot(x,y,c):
 line([(x-.5,y-.4),(x-.5,y+.45)],'line',.7);line([(x-.5,y-.4),(x+.6,y-.4)],'line',.7)
 pts=[(x-.45+i/20,y-.30+.62*math.sin(math.pi*i/20)) for i in range(21)]
 line(pts,c,1.3);line([(a,b-.08+.025*math.sin(i)) for i,(a,b) in enumerate(pts)],c,.8,dash=True)

text(.25,13.55,'A   DISCRETIZED METAMATERIAL DESIGN',10,bold=True,align='left')
for x,w in [(.25,4.05),(4.9,6.2),(11.7,4.05)]:box(x,10.25,w,2.87,fill='pale')
text(2.275,12.78,'CANDIDATE LIBRARY',8.8,bold=True)
for i in range(3):tile(1.15+1.1*i,11.75,['blue','purple','teal'][i],.83,i)
text(2.275,10.88,'90,245 stored unit cells',8)
text(2.275,10.50,'15 choices at each active cell',7.5,'muted')
cloak(8.0,11.73,1.88)
text(8.0,10.55,'168 independent cloak cells',8,bold=True)
text(13.725,12.78,'TARGET + LOADING',8.8,bold=True)
curveplot(13.65,11.72,'teal')
text(13.725,10.88,'Match exterior displacement',7.8)
text(13.725,10.50,'Fixed mask and reference',7.5,'muted')
line([(4.31,11.72),(4.85,11.72)],'blue',1.2,arrow=True)
line([(11.68,11.72),(11.15,11.72)],'teal',1.2,arrow=True)

text(.25,9.72,'B   COMPLEMENTARY PROPOSALS',10,bold=True,align='left')
for x,col in [(.25,'blue'),(5.55,'purple'),(10.85,'teal')]:
 box(x,6.0,4.9,3.24,fill='white',stroke=col,lw=1)
 box(x,8.70,4.9,.54,fill=col,stroke=col,radius=.11)
text(2.70,8.97,'NUMERICAL TOOL',8.8,'white',True)
text(8.0,8.97,'RESPONSE AGENT',8.8,'white',True)
text(13.3,8.97,'INTERFACE AGENT',8.8,'white',True)
# Numerical tool is deliberately a calculator, not a language-model robot.
box(1.05,7.12,1.0,1.24,stroke='blue',radius=.12,lw=1.1)
box(1.18,7.95,.74,.25,fill='pale',stroke='blue',radius=.02)
for xx in [1.26,1.55,1.84]:
 for yy in [7.34,7.64]:circle(xx,yy,.065,'blue','blue')
curveplot(3.63,7.72,'blue')
text(2.70,6.65,'Calibrate scores',8.3,bold=True)
text(2.70,6.29,'Nominate a numerical repair',7.7,'muted')
robot(6.87,7.75,'purple',.78)
tile(8.63,7.78,'purple',.52,0);tile(9.23,7.78,'purple',.52,1)
line([(8.56,7.20),(8.79,6.99),(9.25,7.38)],'purple',1.2)
text(8,6.65,'Compose + ablate',8.3,bold=True)
text(8,6.29,'Learn which changes help',7.7,'muted')
robot(12.10,7.75,'teal',.78)
for xx in [13.83,14.45]:
 for yy in [7.40,8.02]:tile(xx,yy,'teal',.57,1)
line([(14.14,7.15),(14.14,8.30)],'amber',1.3,dash=True)
text(13.3,6.65,'Match + extend interfaces',8.3,bold=True)
text(13.3,6.29,'Test compatible cell groups',7.7,'muted')
for x in [2.7,8,13.3]:line([(x,9.47),(x,9.27)],'muted',.9,arrow=True)
line([(8,10.22),(8,9.47),(2.7,9.47)],'muted',.8)
line([(8,9.47),(13.3,9.47)],'muted',.8)

box(.65,5.04,14.7,.61,fill='pale',stroke='line',radius=.10)
text(7.8,5.35,'SHARED LOG:  incumbent  |  predictions  |  measured successes + failures',8,'muted')
for x in [2.7,8,13.3]:
 line([(x-.10,6),(x-.10,5.69)],'muted',.9,arrow=True)
 line([(x+.10,5.69),(x+.10,6)],'teal',.75,arrow=True)
line([(4.0,5.03),(4.0,4.69)],'amber',1.1,arrow=True)
text(.25,4.82,'C',10,bold=True,align='left')
box(.65,2.93,6.73,1.72,fill='pale',stroke='amber',lw=1)
robot(1.56,3.72,'amber',.64)
text(4.61,4.24,'COORDINATOR',9.2,bold=True)
text(4.61,3.77,'Diversify / validate / commit',8.3)
text(4.61,3.30,'3 fresh proposals; up to 4 swaps each',7.3,'muted')
line([(7.42,3.80),(8.96,3.80)],'amber',1.2,arrow=True)
text(8.2,4.20,'HASH',7,'amber',True)
box(9.0,2.93,6.75,1.72,fill='pale',stroke='blue',lw=1)
for iy in range(5):
 for ix in range(5):
  color=['#E5F1F4','#BEDDE8','#88BACA','#4E93B4','#227DA9'][(ix+iy)//2]
  box(9.47+.21*ix,3.26+.21*iy,.21,.21,fill=color,stroke='white',radius=0,lw=.18)
text(13.1,4.24,'FULL-RESOLUTION FEM',8.8,bold=True)
text(13.1,3.77,'Solve equilibrium',8.3)
text(13.1,3.30,'Measure the masked loss',7.8,'muted')
line([(12.1,2.90),(12.1,2.48),(10.65,2.48),(10.65,2.19)],'blue',1.1,arrow=True)

box(3.10,.48,9.9,1.68,fill='#EDF7F2',stroke='green',lw=1)
polygon([(4.07,1.91),(4.55,1.72),(4.47,1.09),(4.07,.77),(3.67,1.09),(3.59,1.72)],fill='white',stroke='green',lw=1)
line([(3.83,1.35),(4.01,1.16),(4.33,1.60)],'green',1.5)
text(8.4,1.72,'RETAIN ONLY IMPROVEMENTS',9.4,'green',True)
text(8.4,1.22,'Update the design; record every outcome',8.2)
text(8.4,.79,'10 rounds x 3 new FEM evaluations per method',7.4,'muted')
line([(13.04,1.30),(16.12,1.30),(16.12,5.35),(15.40,5.35)],'teal',1.1,dash=True,arrow=True)
text(16.40,3.25,'MEASURED FEEDBACK',7.5,'teal',True,rotation=90)

fig,ax=plt.subplots(figsize=(7.1,5.85));fig.subplots_adjust(0,0,1,1);ax.set(xlim=(0,16.68),ylim=(.12,13.95));ax.set_aspect('equal');ax.axis('off')
for a in scene:
 if a['t']=='box':ax.add_patch(FancyBboxPatch((a['x'],a['y']),a['w'],a['h'],boxstyle=f"round,pad=0,rounding_size={a['r']}",facecolor=a['fill'],edgecolor=a['stroke'],linewidth=a['lw']))
 elif a['t']=='circle':ax.add_patch(Circle((a['x'],a['y']),a['r'],facecolor=a['fill'],edgecolor=a['stroke'],linewidth=a['lw']))
 elif a['t']=='poly':ax.add_patch(Polygon(a['pts'],closed=True,facecolor=a['fill'],edgecolor=a['stroke'],linewidth=a['lw']))
 elif a['t']=='line':
  pts=a['pts'];ls=(0,(3,2)) if a['dash'] else '-'
  for i in range(len(pts)-1):
   if a['arrow'] and i==len(pts)-2:ax.add_patch(FancyArrowPatch(pts[i],pts[i+1],arrowstyle='-|>',mutation_scale=9,linewidth=a['lw'],color=a['color'],linestyle=ls,shrinkA=0,shrinkB=0))
   else:ax.plot(*zip(pts[i],pts[i+1]),color=a['color'],lw=a['lw'],linestyle=ls)
 elif a['t']=='text':ax.text(a['x'],a['y'],a['s'],ha=a['align'],va='center',fontsize=a['size'],color=a['color'],weight='bold' if a['bold'] else 'normal',rotation=a['rotation'],fontfamily='DejaVu Sans')
for ext in ['pdf','svg','png']:fig.savefig(OUT/f'figure1-coordinated-workflow.{ext}',dpi=260,facecolor='white')
plt.close(fig)
# LaTeX uses the same primitive scene; no external image files are needed.
colors=sorted({v for a in scene for k,v in a.items() if k in ['fill','stroke','color']})
cm={c:f'figc{i}' for i,c in enumerate(colors)}
tex=['% Generated from the same scene as figure1-coordinated-workflow.svg',*[rf'\definecolor{{{cm[c]}}}{{HTML}}{{{c[1:]}}}' for c in colors],r'\begin{tikzpicture}[x=1cm,y=1cm]']
def point(p):return '(%.4f,%.4f)'%tuple(p)
def esc(s):return s.replace('&',r'\&').replace('%',r'\%').replace('_',r'\_')
for a in scene:
 if a['t']=='box':tex.append(r'\draw[fill=%s,draw=%s,line width=%.2fpt,rounded corners=%.3fcm] %s rectangle %s;'%(cm[a['fill']],cm[a['stroke']],a['lw'],a['r'],point((a['x'],a['y'])),point((a['x']+a['w'],a['y']+a['h']))))
 elif a['t']=='circle':tex.append(r'\draw[fill=%s,draw=%s,line width=%.2fpt] %s circle (%.4fcm);'%(cm[a['fill']],cm[a['stroke']],a['lw'],point((a['x'],a['y'])),a['r']))
 elif a['t']=='poly':tex.append(r'\draw[fill=%s,draw=%s,line width=%.2fpt] %s -- cycle;'%(cm[a['fill']],cm[a['stroke']],a['lw'],' -- '.join(map(point,a['pts']))))
 elif a['t']=='line':tex.append(r'\draw[draw=%s,line width=%.2fpt%s%s] %s;'%(cm[a['color']],a['lw'],',dashed' if a['dash'] else '',',-{Stealth[length=1.8mm]}' if a['arrow'] else '',' -- '.join(map(point,a['pts']))))
 elif a['t']=='text':tex.append(r'\node[anchor=%s,text=%s,rotate=%d,font=\sffamily%s\fontsize{%.2f}{%.2f}\selectfont,inner sep=0pt] at %s {%s};'%('west' if a['align']=='left' else 'center',cm[a['color']],a['rotation'],r'\bfseries' if a['bold'] else '',a['size'],a['size']*1.2,point((a['x'],a['y'])),esc(a['s'])))
tex.append(r'\end{tikzpicture}')
(OUT/'figure1-body.tex').write_text('\n'.join(tex))
(OUT/'figure1-scene.json').write_text(json.dumps(scene,indent=2))
print('Exported editable Figure 1 in TikZ, SVG, PDF, PNG, and JSON')
