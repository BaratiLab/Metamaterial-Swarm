"""Rewrite the existing manuscript from preserved numerical records."""
from pathlib import Path
import json,numpy as np,sys
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/overleaf-metamaterial-selector'
C=ROOT/'outputs/cloak-coordination'
states={a:json.loads((C/a/'state.json').read_text()) for a in ['numerical','hybrid']}
figure1=(ROOT/'outputs/paper-figures/figure1-body.tex').read_text()
preamble=r'''\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage{amsmath,amssymb,booktabs,array,longtable}
\usepackage{xcolor,graphicx,tikz}
\usetikzlibrary{arrows.meta,positioning,fit,backgrounds}
\usepackage{pgfplots}
\pgfplotsset{compat=1.18}
\usepgfplotslibrary{groupplots}
\usepackage{microtype}
\usepackage[hidelinks]{hyperref}
\usepackage{enumitem}
\setlist{nosep,leftmargin=*}
\setlength{\emergencystretch}{2em}
\definecolor{numblue}{HTML}{227DA9}
\definecolor{agentpurple}{HTML}{8954B0}
\definecolor{agentteal}{HTML}{168C88}
\definecolor{warmamber}{HTML}{C68A29}
\newcommand{\eps}{\varepsilon}
\title{Coordinated Language Agents for Discrete Metamaterial Assembly:\\A Physics-Validated Mechanical Cloaking Study}
\author{Liwei Wang\textsuperscript{1} \and Amir Barati Farimani\textsuperscript{1,2,3,4,*}}
\date{\small
\textsuperscript{1}Department of Mechanical Engineering\\
\textsuperscript{2}Department of Chemical Engineering\\
\textsuperscript{3}Department of Materials Science and Engineering\\
\textsuperscript{4}Machine Learning Department\\
Carnegie Mellon University, 5000 Forbes Avenue, Pittsburgh, PA 15213, USA\\[4pt]
\textsuperscript{*}Corresponding author: \href{mailto:barati@cmu.edu}{barati@cmu.edu}}
\begin{document}
\maketitle
\begin{abstract}
Selecting microstructures for a heterogeneous metamaterial is a global mechanical problem: locally suitable cells can produce an inaccurate assembled response. We investigate a coordinated search system in which language agents select existing unit-cell labels using numerical evidence and measured finite-element outcomes. A numerical proposer, response specialist, and interface specialist contribute complementary candidates; a coordinator suppresses duplicate assignments and commits proposals before evaluation. The primary case is mechanical cloaking with 168 independent selectable cells, 15 candidates per cell, and a full discretization of 2.25 million quadrilateral elements. A Python port preserves the supplied model and reproduces its monitored reference displacement to relative difference $1.29\times10^{-10}$. Starting from the same supplied assignment and identical 18-trial historical ledger, a coordinated hybrid and a frozen adaptive numerical portfolio each receive 30 new full-resolution evaluations. Masked displacement loss decreases from 12.7610\% to 10.6946\% for the hybrid and to 11.6308\% for numerical search: relative reductions of 16.19\% and 8.86\%, respectively. The hybrid's final loss is 8.05\% lower than this comparator. Matched proposal pairs document useful context-specific ablations, and final force-balance checks pass. An earlier beam experiment supplies supporting evidence, including a failed initial language-guided repair. This exploratory case supports combining agent coordination with numerical optimization; it does not establish general superiority, isolate the causal effect of coordination, or replace mechanical validation.
\end{abstract}
\noindent\textbf{Keywords:} metamaterial assembly; mechanical cloaking; language agents; discrete optimization; finite elements; experimental coordination.

\section{Introduction}
Heterogeneous mechanical metamaterials distribute different microstructures across a domain to produce a desired structural response. A unit-cell library turns topology generation into a discrete assembly problem, but the resulting design remains globally coupled through equilibrium. Neighboring cells must transmit deformation, and a close match to a target constitutive tensor does not guarantee a close match to the target displacement field.

Data-driven design frameworks already combine learned microstructure representations, property optimization, and compatibility-aware assembly~\cite{wang2020}. Database-driven aperiodic tiling has also been demonstrated for mechanical cloaks~\cite{cloak2022}. These methods motivate a narrower question: can language agents help select and repair an assembly when candidate geometries, loading, and an objective are already defined? We study selection among existing geometries. We do not retrain a generative model, generate new topologies, or ask a language model to replace the equilibrium solver.

The proposed system treats coordination as an experimental-design task. A numerical tool nominates a repair from calibrated surrogate scores. A response agent combines useful changes and proposes informative ablations. An interface agent examines neighboring geometries and tests compatible groups. The coordinator checks novelty and action validity, then commits three proposals before their measured outcomes are available. Full-resolution finite elements determine which proposal, if any, becomes the next incumbent. The shared ledger retains successes and failures so that subsequent proposals can test specific explanations rather than merely repeat promising-looking scores.

The primary evidence is a mechanical-cloaking case supplied with an assignment, candidate sets, target displacement, and MATLAB evaluator. We first audit its conventions and validate a memory-conscious Python port. We then compare independent hybrid and numerical trajectories at 30 new candidate evaluations each, with the same initial design and the same archived trial history. The hybrid reaches 10.6946\% masked displacement loss, compared with 11.6308\% for the specified adaptive numerical comparator. Figure~\ref{fig:workflow} summarizes the implemented system.

The contributions are (i) an auditable discrete cloaking benchmark at the supplied pixel resolution, (ii) a coordinated proposal protocol combining numerical repair, empirical response reasoning, and interface reasoning, and (iii) complete measured trajectories with matched proposal contrasts and numerical checks. These are contributions of an exploratory computational study. We do not claim a new constitutive theory, global optimality, the first use of language models in metamaterial design, or superiority over the original published design algorithms.
'''
f1=r'''
\begin{figure}[p]
\centering
\resizebox{.99\linewidth}{!}{%
'''+figure1+r'''}
\caption{Overall coordinated selection algorithm. (A) A discretized cloak is populated from fixed local candidate sets, with a fixed exterior target and loading. (B) The numerical tool calibrates scores and nominates a repair; the response LLM agent proposes compositions and ablations; the interface LLM agent tests compatible cell groups and spatial extensions. The shared log carries incumbent assignments, predictions, and all measured outcomes. (C) Coordination combines agent discussion with deterministic validity and novelty checks. Three assignments are hash-committed before full-resolution FEM, and only a measured improvement can replace the incumbent. Robot symbols identify language-agent responsibilities; the calculator and FEM block identify numerical tools. Tiles, domain, curves, and mesh are schematic, not measured response fields. The depicted ten-round budget applies separately to each method; the numerical-only comparator fills all three slots with its numerical portfolio.}
\label{fig:workflow}
\end{figure}
'''
body=r'''
\section{Related work and scope}
\subsection{Microstructure libraries and mechanical cloaking}
Wang et al.~\cite{wang2020} combine a variational autoencoder, property prediction, continuous target design, and graph-based assembly. Their later cloaking study~\cite{cloak2022} uses a precomputed database to fill optimized heterogeneous regions around voids. Our work retains a supplied cavity, cloak region, candidate sets, and target; it studies local label repair after those upstream choices. The public orthotropic library~\cite{dataset} provides the cell geometry and property data used in the earlier beam pilot and matches the geometry and property arrays in the supplied cloak package.

Our numerical comparator is an adaptive local-search portfolio, not the dual-decomposition Markov-random-field algorithm of Ref.~\cite{wang2020}. No trained graph neural network (GNN) selector is evaluated. Consequently, neither the beam nor cloak errors below can be presented as a direct performance improvement over those published systems or over GNNs generally.

\subsection{Language-guided search and tool use}
Optimization by prompting~\cite{opro} places evaluated solutions in the context for subsequent language-model proposals. ReAct~\cite{react} interleaves reasoning with actions and observations, while AutoGen~\cite{autogen} develops conversable multi-agent systems with tool access. These provide relevant patterns for iterative proposal and feedback. Our application adds a fixed discrete material-action space, expensive mechanical evaluation, pre-evaluation proposal commitments, and context-specific comparisons of physical edits. We use these works for positioning; the present implementation is an assistant-mediated research workflow, not an implementation or benchmark of those frameworks.

\section{Mechanical cloaking problem}
\subsection{Candidate space and assembly}
The domain contains $30\times30$ macro cells, each represented by an original $50\times50$ binary pixel geometry. The supplied indicator identifies 112 cavity cells, 336 selectable cloak cells, and 452 fixed surrounding cells. Left--right mirror symmetry leaves 168 independent selectable cells, embedded in a $26\times13$ half-domain label array. Each active cell has 15 local candidate geometries. Passive slots are excluded from the action space, giving $15^{168}$ possible assignments and 2,352 nonincumbent single-cell replacements at any incumbent.

Let $\ell_i\in\{0,\ldots,14\}$ denote the label of independent cell $i$ and $G_{i\ell_i}$ its geometry. The assembler produces a binary field $\rho(\boldsymbol\ell)$ by placing each selected geometry and its mirror into the full domain. The source library contains 90,245 geometries with four independent orthotropic stiffness components and volume fraction~\cite{dataset}. Local candidate retrieval and the cloak region are held fixed throughout the comparison.

An action is a list of at most four distinct independent-cell replacements. Each replacement automatically updates its reflected physical cell. Cell identifiers are zero-based row-major indices of the $26\times13$ half-domain array; labels are zero based. The Python adapter preserves the original assembler's geometry reversal, mirror operation, and MATLAB label permutation. Inactive zeros in the candidate-index array are not dereferenced. This mapping matters: naively flattening the supplied label array in the wrong order would change the assembled design.

\subsection{Equilibrium, loading, and the supplied scaling}
Every pixel is a four-node plane-stress quadrilateral, with two displacement components per node and Poisson's ratio $\nu=0.35$. The full model has 2,250,000 elements and 4,506,002 displacement coordinates. With constrained coordinates eliminated, equilibrium is
\begin{equation}
\mathbf K_{ff}(\rho)\mathbf u_f=\mathbf f_f-\mathbf K_{fc}\mathbf u_c.
\label{eq:equilibrium}
\end{equation}
The supplied load case applies opposed compressive horizontal edge forces: the left edge carries positive horizontal load and the right edge negative load. The total magnitude parameter is $F_A=50(50\cdot50)^2=3.125\times10^8$, distributed over 1,500 edge intervals with half weights at endpoints. Horizontal displacement is fixed along the vertical centerline. Vertical displacement is fixed at the left-edge midpoint, center, and right-edge midpoint. These are the supplied load-case conventions, not newly optimized supports.

The legacy implementation forms an element matrix with prefactor $E_0h$ and multiplies it again by $E_{\min}+\rho_e(E_0-E_{\min})$:
\begin{equation}
\mathbf K_e=E_0h\,[E_{\min}+\rho_e(E_0-E_{\min})],\widehat{\mathbf K}_e(\nu),
\quad E_0=7\times10^6,\quad E_{\min}=10^{-9},\quad h=0.01.
\label{eq:legacy}
\end{equation}
We preserve this double occurrence of $E_0$ to reproduce the supplied reference convention, rather than silently replacing it with a different material scaling. Dividing both stiffness and load by $E_0^2h$ leaves the algebraic solution unchanged and yields the normalized void ratio $E_{\min}/E_0=1.42857\times10^{-16}$. The model is therefore a highly contrasted linear ersatz-material system. The reproduction does not independently establish a physical interpretation of the legacy units.

Exact mirror symmetry permits a $750\times1500$-element half-domain solve with 2,254,502 displacement coordinates. Reflection changes the sign of horizontal displacement and preserves vertical displacement, counting the centerline once. This is a symmetry reduction of the original discretization, not spatial coarsening. Direct sparse block assembly, symmetric diagonal equilibration, smoothed-aggregation algebraic multigrid, conjugate gradients, and iterative refinement make the solve feasible in the recorded environment.

\subsection{Masked displacement objective}
The goal is to reproduce the supplied reference response in the fixed exterior solid region. Let $\mathbf P$ select the monitored displacement coordinates and let $\mathbf u^*$ be the reference displacement. We minimize
\begin{equation}
\eps(\boldsymbol\ell)=
\frac{\|\mathbf P[\mathbf u(\rho(\boldsymbol\ell))-\mathbf u^*]\|_2}
{\|\mathbf P\mathbf u^*\|_2},\qquad J=\eps^2.
\label{eq:loss}
\end{equation}
The supplied pixel interest mask is extended to nodes by duplicating its final row and column. It selects both components at 371,241 nodes, or 742,482 displacement coordinates. We preserve this exact mask rather than sampling every node outside the cloak. The supplied target contains large nearly-void displacements away from the mask; substituting an unmasked norm would define a different and misleading objective. The monitored target norm is 1.28275944.

The original supplied assignment evaluates to $\eps_0=0.12761048866882535$. No expected scalar loss was supplied with the assignment. This is the value computed by the validated Python port, not a claim of matching a previously reported MATLAB scalar objective.

\begin{table}[htbp]
\centering\small
\caption{Primary cloaking case and fixed comparison conditions.}
\label{tab:setup}
\begin{tabular}{@{}p{.48\linewidth}p{.44\linewidth}@{}}\toprule
Quantity & Value\\\midrule
Macro domain / cell pixels & $30\times30$ / $50\times50$\\
Independent active cells / local labels & 168 / 15\\
Full elements / displacement coordinates & 2,250,000 / 4,506,002\\
Half-domain displacement coordinates & 2,254,502\\
Monitored displacement coordinates & 742,482\\
Shared historical trials & 18, identical in both arms\\
New rounds / proposals per round & 10 / 3 per arm\\
New distinct FEM assessments & 30 per arm; 60 total\\
Maximum changes per proposal & Four independent cells, mirrored automatically\\
Acceptance prerequisite & Finite loss; force residual below $10^{-7}$\\
Retention & Strictly lower measured masked loss\\\bottomrule
\end{tabular}
\end{table}

\section{Shared physical evidence and numerical proposer}
\subsection{Homogenized scalar-adjoint guidance}
Both methods receive feedback from a $30\times30$ orthotropic Q4 macro model built from candidate property tensors. Fixed surrounding cells use periodic homogenization of the base cell. Reference displacements and the interest mask are sampled consistently on the macro nodes. This approximate model supplies proposal evidence; all reported cloak losses use the original pixel-resolved model.

For macro objective $\widehat J$, macro equilibrium $\widehat{\mathbf K}\widehat{\mathbf u}=\widehat{\mathbf f}$, and the corresponding constrained scalar adjoint $\widehat{\boldsymbol\lambda}$,
\begin{equation}
\widehat{\mathbf K}_{ff}^{\mathsf T}\widehat{\boldsymbol\lambda}_f
=\left(\frac{\partial\widehat J}{\partial\widehat{\mathbf u}}\right)_f,
\qquad
s_{i\ell}=\frac{J}{\widehat J}\left[-\widehat{\boldsymbol\lambda}^{\mathsf T}
\Delta\widehat{\mathbf K}_{i\ell}\widehat{\mathbf u}\right].
\label{eq:score}
\end{equation}
Here $\Delta\widehat{\mathbf K}_{i\ell}$ includes both mirrored macro cells. The factor $J/\widehat J$ aligns objective scales; it does not make a finite replacement prediction exact. A summed batch score neglects cross-swap response interactions. At the supplied assignment, macro relative error is approximately 41.15\%, compared with fine masked loss 12.76\%. This mismatch is a reason to validate every candidate, not evidence that a persuasive agent explanation should override the evaluator.

A full-resolution scalar-adjoint attempt was stopped during preliminary development because convergence was slow. Its sensitivities are not used in either cloaking comparison. The successful small-model adjoint checks below do not establish a converged fine-model adjoint. In particular, the assembled-geometry response-vector interface used in the earlier beam study is not claimed for this cloak.

\subsection{Geometry and candidate features}
Every replacement is described by its cell and label, scaled macro score $s_{i\ell}$, supplied property-mismatch feature, volume fraction, changed-pixel fraction, and exact single-swap change in whole-assembly interface cost. For binary facing edges $a,b$, the geometric mismatch is
\begin{equation}
g(a,b)=\frac{\sum_p|a_p-b_p|}{\max(1,\sum_p(a_p\lor b_p))},
\qquad
\overline g=\frac1{1740}\sum_{(i,j)\in\mathcal E}g_{ij}.
\label{eq:interfaces}
\end{equation}
The 1,740 edges are the horizontal and vertical neighboring macro-cell pairs in the full $30\times30$ domain. For adjacent simultaneous replacements, joint interface cost must be recomputed on their shared edges rather than inferred by summing single-swap changes. The specialists recorded exact sums only when affected edge neighborhoods were disjoint; the evaluated assembly always supplies the final joint metric.

Connectivity is measured by four-neighbor adjacency of solid pixels. Volume fraction is the solid-pixel fraction. In the cloak comparison these metrics are reported, not imposed as new hard constraints. This differs from the explicit eligibility bounds used in the supporting beam study.

\subsection{Frozen adaptive numerical portfolio}
The numerical-only arm uses three deterministic proposal policies: a singleton for finite-step calibration, a bounded small-combination beam search, and a diverse beam search. It adjusts a signed response-calibration factor from measured versus predicted gains in the recent ledger. Retaining the sign matters because the macro surrogate can misrank finite changes. The factor is the median of the latest six finite gain ratios, clipped to $[-2,2]$, with an absolute floor of 0.02.

Recent unsuccessful batches shrink the changed-pixel limits, aggregate pixel budget, and number of swaps; successful outcomes can expand them. Base per-cell and aggregate pixel limits are 0.20 and 0.40, with a hard action cap of four. The trust-search predicted-gain cap adapts within $[0.025J,0.40J]$. A width-64 beam searches a pool of at most 96 candidates, formed from high-utility and low-pixel alternatives. Saturated calibrated gain is penalized by pixel change, adverse geometry change, and supplied property mismatch. The diverse policy additionally discounts concentration in a single large predicted gain. Exact formulas and constants are preserved in the frozen selector source and its hash manifest.

The calibration and proposal sizes adapt to observed outcomes; the numerical policy code itself remains fixed for the new 30-evaluation experiment. We therefore call it adaptive numerical search, while distinguishing parameter adaptation from the hybrid specialists' ability to change their reasoning strategy. This is a specific local optimizer, not a comprehensive numerical-optimization benchmark.

\section{Coordinated hybrid algorithm}
\subsection{Responsibilities and communication}
The hybrid fills three evaluation slots each round. Its first slot is the singleton nominee from the same numerical optimizer used by the comparator. The response LLM specialist fills a second slot by composing measured helpful changes, proposing subsets after failures, or testing small repairs under uncertainty. The interface LLM specialist fills the third slot by examining geometric compatibility and spatially coherent groups. These two specialist roles communicate directly to avoid redundant proposals and, where useful, construct matched comparisons.

The coordinator is a workflow responsibility combining language-mediated discussion and deterministic code checks, rather than an independently benchmarked third specialist. It shares the hybrid's current assignment, scores, and measured ledger; checks active-cell eligibility, valid labels, distinct changed cells, and assignment novelty; and combines the three nominations. The full assignment after applying actions is the unit of novelty. Different action strings that produce the same design are not treated as new proposals.

Only the hybrid's own new measurements enter its subsequent feedback. It does not inspect the new numerical arm's outcomes. The numerical arm likewise does not receive the hybrid's new outcomes. The identical historical ledger is shared once at initialization. Specialists are computational roles instantiated in an assistant-mediated session, not independent statistical replicates or separately trained models.

\subsection{Commit, evaluate, retain}
At round $t$, let $\boldsymbol\ell_t$ be the incumbent, $\mathcal H_t$ the available ledger, and $\mathcal A_t=\{a_t^{\rm num},a_t^{\rm resp},a_t^{\rm int}\}$ the three action lists. The coordinator requires
\begin{equation}
1\leq |a_t^k|\leq4,\quad
i\neq j\text{ for distinct edits in }a_t^k,\quad
\rho(\boldsymbol\ell_t\oplus a_t^k)\text{ is a fresh assignment}.
\label{eq:actions}
\end{equation}
The three proposals are saved and SHA-256 hashed before any outcome from that arm and round is evaluated. Valid proposals are then assessed by fine FEM. Define eligibility as finite $\eps$ and free-force residual below $10^{-7}$. The retention rule is
\begin{equation}
\boldsymbol\ell_{t+1}\in\underset{\boldsymbol\ell\in
\{\boldsymbol\ell_t\}\cup\{\boldsymbol\ell_t\oplus a_t^k:\ k\text{ eligible}\}}
{\operatorname{argmin}}\ \eps(\boldsymbol\ell),
\label{eq:retain}
\end{equation}
with the incumbent unchanged unless the measured loss is strictly lower. All outcomes, including failed proposals, are appended to $\mathcal H_t$. Eligibility is numerical and label-space validity; it is not a manufacturing certificate.

\begin{table}[htbp]
\centering\small
\caption{Executed hybrid loop. All three nominees use the same round-starting incumbent.}
\label{tab:algorithm}
\begin{tabular}{@{}cp{.87\linewidth}@{}}\toprule
Step & Operation\\\midrule
1 & Load incumbent, identical-form macro feedback, and own-arm measured history.\\
2 & Obtain one numerical nominee and one nominee from each LLM specialist.\\
3 & Discuss complementary hypotheses; resolve duplicates before evaluation.\\
4 & Validate actions and full-assignment novelty; save and hash all three proposals.\\
5 & Solve each candidate at the original fine resolution; record loss and diagnostics.\\
6 & Retain the best eligible strict improvement; append every trial to the shared log.\\
7 & Repeat until ten rounds and 30 new fine evaluations are complete.\\\bottomrule
\end{tabular}
\end{table}

\section{Experimental design}
\subsection{Preliminary studies and the common historical ledger}
The project began with a beam pilot, followed by a more demanding author-supplied cloak. A preliminary cloak comparison used three rounds of three proposals per arm. It reduced loss from 12.7610\% to 12.3594\% for adaptive numerical search and to 12.5406\% for a three-specialist swarm. Numerical policy refinements occurred during that exploratory session, and all outcomes were retained. This preliminary result favored the numerical search; it is not omitted from the present account.

The primary coordinated follow-up restarts both methods from the original supplied assignment, rather than from either preliminary winner. Both methods receive the same 18 historical trials, including actions, incumbent contexts, predicted changes, measured losses, and failures. This treatment acknowledges that the specialists already know the earlier study; restarting an array cannot erase conversational knowledge. Previously assessed full assignments are excluded from new proposals. The follow-up is therefore a warm-history exploratory comparison, not a blinded or held-out test.

\subsection{Matched budgets and independent trajectories}
The numerical-only arm submits all three numerical portfolio nominees each round. The hybrid submits one numerical nominee and two coordinated specialist nominees. Each arm completes ten rounds with three distinct fresh candidates per round: 30 new full-resolution candidate evaluations each. Both start with $\eps_0$, but thereafter retain separate incumbents and use their own new histories. Unlike the earlier beam proposal competition, one arm's accepted design is never handed to the other arm.

All 60 new proposal records report uncached evaluations. A design shared across arms is independently solved rather than counted as a free measurement. The common baseline, historical trials, reference reconstruction, and final diagnostic checks are outside the new candidate budgets. No unreported candidate-FEM lookahead is used to select the new proposals.

Equal fine-evaluation counts control an expensive resource, not total optimization effort. Agent latency, token use, and proposal-search computation were not matched. Nor does the design isolate agent coordination from every other policy difference: the hybrid specialists can revise strategy while the numerical policy code is frozen. We report a system-level comparison of these implemented methods.

\section{Results}
\subsection{Primary matched-budget comparison}
Table~\ref{tab:primary} reports the final primary outcomes. The hybrid reduces masked loss by 16.19\% relative to the supplied assignment; numerical search reduces it by 8.86\%. The hybrid's final loss is 8.05\% lower than the numerical comparator's final loss, an absolute difference of 0.9362 percentage points. These percentages refer to the norm error $\eps$, not its square $J$.

\begin{table}[htbp]
\centering
\caption{Primary cloak outcomes after 30 new fine evaluations per method. Both use the same starting assignment and 18-trial historical ledger.}
\label{tab:primary}
\begin{tabular}{@{}lrrr@{}}\toprule
Method & New FEM tests & Loss (\%) & Relative reduction\\\midrule
Supplied assignment & --- & 12.761049 & ---\\
Adaptive numerical & 30 & 11.630822 & 8.857\%\\
Coordinated hybrid & 30 & \textbf{10.694605} & \textbf{16.193\%}\\\bottomrule
\end{tabular}
\end{table}

The retained trajectories in Fig.~\ref{fig:convergence} show different search behavior. Numerical search makes a larger improvement in round four, then continues with smaller gains. The hybrid improves its retained loss in every round. This monotonicity is guaranteed by retention for either method; the fact that every hybrid round supplies a useful candidate is an observed result, not a general property of language agents. Across all proposals, 21 of 30 numerical candidates and 20 of 30 hybrid candidates improve their own round-starting design. The hybrid advantage therefore does not reduce to a higher fraction of improving trials; the size and composition of useful changes matter.
'''
fig2=[r'\begin{figure}[htbp]',r'\centering',r'\begin{tikzpicture}',r'\begin{axis}[width=.94\linewidth,height=6.4cm,xlabel={New fine FEM evaluations per method},ylabel={Masked displacement loss (\%)},xmin=0,xmax=30,ymin=10.5,ymax=12.95,xtick={0,6,12,18,24,30},grid=major,grid style={black!10},legend style={at={(.98,.98)},anchor=north east,font=\small},tick label style={font=\small}]']
for a,col,label in [('numerical','numblue','Adaptive numerical'),('hybrid','agentpurple','Coordinated hybrid')]:
 coords=[(0,12.761048866882535)]+[(3*x['round'],100*x['retained_loss']) for x in states[a]['rounds']]
 fig2 += [r'\addplot[%s,thick,mark=*] coordinates {%s};'%(col,' '.join(f'({x},{y:.9f})' for x,y in coords)),r'\addlegendentry{%s}'%label]
fig2 += [r'\end{axis}\end{tikzpicture}',r'\caption{Measured retained loss for the primary independent trajectories. Points mark completed three-proposal rounds. Both arms restart from the original assignment with identical historical evidence. No error bars are shown because these are single trajectories, not repeated-run estimates.}',r'\label{fig:convergence}',r'\end{figure}']
results=r'''
\subsection{Spatial changes and secondary metrics}
The numerical and hybrid final assignments differ from the original at 18 and 27 independent cells, respectively. Both retain one four-neighbor connected solid component. Their volume fractions are 0.412736 and 0.412640, compared with 0.41096178 for the supplied assignment. Their mean geometric mismatch costs are 0.121292 and 0.118689. Figure~\ref{fig:locations} maps the changed macro cells. Figure~\ref{fig:evolution} shows actual retained pixel-resolved structures with a common magnified patch; Figs.~\ref{fig:stressfields} and~\ref{fig:stressprofiles} show stresses recovered from saved fine solutions.

The larger accumulated number of hybrid changes is compatible with the four-swap limit: the cap applies to each proposal, while successive retained proposals can alter different cells. These results do not establish equal-material optimality, since volume was not fixed as an exact constraint. Connectedness and lower interface mismatch are useful secondary observations, not proofs of strength, buckling resistance, or printability.
'''
# Exact macro-cell geometry classes and changed locations, not synthetic pixel fields.
sys.path.insert(0,str(C));from cloak_adapter import CloakProblem
p=CloakProblem('/Users/amirbaratifarimani/Downloads/Agent_Meta');baseline=np.load(C/'baseline_labels.npy')
maps=[r'\begin{figure}[htbp]',r'\centering\resizebox{.99\linewidth}{!}{%',r'\begin{tikzpicture}[x=.15cm,y=.15cm]']
for idx,(name,lab) in enumerate([('Supplied',baseline),('Numerical',np.array(states['numerical']['labels'])),('Hybrid',np.array(states['hybrid']['labels']))]):
 offset=idx*35;changed=set()
 for i in np.flatnonzero((lab!=baseline).ravel()):
  y,x=divmod(int(i),13);changed.update([(27-y,x+2),(27-y,27-x)])
 for yy in range(30):
  for xx in range(30):
   kind=p.indicator[29-yy,xx]
   fill='white' if kind==0 else ('warmamber!65' if (yy,xx) in changed else ('numblue!28' if kind==1 else 'black!8'))
   maps.append(r'\filldraw[fill=%s,draw=white,line width=.14pt] (%d,%d) rectangle (%d,%d);'%(fill,offset+xx,29-yy,offset+xx+1,30-yy))
 maps.append(r'\draw[black!35] (%d,0) rectangle (%d,30);'%(offset,offset+30))
 maps.append(r'\node[font=\sffamily\small] at (%g,32) {%s};'%(offset+15,name))
 maps.append(r'\node[font=\sffamily\scriptsize] at (%g,-2) {%d independent changes};'%(offset+15,int(np.sum(lab!=baseline))))
maps += [r'\end{tikzpicture}}',r'\caption{Exact macro-cell locations changed relative to the supplied assignment, shown schematically rather than as pixel microstructures. Gray denotes the fixed surrounding region, blue unchanged cloak cells, white the cavity, and amber changed cloak cells. Mirrored changes are shown in both halves. The label array has 168 independent active cells; accumulated changes need not be four or fewer.}',r'\label{fig:locations}',r'\end{figure}']
mechanisms=r'''
\subsection{What coordination contributed in the observed run}
The response specialist supplies the retained proposal in seven rounds and the interface specialist in three. The numerical-tool slot supplies four candidates that improve their round-starting incumbent, but none is the best of its hybrid round. This is descriptive attribution of accepted proposals, not a causal decomposition of the final gain: all roles use numerical feedback and shared earlier measurements.

Three episodes illustrate the coordination mechanism. First, the response agent combines a useful response block with a previously helpful numerical block, reaching 12.1506\% in round two. This transfers measured structure across contexts without assuming that component gains add exactly. Second, an interface pair at independent cells 119 and 210 improves round five; extending the same material geometry to cells 106 and 223 improves round six. A further outward extension to 93 and 236 fails in round seven. The finite extent of the useful band is therefore learned from measurements rather than inferred from visual regularity alone.

Third, matched proposals turn later evaluations into interpretable contrasts. In round nine, both specialists set cells 132 and 197 to label 5; the response proposal additionally restores cell 311 to label 0. Loss is 10.8152\% without that restoration and 10.7800\% with it. Thus restoring cell 311 helps by 0.03519 percentage points \emph{in that shared context}. In round ten, both proposals change cells 107, 50, and 297 identically; the interface proposal additionally sets cell 224 to label 13. That extra change lowers loss from 10.7143\% to 10.6946\%, a 0.01966-point improvement. Neither contrast establishes a context-independent effect of the individual cell.

These comparisons are more informative than three arbitrary independent guesses, but they consume the same expensive evaluation slots. The selected protocol favors a mixture of strong repairs and interpretable comparisons. No separate experiment tests whether that particular allocation is optimal.

\subsection{Complete retained history}
Table~\ref{tab:trajectory} lists the complete retained history and the source of each accepted hybrid proposal.
\begin{table}[htbp]
\centering\small
\caption{Primary retained trajectories. Each round consumes three new candidates per method. R and I denote response and interface specialist winners in the hybrid arm.}
\label{tab:trajectory}
\begin{tabular}{@{}rrrrc@{}}\toprule
Round & Tests per arm & Numerical loss (\%) & Hybrid loss (\%) & Winner\\\midrule
'''
trajectory=[]
for n,(nr,hr) in enumerate(zip(states['numerical']['rounds'],states['hybrid']['rounds']),1):
 winner=min(hr['proposals'],key=lambda h:h['loss'])['name'];trajectory.append(f"{n} & {3*n} & {nr['retained_loss']*100:.6f} & {hr['retained_loss']*100:.6f} & {'R' if winner=='agent_response' else 'I'}\\\\")
after=r'''
\bottomrule\end{tabular}
\end{table}

\subsection{Numerical verification}
The monitored reference displacement reconstructed from the supplied uniform base-cell structure agrees with the supplied target to relative difference $1.2912\times10^{-10}$. Small independently assembled models verify the full/half symmetry relation and stiffness assembly. The macro-adjoint derivative check validates the implemented infinitesimal macro derivative, not the accuracy of finite candidate scores. Table~\ref{tab:verification} collects checks at their actual scope.

\begin{table}[htbp]
\centering\small
\caption{Verification evidence. Numerical agreement does not establish physical model validity.}
\label{tab:verification}
\begin{tabular}{@{}p{.65\linewidth}r@{}}\toprule
Check & Recorded discrepancy\\\midrule
Supplied monitored reference, relative difference & $1.29\times10^{-10}$\\
Small-model half/full displacement, relative difference & $1.10\times10^{-15}$\\
Independent triplet stiffness, maximum entry difference & $4.44\times10^{-16}$\\
Small scalar-adjoint finite difference, relative difference & $2.38\times10^{-10}$\\
Macro-adjoint finite difference, relative difference & $2.37\times10^{-7}$\\
Largest free-force residual among 60 candidates & $1.66\times10^{-11}$\\
Final independent free-force residual, numerical / hybrid & $2.33/2.31\times10^{-11}$\\
Final net-force imbalance, numerical / hybrid & $1.95/1.94\times10^{-10}$\\\bottomrule
\end{tabular}
\end{table}

The audit checks 30 distinct new assignments per arm, no cached new proposal evaluations, valid label changes, strict retention, all 20 proposal commitment hashes, identical prior ledgers, and unchanged scientific solver, feedback, and numerical-selector source hashes. Final support reactions and element internal forces are recomputed independently of the forward residual report. No candidate is rejected for force residual; mechanically unsuccessful candidates are rejected because their loss is higher.

Recorded candidate solve-and-refinement times range from 39.05 to 55.67 seconds. Summed times are 1,431.27 seconds for numerical and 1,472.46 seconds for hybrid candidate solves. These exclude AMG setup, feedback formation, agent interaction, and proposal-search overhead; they are not end-to-end optimization times and do not support a speedup claim.

\section{Discussion}
\subsection{A useful role for language agents}
The observed benefit is the construction and revision of experiments in a discrete physical action space. Agents can connect a failed composition to a smaller test, compare a transferred block with its contextual alternatives, and ask whether extending a compatible band remains beneficial. Their output is a concrete action list that can be checked and evaluated. Mechanical predictions still come from numerical models, and acceptance still comes from fine equilibrium.

The hybrid is consequently a tool-using search system, not language-only mechanics. The numerical proposer is integral to its evidence interface and supplies useful comparisons even when a specialist provides the retained design. Conversely, the lower final hybrid loss is not explained by a language model having solved equilibrium implicitly. The initial failed beam repair and failed cloak proposals show why measured retention remains necessary.

\subsection{What the comparison establishes}
The matched new-FEM budget and common historical ledger support a concrete finding: this coordinated hybrid produces a lower final loss than this frozen adaptive numerical portfolio on the supplied case. Both methods improve substantially, and the hybrid's final geometry remains connected at a similar reported material fraction. The result warrants further evaluation of the coordination strategy.

It does not isolate coordination as a single causal factor. There is no new 30-evaluation uncoordinated swarm control, no repeated-team distribution, and no optimizer portfolio exhaustive enough to represent numerical search generally. The preliminary nine-evaluation swarm is not such a control: it uses a smaller budget and different history. The comparison is also not an LLM-versus-GNN test. A larger agent count is not evaluated in this paper.

\subsection{Feedback fidelity and adaptive hypotheses}
Macro gradients are cheap but can misrank finite topology changes. Signed empirical calibration partly addresses this in the numerical policy. The specialists additionally use spatial and contextual reasoning, including proposals with adverse macro scores when earlier measurements justify exploration. Their failures remain essential evidence: a good interface pattern cannot be extended indefinitely, and a helpful cell in one assembly need not help another.

Strong numerical alternatives could use empirical interaction models, contextual bandits, trust-region optimization with richer local surrogates, or systematic subset tests. Those are appropriate next comparators. The present record makes such comparisons possible without attributing all useful adaptation uniquely to language models.

\section{Limitations and future work}
The primary study uses one supplied cavity, one set of 15 candidates at each active cell, one loading case, and one assistant-mediated run. The exact language-model snapshot and decoding settings were not recorded sufficiently for regeneration of the specialist decisions. Literal actions and FEM outcomes are reproducible more directly than the decision process. Prior conversational familiarity further prevents treating this as a held-out test, despite the shared historical ledger.

The original legacy stiffness scaling and nearly void phase are preserved. Agreement with the supplied reference and small force residuals verify reproduction of the numerical problem, not its conditioning under every perturbation or its physical calibration. A cloak void-stiffness sensitivity study, mesh convergence study, nonlinear analysis, multiple-load tests, and fabrication experiments have not been performed. The earlier beam regularization check cannot be transferred as evidence for cloak robustness.

Future work should use multiple cavities and compatible regenerated targets, fixed model and decoding records, repeated runs, explicit wall-clock and token costs, and manufacturing constraints such as minimum ligament width. A matched uncoordinated hybrid control and a stronger numerical search with the same ablation capabilities would help determine which coordination elements add value. A trained GNN comparator requires a separate controlled training and evaluation protocol.

\section{Conclusion}
Coordinated language agents can participate in discrete metamaterial assembly when paired with numerical proposal tools and fine mechanical validation. In the supplied mechanical-cloaking case, the hybrid lowers masked displacement loss from 12.7610\% to 10.6946\%, while an adaptive numerical portfolio reaches 11.6308\% under the same 30-new-evaluation budget and shared historical evidence. Measured compositions, interface extensions, and matched ablations provide concrete examples of how the roles work together. The result is evidence for this implemented hybrid on this case, with generalization and the causal contribution of coordination remaining open.

\section*{Data and code availability}
The public unit-cell library is available under CC BY 4.0 at the Figshare DOI in Ref.~\cite{dataset}. The repository \href{https://github.com/BaratiLab/Metamaterial-Swarm}{BaratiLab/Metamaterial-Swarm} contains the project source, recorded actions, outcomes, validation, figure sources, and manuscript. It is private at preparation; this is an access-controlled working record rather than an independently archived public release. The author-supplied cloak input package is required separately and is not redistributed. Public release permissions and a permanent archived identifier remain to be resolved before journal submission.

\section*{AI assistance and author declarations}
Language agents generated experimental proposals and assisted with code and manuscript preparation. Their nominations are evaluated research objects, not independent human reviews. The human authors must review the code, numerical interpretation, and final scientific claims. The author order and corresponding-author designation are specified above. Detailed contribution, funding, and competing-interest statements must be completed and approved by the listed authors before submission.

\appendix
\section{Supporting beam study}
The earlier beam pilot uses the same public library but a different task, feedback interface, and protocol. A $30\times4$ macro-cell beam has ten candidates per cell and a fine model with 300,000 Q4 elements. It targets the achieved displacement profile of a continuous macro design, sampled on both outer edges. It is paper-inspired rather than an exact reproduction of Ref.~\cite{wang2020}: the library size, constituent Poisson's ratio, loading conventions, and assembly solver differ.

Independent property matching and multistart graph ICM yield errors of 20.73\% and 9.93\%. An initial top-eight numerical repair reaches 4.86\%, while a single assistant-guided batch using homogenized feedback worsens the graph result to 10.82\%. A subsequent three-specialist proposal competition uses assembled-geometry response sensitivities and reduces the numerical incumbent from 4.862985\% to 3.921978\% after three rounds. The numerical and agent groups receive nine candidate assessments each, but share the retained incumbent. Fixed numerical policies repeat their final three candidates, covering only six unique incumbent/action pairs. This is supporting evidence of feasibility, not an independent matched adaptive-optimizer test.

Unlike the cloak, the beam follow-up imposes connectedness, mean geometric mismatch at most 0.20, mean mechanical mismatch at most 0.35, and volume fraction within 0.015 of the starting value. These conditions are not silently applied to the cloak results. The beam archive retains its complete failed and successful proposals, derivative checks, and a limited ersatz-stiffness sensitivity check.

\section{Preliminary cloak study and provenance}
Before the primary follow-up, separate nine-proposal cloak trajectories reach 12.359447\% for numerical search and 12.540622\% for the swarm, starting from 12.761049\%. Numerical policy development includes signed calibration and trust-update refinements; the prior source and literal actions are preserved. All 18 assessments become the common historical ledger for the primary study. The final numerical selector is frozen before new primary outcomes, and its SHA-256 digest is recorded with the protocol. Preliminary trials are not counted as 18 additional new measurements for either primary arm.

\section{Reproduction and implementation details}
The recorded environment uses Python 3.11, NumPy 1.24.3, SciPy 1.11.1, Numba 0.57.1, and PyAMG 5.0.1. BLAS and OpenMP threads are set to one. The original MATLAB sources and data are unchanged. The full model has not been executed in MATLAB or Octave in this environment. The reported reproduction is the validated Python port.

Source data include both ordinary MAT and MATLAB v7.3/HDF5 files. The adapter restores array ordering, excludes inactive candidate zeros, and reproduces the label-index permutation. Agent actions use zero-based independent-cell and label indices; stored library indices are converted from their MATLAB convention. Retained assignments are exported as MATLAB-compatible \texttt{Label} arrays.

All three proposals in an arm-round are saved before any of its candidate outcomes. Commitment hashes and geometry hashes are retained. Round-one scratch launches initially share a namespace but independently execute their common singleton; later hybrid rounds use an arm-specific namespace. Every one of the 60 new trial records reports an uncached solve. This implementation detail does not change the optimization policy or reported evaluation count.

The literal-action replay script recomputes the saved proposals in a new directory without requesting new language-agent decisions. A complete 60-assessment replay was not redundantly rerun after the completed study. The standalone \texttt{main.tex} embeds the vector overview, result plots, and losslessly compressed RGB structure/stress figures through the PGF PDF backend. No external graphics or bibliography database is required. The original PNG/PDF assets and numerical profile CSV are also supplied for reuse.

\section{All primary candidate outcomes}
Table~\ref{tab:alltrials} preserves all 60 measured candidate losses, including failures. N1, N2, and N3 are the numerical singleton, trust-combination, and diverse-beam policies. In the hybrid, T denotes its numerical-tool singleton, R the response agent, and I the interface agent. All candidates are numerically eligible; lower loss determines retention. Rows are correlated adaptive trials, not independent replicates. Literal actions, predicted scores, force residuals, connectivity, volume, and interface metrics are provided in the computational archive.
\small
\begin{longtable}{@{}rrlrrl@{}}
\caption{Complete primary trial outcomes, grouped by round. Losses are percentages.}\label{tab:alltrials}\\
\toprule Round & Tests & Numerical policy & Loss (\%) & Hybrid loss (\%) & Hybrid role\\\midrule
\endfirsthead
\toprule Round & Tests & Numerical policy & Loss (\%) & Hybrid loss (\%) & Hybrid role\\\midrule
\endhead
\bottomrule\endfoot
'''
allrows=[]
for n in range(10):
 for k in range(3):
  nr=states['numerical']['rounds'][n]['proposals'][k];hr=states['hybrid']['rounds'][n]['proposals'][k]
  allrows.append(f"{n+1} & {3*n+k+1} & N{k+1} & {100*nr['loss']:.6f} & {100*hr['loss']:.6f} & {['T','R','I'][k]}\\\\")
bib=r'''
\end{longtable}
\normalsize
\begin{thebibliography}{9}
\bibitem{wang2020} L. Wang, Y.-C. Chan, F. Ahmed, Z. Liu, P. Zhu, and W. Chen.
Deep generative modeling for mechanistic-based learning and design of metamaterial systems.
\emph{Computer Methods in Applied Mechanics and Engineering}, 372:113377, 2020.
\href{https://doi.org/10.1016/j.cma.2020.113377}{doi:10.1016/j.cma.2020.113377}.
\bibitem{cloak2022} L. Wang, J. Boddapati, K. Liu, P. Zhu, C. Daraio, and W. Chen.
Mechanical cloak via data-driven aperiodic metamaterial design.
\emph{Proceedings of the National Academy of Sciences}, 119(13):e2122185119, 2022.
\href{https://doi.org/10.1073/pnas.2122185119}{doi:10.1073/pnas.2122185119}.
\bibitem{dataset} L. Wang, J. Boddapati, K. Liu, P. Zhu, C. Daraio, and W. Chen.
\emph{2D orthotropic metamaterial micorstructrue dataset}. Figshare, version 1, 2021. CC BY 4.0.
\href{https://doi.org/10.6084/m9.figshare.17141975.v1}{doi:10.6084/m9.figshare.17141975.v1}.
\bibitem{opro} C. Yang, X. Wang, Y. Lu, H. Liu, Q. V. Le, D. Zhou, and X. Chen.
Large language models as optimizers. \emph{International Conference on Learning Representations}, 2024.
\href{https://proceedings.iclr.cc/paper_files/paper/2024/hash/3339f19c5fcee3ad74502947a32be9e6-Abstract-Conference.html}{Conference proceedings}.
\bibitem{react} S. Yao, J. Zhao, D. Yu, N. Du, I. Shafran, K. Narasimhan, and Y. Cao.
ReAct: Synergizing reasoning and acting in language models.
\emph{International Conference on Learning Representations}, 2023.
\href{https://arxiv.org/abs/2210.03629}{arXiv:2210.03629}.
\bibitem{autogen} Q. Wu et al.
AutoGen: Enabling next-gen LLM applications via multi-agent conversation.
\emph{Conference on Language Modeling}, 2024.
\href{https://arxiv.org/abs/2308.08155}{arXiv:2308.08155}.
\end{thebibliography}
\end{document}
'''
embedded=r'\newcommand{\structureevolution}{\includegraphics[width=.99\linewidth]{cloak-structure-evolution.png}}'+'\n'+r'\newcommand{\stressfields}{\includegraphics[width=.99\linewidth]{cloak-stress-fields.png}}' 
preamble=preamble.replace(r'\begin{document}',embedded+'\n'+r'\begin{document}')
stress=(ROOT/'work/manuscript-revision/stress-paper-section.tex').read_text()
after=after.replace(r'\subsection{Numerical verification}',stress+'\n'+r'\subsection{Numerical verification}')
source='\n'.join([preamble,f1,body,'\n'.join(fig2),results,'\n'.join(maps),mechanisms,'\n'.join(trajectory),after,'\n'.join(allrows),bib])
from expand_references import revise
source=revise(source)
(OUT/'main.tex').write_text(source)
print('Rewrote existing main.tex:',len(source),'characters')
