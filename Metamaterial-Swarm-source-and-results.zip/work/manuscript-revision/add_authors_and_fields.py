"""Extend the existing manuscript builder with authors and real FEM figures."""
from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parents[2]
p=ROOT/'work/manuscript-revision/rewrite_paper.py'
s=p.read_text()
s=s.replace(r'\pgfplotsset{compat=1.18}',r'\pgfplotsset{compat=1.18}'+'\n'+r'\usepgfplotslibrary{groupplots}')
s=s.replace(r'\author{}',r'\author{Liwei Wang\textsuperscript{1} \and Amir Barati Farimani\textsuperscript{1,2,3,4,*}}')
s=s.replace(r'\date{}',r'''\date{\small
\textsuperscript{1}Department of Mechanical Engineering\\
\textsuperscript{2}Department of Chemical Engineering\\
\textsuperscript{3}Department of Materials Science and Engineering\\
\textsuperscript{4}Machine Learning Department\\
Carnegie Mellon University, 5000 Forbes Avenue, Pittsburgh, PA 15213, USA\\[4pt]
\textsuperscript{*}Corresponding author: \href{mailto:barati@cmu.edu}{barati@cmu.edu}}''')
s=s.replace('Author names, affiliations, contributions, funding, and competing-interest statements remain deferred in this working manuscript, as requested, and must be completed before submission.','The author order and corresponding-author designation are specified above. Detailed contribution, funding, and competing-interest statements must be completed and approved by the listed authors before submission.')
s=s.replace(r'''\section*{Acknowledgments}
We thank Liwei Wang for providing the mechanical-cloaking assignment, evaluator, and task summary used to define this benchmark. Sharing these materials does not imply review or endorsement of the new experimental claims.

''','')
s=s.replace('The standalone \\texttt{main.tex} embeds the vector overview and result plots directly; no external graphics or bibliography database is required to compile it with pdfLaTeX. Editable overview exports and full pixel-resolved raster figures are separate companion assets.','The standalone \\texttt{main.tex} embeds the vector overview, result plots, and losslessly compressed RGB structure/stress figures through the PGF PDF backend. No external graphics or bibliography database is required. The original PNG/PDF assets and numerical profile CSV are also supplied for reuse.')
s=s.replace('Figure~\\ref{fig:locations} maps the changed macro cells; the companion figures provide the full pixel-resolved assemblies and exterior displacement-error maps on a common scale.','Figure~\\ref{fig:locations} maps the changed macro cells. Figure~\\ref{fig:evolution} shows actual retained pixel-resolved structures with a common magnified patch; Figs.~\\ref{fig:stressfields} and~\\ref{fig:stressprofiles} show stresses recovered from saved fine solutions.')
s=s.replace('\\subsection{Complete retained history}\n\\begin{table}', '\\subsection{Complete retained history}\nTable~\\ref{tab:trajectory} lists the complete retained history and the source of each accepted hybrid proposal.\n\\begin{table}')
stress=r'''
\subsection{Recovered stress fields and profiles}
The optimized objective is exterior displacement error, not stress uniformity. To examine the mechanical fields without additional candidate solves, we recover plane-stress components from the saved fine displacement vectors using the same Q4 interpolation and element ordering. At each element center,
\begin{equation}
\widehat{\boldsymbol\sigma}_e=\left[\eta+(1-\eta)\rho_e\right]
\mathbf D(\nu)\mathbf B_e(0,0)\mathbf u_e,
\qquad
\widetilde{\boldsymbol\sigma}_e=\widehat{\boldsymbol\sigma}_e/\widehat\sigma_{\rm nom},
\quad \widehat\sigma_{\rm nom}=\frac{F_A}{1500E_0^2h}.
\label{eq:stressrecovery}
\end{equation}
Here $\mathbf D$ has normalized solid Young's modulus one, $\eta=E_{\min}/E_0$, and $\mathbf B_e$ uses unit pixel length. This dimensionless normalization cancels the legacy stiffness scaling and is unchanged by a uniform spatial rescaling. Compression is negative $\sigma_{xx}$; physical $x$ points right and physical $y$ up. Stored image rows increase downward. The von Mises quantity is evaluated from the recovered center components,
\begin{equation}
\widetilde\sigma_{\rm vm}=
\sqrt{\widetilde\sigma_{xx}^2-\widetilde\sigma_{xx}\widetilde\sigma_{yy}
+\widetilde\sigma_{yy}^2+3\widetilde\tau_{xy}^2}.
\end{equation}
For constant element material, center stress equals the average of the four Gauss-point stress vectors; its von Mises value is not the average of Gauss-point von Mises values. Quadrature of the recovery matrix reproduces the solver's normalized element stiffness to maximum difference $1.11\times10^{-16}$. An affine stress patch test has maximum discrepancy $1.46\times10^{-18}$, and center versus mean-Gauss stress agrees to $2.22\times10^{-16}$.

Figure~\ref{fig:stressfields} plots local solid-element stresses on the actual geometries, with void elements masked and common color scales. The shared upper scale is the pooled 99.5th percentile of deterministic sampled solid-element values; higher values are saturated for visibility. Unclipped sampled-field maxima are retained in the recovery record. These are element-center fields, not mesh-converged peak-stress estimates, and sharp pixel corners and constrained nodes can dominate local extrema.

For readable exterior profiles, each original $50\times50$-element macro cell is averaged over its full area, including the unchanged ersatz void phase. Figure~\ref{fig:stressprofiles} compares fixed exterior row 1 and column 1, which lie in the surrounding base-cell region. We additionally report a secondary stress mismatch over the 452 fixed exterior cells,
\begin{equation}
e_\sigma=\frac{\sqrt{\sum_{i\in\mathcal E_{\rm out}}
[(\Delta\overline\sigma_{xx,i})^2+(\Delta\overline\sigma_{yy,i})^2
+2(\Delta\overline\tau_{xy,i})^2]}}
{\sqrt{\sum_{i\in\mathcal E_{\rm out}}
[\overline\sigma_{xx,i}^{*2}+\overline\sigma_{yy,i}^{*2}
+2\overline\tau_{xy,i}^{*2}]}}.
\label{eq:stresserror}
\end{equation}
The reference is the uniformly tiled base-cell structure under the same load and supports. Values are 11.6298\% for the supplied assignment, 11.8811\% for the numerical final design, and 11.5985\% for the hybrid final design. Thus the substantial displacement-loss improvement does not translate into a similarly large stress-field improvement: the hybrid stress metric is nearly unchanged from the supplied design, and the numerical stress metric increases. This post hoc diagnostic was not used for proposal selection or retention. It neither establishes stress optimality nor changes the displacement-based ranking.

\begin{figure}[p]
\centering\structureevolution
\caption{Actual pixel-resolved evolution of retained hybrid assignments: supplied design and rounds 2, 5, and 10. The upper row shows the entire original $1500\times1500$-element assembly; amber boxes identify the same $5\times5$-cell patch magnified below. Purple frames indicate cells changed relative to the supplied assignment. The sequence is reconstructed from saved retained labels, not generated illustrations. Reported losses are measured fine FEM objectives.}
\label{fig:evolution}
\end{figure}

\begin{figure}[p]
\centering\stressfields
\caption{Recovered element-center von Mises stress (upper row) and horizontal normal stress (lower row), normalized by applied nominal compressive traction. Columns show the uniform base-cell reference, supplied cloak, numerical final cloak, and hybrid final cloak. Original pixel geometries and saved fine displacement fields are used; void pixels are masked. All columns use the same scales, clipped at the common pooled 99.5th-percentile limits for display. Compression is negative $\sigma_{xx}$. These fields are diagnostic: stresses were not optimized, and local maxima have no mesh-convergence claim.}
\label{fig:stressfields}
\end{figure}
'''
# PGFPlots profiles remain editable vectors and use exactly the exported CSV.
rows=list(csv.DictReader((ROOT/'outputs/paper-figures/stress-profiles.csv').open()))
profiles=[r'\begin{figure}[htbp]',r'\centering\begin{tikzpicture}',r'\begin{groupplot}[group style={group size=3 by 1,horizontal sep=1.25cm},width=.28\linewidth,height=5cm,grid=major,grid style={black!10},xmin=.5,xmax=29.5,xtick={5,15,25},tick label style={font=\scriptsize},label style={font=\scriptsize},title style={font=\small},legend style={font=\tiny,at={(.02,.03)},anchor=south west}]']
for k,(col,title,xlab,ylab) in enumerate([('top_compressive_sigma_xx','Top exterior row','Cell coordinate $x/a$',r'$-\langle\sigma_{xx}\rangle/\sigma_{\rm nom}$'),('left_compressive_sigma_xx','Left exterior column','Stored row coordinate',r'$-\langle\sigma_{xx}\rangle/\sigma_{\rm nom}$'),('top_sigma_yy','Top exterior row','Cell coordinate $x/a$',r'$\langle\sigma_{yy}\rangle/\sigma_{\rm nom}$')]):
 profiles.append(r'\nextgroupplot[title={%s},xlabel={%s},ylabel={%s}]'%(title,xlab,ylab))
 for name,color,label in [('reference','black!65','Reference'),('supplied','black!35','Supplied'),('numerical','numblue','Numerical'),('hybrid','agentpurple','Hybrid')]:
  rr=[x for x in rows if x['case']==name];coords=' '.join('(%s,%.10g)'%(x['macro_coordinate'],float(x[col])) for x in rr)
  profiles.append(r'\addplot[%s,%sthick] coordinates {%s};'%(color,'dashed,' if name=='reference' else '',coords))
  if k==0:profiles.append(r'\addlegendentry{%s}'%label)
profiles += [r'\end{groupplot}\end{tikzpicture}',r'\caption{Gross-area stress profiles averaged over original $50\times50$-element cells in the fixed exterior region. Top row index 1 and left column index 1 are used; displayed coordinates are cell centers and stored row increases downward. The profiles retain the original material/void interpolation and are not reoptimized curves. The numerical profile CSV and stress-recovery checks accompany the figures.}',r'\label{fig:stressprofiles}',r'\end{figure}']
stress+='\n'+'\n'.join(profiles)
q=ROOT/'work/manuscript-revision/stress-paper-section.tex';q.write_text(stress)
old="source='\\n'.join([preamble,f1,body,'\\n'.join(fig2),results,'\\n'.join(maps),mechanisms,'\\n'.join(trajectory),after,'\\n'.join(allrows),bib])"
new="""embedded=(ROOT/'outputs/paper-figures/embedded-raster-figures.tex').read_text()
preamble=preamble.replace(r'\\begin{document}',embedded+'\\n'+r'\\begin{document}')
stress=(ROOT/'work/manuscript-revision/stress-paper-section.tex').read_text()
after=after.replace(r'\\subsection{Numerical verification}',stress+'\\n'+r'\\subsection{Numerical verification}')
source='\\n'.join([preamble,f1,body,'\\n'.join(fig2),results,'\\n'.join(maps),mechanisms,'\\n'.join(trajectory),after,'\\n'.join(allrows),bib])"""
assert old in s;s=s.replace(old,new);p.write_text(s)
print('Updated manuscript builder, author block, stress methods/results, and real figures')
