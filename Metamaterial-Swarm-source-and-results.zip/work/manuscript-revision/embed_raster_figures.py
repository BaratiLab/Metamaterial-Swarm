"""Embed losslessly compressed raster figures through the PGF PDF backend.

The main document remains standalone for the built-in editor. The identical
PNG/PDF assets are also included in the Overleaf package for normal reuse.
"""
from pathlib import Path
import zlib,hashlib,json,base64
from PIL import Image
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'outputs/paper-figures'
figures=[('structureevolution','cloak-structure-evolution.png'),('stressfields','cloak-stress-fields.png')]
parts=[r'''% Losslessly embedded RGB figures. PDF/PGF inline images need no external files.
\makeatletter
\newdimen\PaperImageWidth
\newdimen\PaperImageHeight
\newdimen\PaperImageBPWidth
\newdimen\PaperImageBPHeight
\newcommand{\PaperInlineRGB}[4]{%
\begingroup
\PaperImageWidth=.99\linewidth
\PaperImageHeight=#3\PaperImageWidth
\PaperImageBPWidth=.99626401\PaperImageWidth
\PaperImageBPHeight=.99626401\PaperImageHeight
\edef\PaperW{\strip@pt\PaperImageBPWidth}%
\edef\PaperH{\strip@pt\PaperImageBPHeight}%
\begin{tikzpicture}
\path[use as bounding box] (0pt,0pt) rectangle (\PaperImageWidth,\PaperImageHeight);
\pgfsys@beginscope
\pgfsys@transformcm{\PaperW}{0}{0}{\PaperH}{0pt}{0pt}
\pgfsys@invoke{BI /W #1 /H #2 /BPC 8 /CS /RGB /F [/A85 /Fl] ID #4 \detokenize{~>} EI}%
\pgfsys@endscope
\end{tikzpicture}%
\endgroup}
\makeatother
'''];records=[]
for macro,name in figures:
 im=Image.open(OUT/name).convert('RGB');w,h=im.size;raw=im.tobytes();compressed=zlib.compress(raw,9);encoded=base64.a85encode(compressed).decode('ascii');wrapped='\n'.join(encoded[i:i+120] for i in range(0,len(encoded),120))
 assert zlib.decompress(base64.a85decode(encoded))==raw
 data='PaperRasterData'+macro
 parts.append(r'''\begingroup
\catcode`\%=12
\catcode`\#=12
\catcode`\$=12
\catcode`\&=12
\catcode`\^=12
\catcode`\_=12
\catcode`\~=0
\catcode`\\=12
'''+f'~gdef~{data}'+'{\n'+wrapped+'\n}\n~endgroup\n'+r'\newcommand{\%s}{\PaperInlineRGB{%d}{%d}{%.9f}{\%s}}'%(macro,w,h,h/w,data))
 records.append(dict(macro=macro,file=name,width=w,height=h,rgb_sha256=hashlib.sha256(raw).hexdigest(),compression='zlib + ASCII85Decode, lossless',compressed_bytes=len(compressed)))
(OUT/'embedded-raster-figures.tex').write_text('\n'.join(parts))
(OUT/'embedded-raster-manifest.json').write_text(json.dumps(records,indent=2))
print(records)
