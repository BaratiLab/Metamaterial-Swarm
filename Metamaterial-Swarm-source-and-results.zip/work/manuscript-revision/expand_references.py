"""Maintain the 40-source, claim-linked literature revision in the existing paper."""
from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parents[2]
RECORDS=[]
def add(key,authors,title,venue,year,url='',original=None,status='published'):
 RECORDS.append(dict(key=key,authors=authors,title=title,venue=venue,year=year,url=url,original_paper_reference=original,status=status))
add('wang2020','L. Wang, Y.-C. Chan, F. Ahmed, Z. Liu, P. Zhu, W. Chen','Deep generative modeling for mechanistic-based learning and design of metamaterial systems','Computer Methods in Applied Mechanics and Engineering 372, 113377',2020,'https://doi.org/10.1016/j.cma.2020.113377')
add('cloak2022','L. Wang, J. Boddapati, K. Liu, P. Zhu, C. Daraio, W. Chen','Mechanical cloak via data-driven aperiodic metamaterial design','Proceedings of the National Academy of Sciences 119(13), e2122185119',2022,'https://doi.org/10.1073/pnas.2122185119')
add('dataset','L. Wang, J. Boddapati, K. Liu, P. Zhu, C. Daraio, W. Chen','2D orthotropic metamaterial micorstructrue dataset','Figshare, version 1, CC BY 4.0',2021,'https://doi.org/10.6084/m9.figshare.17141975.v1',status='dataset')
add('yu','X. Yu, J. Zhou, H. Liang, Z. Jiang, L. Wu','Mechanical metamaterials associated with stiffness, rigidity and compressibility: A brief review','Progress in Materials Science 94, 114--173',2018,'https://www.sciencedirect.com/science/article/pii/S0079642517301445',2)
add('clausen','A. Clausen, F. Wang, J. S. Jensen, O. Sigmund, J. A. Lewis',"Topology optimized architectures with programmable Poisson's ratio over large deformations",'Advanced Materials 27, 5523--5527',2015,'https://orbit.dtu.dk/files/128079105/ProgrammablePoisson_postPrint.pdf',4)
add('zhu','B. Zhu, M. Skouras, D. Chen, W. Matusik','Two-scale topology optimization with microstructures','ACM Transactions on Graphics 36(4)',2017,'https://arxiv.org/abs/1706.03189',8)
add('xia2014','L. Xia, P. Breitkopf','Concurrent topology optimization design of material and structure within FE2 nonlinear multiscale analysis framework','Computer Methods in Applied Mechanics and Engineering 278, 524--542',2014,'https://www.sciencedirect.com/science/article/pii/S0045782514001832',12)
add('xia2015','L. Xia, P. Breitkopf','Multiscale structural topology optimization with an approximate constitutive model for local material microstructure','Computer Methods in Applied Mechanics and Engineering 286, 147--167',2015,'https://www.sciencedirect.com/science/article/pii/S0045782514004976',13)
add('zhou','S. Zhou, Q. Li','Design of graded two-phase microstructures for tailored elasticity gradients','Journal of Materials Science 43, 5157--5167',2008,original=16)
add('panetta','J. Panetta, Q. Zhou, L. Malomo, N. Pietroni, P. Cignoni, D. Zorin','Elastic textures for additive fabrication','ACM Transactions on Graphics 34(4), 135',2015,'https://doi.org/10.1145/2766937',23)
add('schumacher','C. Schumacher, B. Bickel, J. Rys, S. Marschner, C. Daraio, M. Gross','Microstructures to control elasticity in 3D printing','ACM Transactions on Graphics 34(4), 136',2015,'https://doi.org/10.1145/2766926',28)
add('cheng','L. Cheng, J. Bai, A. C. To','Functionally graded lattice structure topology optimization for the design of additive manufactured components with stress constraints','Computer Methods in Applied Mechanics and Engineering 344, 334--359',2019,'https://www.sciencedirect.com/science/article/pii/S0045782518305061',24)
add('white','D. A. White, W. J. Arrighi, J. Kudo, S. E. Watts','Multiscale topology optimization using neural network surrogate models','Computer Methods in Applied Mechanics and Engineering 346, 1118--1135',2019,'https://www.sciencedirect.com/science/article/pii/S004578251830450X',32)
add('kingma','D. P. Kingma, M. Welling','Auto-encoding variational Bayes','International Conference on Learning Representations',2014,'https://arxiv.org/abs/1312.6114',35)
add('homog','L. Xia, P. Breitkopf','Design of materials using topology optimization and energy-based homogenization approach in Matlab','Structural and Multidisciplinary Optimization 52, 1229--1241',2015,'https://doi.org/10.1007/s00158-015-1294-0',48)
add('mma','K. Svanberg','The method of moving asymptotes---a new method for structural optimization','International Journal for Numerical Methods in Engineering 24, 359--373',1987,'https://doi.org/10.1002/nme.1620240207',52)
add('mrf','N. Komodakis, N. Paragios, G. Tziritas','MRF energy minimization and beyond via dual decomposition','IEEE Transactions on Pattern Analysis and Machine Intelligence 33(3), 531--552',2011,'https://www.csd.uoc.gr/~komod/publications.html',53)
add('gao','J. Gao, Z. Luo, L. Xia, L. Gao','Concurrent topology optimization of multiscale composite structures in Matlab','Structural and Multidisciplinary Optimization 60, 2621--2651',2019,'https://github.com/GabrielJie/Concurrent-topology-optimization-in-Matlab',55)
add('sivapuram','R. Sivapuram, P. D. Dunning, H. A. Kim','Simultaneous material and structural optimization by multiscale topology optimization','Structural and Multidisciplinary Optimization 54, 1267--1281',2016,'https://orca.cardiff.ac.uk/id/eprint/104063/',54)
add('watts','S. Watts, W. Arrighi, J. Kudo, D. A. Tortorelli, D. A. White','Simple, accurate surrogate models of the elastic response of three-dimensional open truss micro-architectures with applications to multiscale topology design','Structural and Multidisciplinary Optimization 60, 1887--1920',2019,'https://doi.org/10.1007/s00158-019-02297-5',31)
add('nie','Z. Nie, H. Jiang, L. B. Kara','Stress field prediction in cantilevered structures using convolutional neural networks','Journal of Computing and Information Science in Engineering 20(1), 011002',2020,'https://doi.org/10.1115/1.4044097',33)
add('metaset','Y.-C. Chan, F. Ahmed, L. Wang, W. Chen','METASET: Exploring shape and property spaces for data-driven metamaterials design','Journal of Mechanical Design 143(3), 031707',2021,'https://doi.org/10.1115/1.4048629',61)
add('shapedna','L. Wang, Y.-C. Chan, Z. Liu, P. Zhu, W. Chen',"Data-driven metamaterial design with Laplace--Beltrami spectrum as `shape-DNA'",'Structural and Multidisciplinary Optimization 61, 2613--2628',2020,'https://doi.org/10.1007/s00158-020-02523-5',19)
add('lvgp','L. Wang, S. Tao, P. Zhu, W. Chen','Data-driven topology optimization with multiclass microstructures using latent variable Gaussian process','Journal of Mechanical Design 143(3), 031708',2021,'https://doi.org/10.1115/1.4048628')
add('tmetaset','D. Lee, Y.-C. Chan, Wei (Wayne) Chen, L. Wang, A. van Beek, Wei Chen','t-METASET: Task-aware acquisition of metamaterial datasets through diversity-based active learning','Journal of Mechanical Design 145(3), 031704',2023,'https://doi.org/10.1115/1.4055925')
add('matsci','A. Chaudhari, J. Ock, A. Barati Farimani','Modular large language model agents for multi-task computational materials science','Communications Materials 7, 131',2026,'https://doi.org/10.1038/s43246-025-00994-x')
add('mechanicalagent','Y. Jadhav, A. Barati Farimani','Large language model agent as a mechanical designer','arXiv:2404.17525v3',2025,'https://arxiv.org/abs/2404.17525v3',status='preprint; first posted 2024, cited revision 2025')
add('processagent','T. Zeng, S. Badrinarayanan, J. Ock, C.-K. Lai, A. Barati Farimani','LLM-guided chemical process optimization with a multi-agent approach','arXiv:2506.20921v2',2025,'https://arxiv.org/abs/2506.20921v2',status='preprint')
add('alloyagent','P. Pak, A. Chandrasekhar, A. Barati Farimani','Agentic additive manufacturing alloy evaluation','Additive Manufacturing Letters 17, 100355',2026,'https://doi.org/10.1016/j.addlet.2026.100355')
add('databaseagent','A. Chandrasekhar, O. Barati Farimani, R. S. Meda, A. Barati Farimani','Material Database Agent: A multimodal agentic framework for scientific literature mining','arXiv:2605.04278',2026,'https://arxiv.org/abs/2605.04278',status='preprint')
add('agentscad','E. George, C. Keefe, P. Pak, A. Barati Farimani','AgentsCAD: Automated design for manufacturing of FDM parts via multi-agent LLM reasoning and geometric feature recognition','arXiv:2607.02448v2',2026,'https://arxiv.org/abs/2607.02448v2',status='preprint')
add('opro','C. Yang, X. Wang, Y. Lu, H. Liu, Q. V. Le, D. Zhou, X. Chen','Large language models as optimizers','International Conference on Learning Representations',2024,'https://arxiv.org/abs/2309.03409')
add('react','S. Yao, J. Zhao, D. Yu, N. Du, I. Shafran, K. Narasimhan, Y. Cao','ReAct: Synergizing reasoning and acting in language models','International Conference on Learning Representations',2023,'https://arxiv.org/abs/2210.03629')
add('autogen','Q. Wu, G. Bansal, J. Zhang, Y. Wu, B. Li, E. Zhu, L. Jiang, X. Zhang, S. Zhang, A. H. Awadallah, R. W. White, D. Burger, C. Wang','AutoGen: Enabling next-gen LLM applications via multi-agent conversation','Conference on Language Modeling',2024,'https://arxiv.org/abs/2308.08155')
add('chemcrow','A. M. Bran, S. Cox, O. Schilter, C. Baldassari, A. D. White, P. Schwaller','Augmenting large language models with chemistry tools','Nature Machine Intelligence 6, 525--535',2024,'https://doi.org/10.1038/s42256-024-00832-8')
add('coscientist','D. A. Boiko, R. MacKnight, B. Kline, G. Gomes','Autonomous chemical research with large language models','Nature 624, 570--578',2023,'https://doi.org/10.1038/s41586-023-06792-0')
add('toolformer',r'T. Schick, J. Dwivedi-Yu, R. Dess\`i, R. Raileanu, M. Lomeli, E. Hambro, L. Zettlemoyer, N. Cancedda, T. Scialom','Toolformer: Language models can teach themselves to use tools','Advances in Neural Information Processing Systems 36',2023,'https://arxiv.org/abs/2302.04761')
add('reflexion','N. Shinn, F. Cassano, A. Gopinath, K. Narasimhan, S. Yao','Reflexion: Language agents with verbal reinforcement learning','Advances in Neural Information Processing Systems 36',2023,'https://papers.nips.cc/paper_files/paper/2023/hash/1b44b878bb782e6954cd888628510e90-Abstract-Conference.html')
add('tot','S. Yao, D. Yu, J. Zhao, I. Shafran, T. L. Griffiths, Y. Cao, K. Narasimhan','Tree of thoughts: Deliberate problem solving with large language models','Advances in Neural Information Processing Systems 36',2023,'https://arxiv.org/abs/2305.10601')
add('debate','Y. Du, S. Li, A. Torralba, J. B. Tenenbaum, I. Mordatch','Improving factuality and reasoning in language models through multiagent debate','Proceedings of Machine Learning Research 235, 11733--11763',2024,'https://proceedings.mlr.press/v235/du24e.html')
RELATED=r'''\section{Related work and scope}
\subsection{Multiscale design, homogenization, and compatible assembly}
Mechanical metamaterials use geometry to control stiffness, compressibility, and deformation modes~\cite{yu,clausen}. For a spatially heterogeneous structure, inverse design couples cell-scale constitutive behavior to the response of the assembled domain. Concurrent approaches optimize material and structural variables within a multiscale analysis~\cite{xia2014,sivapuram}; reduced constitutive models and practical implementations reduce the repeated cost of local design~\cite{xia2015,gao}. Energy-based homogenization supplies an efficient route from periodic cell geometry to effective stiffness~\cite{homog}, while graded microstructures distribute these properties through space~\cite{zhou}. These approaches establish the mechanics and optimization setting of the present study; our agents operate on a supplied discrete library rather than generating a replacement constitutive model.

A continuous property field must ultimately be realized by connected microstructures. Two-scale optimization with precomputed property gamuts~\cite{zhu}, elastic texture libraries~\cite{panetta}, and interpolated microstructure families~\cite{schumacher} address complementary aspects of this realization problem. These methods show why local property matching and global mechanical performance are separate requirements. Our interface specialist therefore receives explicit geometric mismatch measurements, but compatibility reasoning is still checked by the assembled finite-element solution. A connected binary image alone does not establish manufacturability or strength.

\subsection{Data-driven metamaterials and the Wang design lineage}
Wang and co-workers developed reduced shape descriptions using the Laplace--Beltrami spectrum~\cite{shapedna}, followed by a variational generative representation that couples geometry, properties, and multiscale assembly~\cite{wang2020}. The underlying variational-autoencoder construction follows probabilistic latent-variable learning~\cite{kingma}. Their multiclass latent-variable Gaussian-process formulation provides a differentiable representation across microstructure concepts~\cite{lvgp}. These contributions concern representation and the structure of the material design space; the present investigation retains the supplied geometry candidates and tests how to select their discrete labels using successive measured outcomes.

Dataset construction is also a design decision. METASET balances diversity in shape and property spaces when selecting unit-cell subsets~\cite{metaset}, and t-METASET extends dataset acquisition toward task-aware, diversity-based active learning~\cite{tmetaset}. The mechanical-cloak study~\cite{cloak2022} demonstrates database-driven aperiodic assembly around a cavity, with its public orthotropic library documented separately~\cite{dataset}. We retain a supplied cavity, candidate sets, reference response, and evaluator associated with this line of work. This is a local assignment-repair study after those upstream choices, not a reproduction of the complete published design pipeline.

Learned response models can make multiscale design more efficient. White et al.~\cite{white} use neural-network surrogate models within multiscale topology optimization, and Watts et al.~\cite{watts} develop elastic-response surrogates for truss micro-architectures. Such models motivate useful proposal evidence, but surrogate accuracy and candidate ranking must be assessed for the actual assembled problem. Our numerical proposer uses a coarse homogenized scalar-adjoint score and measured calibration. The original framework instead uses a dual-decomposition Markov-random-field assembly algorithm~\cite{wang2020,mrf}. Gradient-based structural optimization also has established sequential-approximation methods, including the method of moving asymptotes~\cite{mma}; our discrete numerical policy does not implement that continuous optimizer. No trained graph neural network (GNN) selector is evaluated. Accordingly, the reported gains are relative to the specified adaptive numerical portfolio, not to those published algorithms or GNNs generally.

\subsection{Language agents, external tools, and coordinated search}
Language-agent methods offer several distinct mechanisms. ReAct alternates reasoning with external actions~\cite{react}, while Toolformer learns API use during model training~\cite{toolformer}. Optimization by prompting conditions new proposals on evaluated candidates~\cite{opro}. Reflexion retains linguistic feedback from previous trials~\cite{reflexion}, and Tree of Thoughts explores alternative reasoning paths~\cite{tot}. These works motivate explicit tool interfaces, outcome memory, and alternative hypotheses, but they do not establish that verbal reasoning is an accurate mechanical surrogate. In this paper, numerical equilibrium and the monitored displacement loss determine whether a proposed design is retained.

AutoGen provides a framework for conversation among specialized agents and tools~\cite{autogen}; multiagent debate studies how interacting responses can improve reasoning on its evaluated tasks~\cite{debate}. We draw on the distinction between complementary responsibilities and independent repetition. The response specialist proposes compositions and ablations; the interface specialist tests compatible spatial groups; and coordination checks novelty and commits the evaluation batch. We do not infer a benefit merely from increasing the number of agents. Debate-style agreement cannot replace a finite-element assessment, and our single trajectory does not identify the causal contribution of communication.

Scientific tool agents provide a closer application precedent. ChemCrow connects language models to chemistry tools~\cite{chemcrow}, and Coscientist orchestrates chemical-research tasks using external resources and laboratory capabilities~\cite{coscientist}. These studies support grounding agent actions in executable tools rather than relying on unsupported narrative answers. Their chemistry results are not performance baselines for mechanical cloaking.

\subsection{Agentic engineering and materials workflows}
Within our group's work, MatSciAgent routes materials questions to specialized modules for retrieval, continuum simulation, structure generation, and molecular dynamics~\cite{matsci}. Jadhav and Barati Farimani couple a mechanical-design agent to finite-element feedback for iterative truss refinement~\cite{mechanicalagent}. These are direct precedents for separating an agent's design decisions from a numerical evaluator. Our contribution focuses on heterogeneous microstructure assignment, a costly pixel-resolved cloak model, and a recorded comparison against an adaptive numerical selection policy.

Other workflows illustrate complementary responsibilities. Multi-agent chemical-process optimization assigns roles to constraints, validation, simulation, and optimization guidance~\cite{processagent}. Agentic alloy evaluation links reasoning to thermophysical calculations and process-window assessment~\cite{alloyagent}. AgentsCAD couples geometric feature analysis, design recommendations, and visual verification~\cite{agentscad}, whereas Material Database Agent uses specialized agents to extract and assemble materials information from literature~\cite{databaseagent}. The mechanical-designer, process-optimization, AgentsCAD, and database-agent references are cited as preprints at their specified versions. Their relevance is the organization of evidence and task-specific tools, not a claim that their results demonstrate improved cloak performance.

The distinction from these precedents is therefore specific: the present specialists select existing cell labels, use the same numerical evidence and initial trial ledger, commit distinct proposals before observing their outcomes, and retain designs only after the original-resolution mechanical evaluation. The comparison measures the resulting search system. It does not benchmark the cited agent frameworks against one another, automate the complete original metamaterial pipeline, or demonstrate manufacturing readiness.

'''

def revise(source):
 if r'\usepackage{cite}' not in source:source=source.replace(r'\usepackage{microtype}',r'\usepackage{microtype}'+'\n'+r'\usepackage{cite}')
 source=re.sub(r'\\section\{Related work and scope\}.*?(?=\\section\{Mechanical cloaking problem\})',lambda _:RELATED,source,flags=re.S)
 old='Heterogeneous mechanical metamaterials distribute different microstructures across a domain to produce a desired structural response.'
 new='Heterogeneous mechanical metamaterials distribute different microstructures across a domain to produce a desired structural response~\\cite{yu,zhou}.'
 source=source.replace(old,new)
 old='Data-driven design frameworks already combine learned microstructure representations, property optimization, and compatibility-aware assembly~\\cite{wang2020}.'
 new='Data-driven design frameworks already combine learned microstructure representations, property optimization, and compatibility-aware assembly~\\cite{shapedna,wang2020,metaset,lvgp}.'
 source=source.replace(old,new)
 old='The proposed system treats coordination as an experimental-design task.'
 new='Tool-using scientific agents and agentic mechanical design motivate coupling language-based proposals to executable evaluations~\\cite{chemcrow,coscientist,matsci,mechanicalagent}. The proposed system treats coordination as an experimental-design task.'
 if new not in source:source=source.replace(old,new)
 old='The optimized objective is exterior displacement error, not stress uniformity.'
 new='The optimized objective is exterior displacement error, not stress uniformity. Stress-constrained lattice optimization treats stress as an explicit design requirement~\\cite{cheng}; stress-field learning instead targets a response prediction task~\\cite{nie}. Here, stresses are recovered from saved equilibrium solutions as a secondary diagnostic.'
 if new not in source:source=source.replace(old,new)
 # Reference ordering follows first appearance throughout the manuscript.
 before=source.split(r'\begin{thebibliography}')[0]
 order=[]
 for group in re.findall(r'\\cite\{([^}]+)\}',before):
  for key in group.split(','):
   if key not in order:order.append(key)
 refs={r['key']:r for r in RECORDS}
 assert len(refs)==40 and set(order)==set(refs),(len(refs),set(refs)-set(order),set(order)-set(refs))
 lines=[r'\begin{thebibliography}{99}',r'\small']
 for key in order:
  r=refs[key];entry=r'\bibitem{'+key+'} '+r['authors']+'. '+r['title']+'. '+r'\emph{'+r['venue']+'} ('+str(r['year'])+').'
  if r['status'].startswith('preprint'):entry+=' Preprint.'
  if r['url']:
   label=r['url'].removeprefix('https://doi.org/') if 'doi.org/' in r['url'] else 'Publisher / author record'
   entry+=r' \href{'+r['url']+'}{'+label+'}.'
  lines.append(entry)
 lines += [r'\end{thebibliography}',r'\end{document}']
 source=before+'\n'.join(lines)+'\n'
 record={'checked_date':'2026-10-16','target':'Computer Methods in Applied Mechanics and Engineering (CMAME)','reference_count':40,'all_entries_cited':True,'order':'first citation','notes':'Original-paper references use the user-supplied primary bibliography; metadata updated to journal issue year where verified. Additional agent references checked against publisher/proceedings/arXiv records. Preprints explicitly identified. Links are primary publisher, author, or institutional records.','references':[refs[k] for k in order]}
 (ROOT/'outputs/paper-figures/reference-audit.json').write_text(json.dumps(record,indent=2))
 return source
if __name__=='__main__':
 p=ROOT/'outputs/overleaf-metamaterial-selector/main.tex';p.write_text(revise(p.read_text()));print('Updated existing manuscript: 40 cited references')
