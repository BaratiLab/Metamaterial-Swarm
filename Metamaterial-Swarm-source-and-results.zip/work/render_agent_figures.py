from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
out=Path('outputs/agent-figures');out.mkdir(exist_ok=True)
colors={'blue':'#245B91','teal':'#167D8D','purple':'#7753A6','amber':'#B97721','gray':'#566473'}

def start(title,sub):
 fig,ax=plt.subplots(figsize=(12,12));fig.patch.set_facecolor('#FFFFFF');ax.set(xlim=(0,12),ylim=(0,12));ax.axis('off')
 ax.text(.6,11.55,title,fontsize=23,weight='bold',color='#18324B',va='top')
 ax.text(.6,10.96,sub,fontsize=11.5,color='#566473',va='top')
 return fig,ax

def card(ax,x,y,w,h,title,lines,c='blue',fs=11):
 col=colors[c];ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.02,rounding_size=.12',linewidth=1.4,edgecolor=col,facecolor=col+'0D'))
 ax.text(x+.19,y+h-.22,title,fontsize=13,weight='bold',color=col,va='top')
 ax.text(x+.19,y+h-.62,'\n'.join(lines),fontsize=fs,color='#273C4F',va='top',linespacing=1.55)

def arrow(ax,a,b,c='blue',dash=False,style='arc3,rad=0'):
 ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=16,lw=1.7,color=colors[c],linestyle='--' if dash else '-',connectionstyle=style))

def save(fig,name):
 fig.savefig(out/(name+'.svg'),bbox_inches='tight',pad_inches=.18)
 fig.savefig(out/(name+'.png'),dpi=220,bbox_inches='tight',pad_inches=.18)
 plt.close(fig)

fig,ax=start('Physics-guided metamaterial design','Library-based discrete assembly with an agent proposal portfolio')
card(ax,.6,8.65,5.05,1.7,'01  Microstructure library',['90,245 binary unit-cell geometries','Stored stiffness tensors and volume fraction'])
card(ax,6.35,8.65,5.05,1.7,'02  Design objective',['Domain, loading, and boundary conditions','Target displacement profile'])
card(ax,.6,6.55,10.8,1.4,'03  Optimize the target field and retrieve candidates',['Ten candidates at each of 120 locations → one unit-cell label per location'])
arrow(ax,(3.1,8.65),(3.1,7.95));arrow(ax,(8.9,8.65),(8.9,7.95))
card(ax,.6,4.15,5.05,1.7,'04  Assembled-geometry physics',['Fine FEM + response adjoints','1080 response vectors + interface features'],'teal')
card(ax,6.35,4.15,5.05,1.7,'05  Specialized agent portfolio',['Response · Interface · Cautious','Existing candidate labels; adaptive search'],'purple')
arrow(ax,(3.1,6.55),(3.1,5.85));arrow(ax,(5.65,5),(6.35,5),'teal')
card(ax,.6,1.9,10.8,1.55,'06  Commit proposals, simulate, and retain',['Fine-FEM evaluation of agent and numerical batches','Accept the best eligible improvement; archive every assessed trial'],'amber')
arrow(ax,(8.9,4.15),(8.9,3.45),'purple')
ax.text(.65,1.2,'Observed case: 4.86% → 3.92% displacement error',fontsize=17,weight='bold',color=colors['teal'])
ax.text(.65,.75,'Single target; no established superiority over adaptive optimizers or GNNs.',fontsize=11,color=colors['gray'])
ax.plot([.6,.18,.18,.6],[2.5,2.5,4.0,4.0],color=colors['teal'],lw=1.6,ls='--'); arrow(ax,(.6,4.0),(.6,4.9),'teal',True)
ax.text(.75,3.76,'Next incumbent',fontsize=9,color=colors['teal'])
save(fig,'overall-concept')

fig,ax=start('A coordinated portfolio of three agents','Shared mechanical evidence · independent proposals · common validation')
card(ax,.6,8.75,10.8,1.55,'01  Shared round evidence',['Same incumbent, target, and candidate sets; previous-round outcomes','1080 replacement options with 62-coordinate response vectors'])
for x,title,lines,c in [(.6,'Response agent',['Match displacement','Combine corrections','Adapt response scaling'],'blue'),(4.3,'Interface agent',['Limit geometry changes','Search combinations','Revise interface filters'],'purple'),(8.0,'Cautious agent',['Use conservative batches','Inspect pixel changes','Limit uncertain steps'],'teal')]:
 card(ax,x,5.65,3.4,2.35,title,lines,c,10.6);arrow(ax,(x+1.7,8.75),(x+1.7,8))
ax.text(6,.02,'Each agent submits ≤8 distinct-cell changes; no within-round fine-FEM lookahead.',ha='center',fontsize=9.5,color=colors['gray'])
card(ax,.6,3.2,6.7,1.35,'02  Commit three agent batches',['Save literal candidate labels and action-file hashes'],'purple',10.5)
card(ax,8.0,3.2,3.4,1.35,'Numerical controls',['Fixed greedy caps: 1, 4, 8','Same round evidence'],'gray',10.2)
for x in [2.3,6,9.7]:arrow(ax,(x,5.65),(4.0,4.55),'purple')
card(ax,.6,.95,10.8,1.55,'03  Evaluate all six proposals and retain the best improvement',['300,000-element FEM; connectivity, interface, and volume checks','Update the shared incumbent, or retain it if no proposal improves'],'amber',10.7)
arrow(ax,(4,3.2),(4,2.5),'purple');arrow(ax,(9.7,3.2),(9.7,2.5),'gray')
ax.plot([.6,.18,.18,.6],[1.7,1.7,8.3,8.3],color=colors['teal'],lw=1.6,ls='--'); arrow(ax,(.6,8.3),(.6,9.3),'teal',True)
ax.text(6,.38,'Three rounds · nine assessments per group · all outcomes retained',ha='center',fontsize=11,color=colors['gray'])
save(fig,'agent-swarm')
print(str(out.resolve()))
