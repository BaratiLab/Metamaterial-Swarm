from pathlib import Path
p=Path('outputs/overleaf-metamaterial-selector/main.tex');s=p.read_text()
s=s.replace('\\usepackage{xcolor}',r'''\usepackage{xcolor,graphicx}
\usetikzlibrary{arrows.meta,positioning,fit,backgrounds}
\definecolor{conceptblue}{HTML}{245B91}
\definecolor{conceptteal}{HTML}{167D8D}
\definecolor{conceptpurple}{HTML}{7753A6}
\definecolor{conceptamber}{HTML}{B97721}
\tikzset{
 conceptbox/.style={rounded corners=5pt,draw=conceptblue!50,fill=conceptblue!5,thick,align=center,font=\small,inner sep=9pt},
 conceptflow/.style={-{Stealth[length=2.5mm]},thick,draw=conceptblue!80},
 conceptfeedback/.style={-{Stealth[length=2.5mm]},thick,dashed,draw=conceptteal},
 conceptnote/.style={font=\footnotesize,align=center,text=black!65}
}
''')
concept=r'''\begin{figure}[p]
\centering
\resizebox{\linewidth}{!}{%
\begin{tikzpicture}
\node[conceptbox,text width=4.8cm,minimum height=1.35cm] (library) at (-3.4,0) {\textbf{Microstructure library}\\90,245 binary unit cells\\Stored stiffness and volume fraction};
\node[conceptbox,text width=4.8cm,minimum height=1.35cm] (target) at (3.4,0) {\textbf{Design objective}\\Beam domain and prescribed loading\\Target boundary-displacement profile};
\node[conceptbox,text width=11.4cm,minimum height=1.15cm] (field) at (0,-2.2) {\textbf{Continuous design and candidate retrieval}\\Optimize the macro stiffness field; retain ten library candidates at each of 120 locations};
\draw[conceptflow] (library.south) -- ++(0,-.4) -| (field.north);
\draw[conceptflow] (target.south) -- ++(0,-.4) -| (field.north);
\node[conceptbox,text width=11.4cm,minimum height=1.55cm] (grid) at (0,-4.6) {\textbf{Discrete metamaterial assembly}\\One candidate label per macro cell; graph costs encourage compatible neighbors\\$4\times30$ cells $\longrightarrow$ $1500\times200$ pixel elements};
\draw[conceptflow] (field) -- (grid);
\node[conceptbox,draw=conceptteal!70,fill=conceptteal!6,text width=4.8cm,minimum height=1.6cm] (physics) at (-3.4,-7.2) {\textbf{Assembled-geometry physics}\\Forward FEM and response adjoints\\Candidate response vectors\\Interface and pixel-change features};
\node[conceptbox,draw=conceptpurple!70,fill=conceptpurple!6,text width=4.8cm,minimum height=1.6cm] (swarm) at (3.4,-7.2) {\textbf{Agent proposal portfolio}\\Response, interface, cautious roles\\Inspect common numerical evidence\\Propose existing candidate labels};
\draw[conceptflow] (grid.south) -- ++(0,-.35) -| (physics.north);
\draw[conceptflow] (physics.east) -- node[conceptnote,above,text width=1.4cm] {shared\\evidence} (swarm.west);
\node[conceptbox,draw=conceptamber!70,fill=conceptamber!7,text width=11.4cm,minimum height=1.45cm] (validate) at (0,-10) {\textbf{Commit, simulate, and validate}\\Save all agent and numerical proposals before their outcomes are observed\\Measure fine displacement error; enforce connectivity, interface, and volume bounds};
\draw[conceptflow] (swarm.south) -- ++(0,-.35) -| (validate.north);
\node[conceptbox,draw=conceptteal!70,fill=conceptteal!9,text width=11.4cm,minimum height=1.25cm] (output) at (0,-12.5) {\textbf{Retain the best eligible improvement}\\Update the common incumbent and archive every trial\\Observed case: $4.86\%\ \longrightarrow\ 3.92\%$ relative displacement error};
\draw[conceptflow] (validate) -- (output);
\draw[conceptfeedback] (output.west) -- ++(-1.1,0) |- node[conceptnote,pos=.25,rotate=90,text width=3.5cm] {next-round incumbent} (physics.west);
\end{tikzpicture}}
\caption{Overall concept of physics-guided discrete metamaterial design. Unit-cell geometries remain in a fixed library; the agents choose labels and search strategies. Finite elements supply the response evidence and determine whether an assembly improves. The improvement shown is the observed single-target result, not a general performance guarantee.}
\label{fig:concept}
\end{figure}

'''
s=s.replace('\\section{Related work and positioning}',concept+'\\section{Related work and positioning}')
# replace boxed protocol with a detailed true topology of cooperation.
a=s.index('\\begin{figure}[htbp]\n\\centering\\fbox{');b=s.index('\\end{figure}',a)+len('\\end{figure}')
swarm=r'''\begin{figure}[p]
\centering\resizebox{\linewidth}{!}{%
\begin{tikzpicture}
\node[conceptbox,text width=12cm,minimum height=1.45cm] (evidence) at (0,0) {\textbf{Shared round state and mechanical evidence}\\Same incumbent, target, ten candidates per location, and previous-round outcomes\\1080 replacement options with 62-coordinate response vectors and compatibility features};
\node[conceptbox,draw=conceptblue!70,fill=conceptblue!7,text width=3.3cm,minimum height=2.15cm] (response) at (-4.5,-3.0) {\textbf{Response agent}\\Match boundary displacement\\Combine response corrections\\Adapt using observed error};
\node[conceptbox,draw=conceptpurple!70,fill=conceptpurple!7,text width=3.3cm,minimum height=2.15cm] (interface) at (0,-3.0) {\textbf{Interface agent}\\Limit geometry disruption\\Search small combinations\\Revise interface filters};
\node[conceptbox,draw=conceptteal!70,fill=conceptteal!7,text width=3.3cm,minimum height=2.15cm] (cautious) at (4.5,-3.0) {\textbf{Cautious agent}\\Favor conservative batches\\Inspect pixel-change size\\Avoid large uncertain steps};
\draw[conceptflow] (evidence.south) -- ++(0,-.45) -| (response.north);
\draw[conceptflow] (evidence.south) -- (interface.north);
\draw[conceptflow] (evidence.south) -- ++(0,-.45) -| (cautious.north);
\node[conceptnote,text width=12cm] at (0,-4.7) {Complementary proposal roles; each submits at most eight distinct-cell changes.\\Cooperation occurs through shared evidence and the retained incumbent.};
\node[conceptbox,draw=conceptpurple!60,fill=conceptpurple!4,text width=7.8cm,minimum height=1.15cm] (commit) at (-2.1,-6.4) {\textbf{Commit three agent proposals}\\Literal labels and action-file hashes saved before evaluation};
\draw[conceptflow] (response.south) -- ++(0,-1.1) -| (commit.north);
\draw[conceptflow] (interface.south) -- ++(0,-1.25) -| (commit.north);
\draw[conceptflow] (cautious.south) -- ++(0,-1.4) -| (commit.north);
\node[conceptbox,text width=2.65cm,minimum height=1.6cm,draw=black!35,fill=black!3] (numeric) at (4.5,-6.4) {\textbf{Numerical controls}\\Fixed greedy policies\\Caps: 1, 4, 8\\Same round evidence};
\node[conceptbox,draw=conceptamber!70,fill=conceptamber!7,text width=12cm,minimum height=1.65cm] (solve) at (0,-9.0) {\textbf{Six committed batches $\longrightarrow$ six fine-FEM assessments}\\300,000 elements for each proposed geometry\\Measure displacement error and verify one solid component, interface bounds, and volume bounds};
\draw[conceptflow] (commit.south) -- ++(0,-.45) -| (solve.north);
\draw[conceptflow] (numeric.south) -- ++(0,-.45) -| (solve.north);
\node[conceptbox,draw=conceptteal!70,fill=conceptteal!8,text width=12cm,minimum height=1.4cm] (retain) at (0,-11.7) {\textbf{Shared incumbent selection}\\Accept the lowest-error eligible proposal only if it improves the incumbent\\If none improves, keep the incumbent; retain all successful and unsuccessful outcomes};
\draw[conceptflow] (solve) -- (retain);
\draw[conceptfeedback] (retain.west) -- ++(-1.2,0) |- (evidence.west);
\node[conceptnote,rotate=90,text width=5cm] at (-8.2,-5.9) {Feedback to all proposers after the round};
\node[conceptnote,text width=12cm] at (0,-13.25) {Three rounds: nine agent and nine numerical candidate assessments.\\Agents adapt selection strategies; numerical controls remain fixed.};
\end{tikzpicture}}
\caption{How the three-agent portfolio works together in the executed experiment. Agents propose independently from shared evidence; a common finite-element evaluator and retention rule coordinate the portfolio. Numerical controls use the same incumbent and feedback. Arrows indicate information and proposal flow, not direct inter-agent voting or communication.}
\label{fig:protocol}
\end{figure}'''
s=s[:a]+swarm+s[b:]
s=s.replace('The contributions are an implemented library-based selection problem with fixed candidates,','Figures~\\ref{fig:concept} and~\\ref{fig:protocol} summarize the overall design workflow and the coordination of agent proposals. The contributions are an implemented library-based selection problem with fixed candidates,')
p.write_text(s)
print('Added two self-contained vector conceptual figures.')
