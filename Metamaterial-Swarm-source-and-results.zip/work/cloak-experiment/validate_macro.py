import sys,json,numpy as np
from pathlib import Path
sys.path[:0]=['outputs/cloak-review','outputs/cloak-experiment']
from cloak_adapter import CloakProblem
from macro_feedback import model,score
p=CloakProblem('/Users/amirbaratifarimani/Downloads/Agent_Meta');c=model(p,p.labels);J,g,r=score(p,p.labels,c)
y,x=15,4;dc=c[y,x]*.07;eps=1e-4;vals=[]
for t in [-eps,eps]:
 cc=c.copy();cc[y,x]+=t*dc;cc[y,29-x]+=t*dc;vals.append(score(p,p.labels,cc)[0])
fd=(vals[1]-vals[0])/(2*eps);ad=np.sum((g[y,x]+g[y,29-x])*dc);rel=abs(fd-ad)/max(abs(fd),1e-30)
assert rel<1e-3,(fd,ad,rel)
f=Path('outputs/cloak-experiment/validation.json');v=json.loads(f.read_text());v['macro_adjoint_finite_difference_relative_error']=rel;v['macro_equilibrium_residual']=r;f.write_text(json.dumps(v,indent=2));print('macro adjoint validation',rel,'residual',r)
