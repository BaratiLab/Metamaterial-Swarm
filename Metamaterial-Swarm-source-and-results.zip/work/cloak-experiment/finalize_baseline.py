import sys,json,numpy as np
from pathlib import Path
sys.path[:0]=['outputs/cloak-review','outputs/cloak-experiment']
from cloak_adapter import CloakProblem
from fem_solver import reflect
p=CloakProblem('/Users/amirbaratifarimani/Downloads/Agent_Meta');r=json.loads(Path('work/cloak-experiment/verified_baseline/solver.json').read_text());u=np.load('work/cloak-experiment/verified_baseline/half_displacement.npy')
r['fine_loss']=p.outside_loss(reflect(u,1500));r['method']='Faithful Python Q4 port of UCal CA1, exact mirror reduction; target reproduction independently checked.';r['full_geometry_adjoint_status']='CG did not complete promptly at original void contrast; stopped before any search outcomes. Comparison uses same homogenized feedback in both arms.'
Path('outputs/cloak-experiment/supplied_assignment_result.json').write_text(json.dumps(r,indent=2));np.save('outputs/cloak-experiment/baseline_labels.npy',p.labels)
print('VERIFIED LOSS',r['fine_loss'],'FORCE RESIDUAL',r['relative_force_residual'])
from macro_feedback import candidate_scores
scores,J=candidate_scores(p,p.labels,r['fine_loss']);print('MACRO ERROR',J**.5,'SCORE RANGE',min(scores.values()),max(scores.values()))
