import sys,json
from pathlib import Path
import numpy as np
from scipy.sparse.linalg import spsolve
sys.path.insert(0,'outputs/cloak-experiment')
from fem_solver import matrix,force,reflect,density_gradient,element
rng=np.random.default_rng(93);phi=rng.uniform(.3,1,(12,6))
H,fixed=matrix(phi);b=force(6,12);b[fixed]=0;u=spsolve(H.tocsc(),b)
full=reflect(u,12);target=full*.87;scale=target@target;res=2*(full-target)/scale
q=res.reshape((13,13,2));qh=q[:7].copy();r=q[7:][::-1].copy();r[:,:,0]*=-1;qh[:6]+=r
rhs=qh.ravel();rhs[fixed]=0;lam=spsolve(H.tocsc(),rhs)
g=density_gradient(u,lam,6,12,element());eps=1e-5;values=[]
for change in [-eps,eps]:
 p=phi.copy();p[7,3]+=change;A,_=matrix(p);v=spsolve(A.tocsc(),b);f=reflect(v,12);values.append(np.linalg.norm(f-target)**2/scale)
fd=(values[1]-values[0])/(2*eps);relative=abs(fd-g[7,3])/abs(fd);assert relative<1e-6,relative
path=Path('outputs/cloak-experiment/validation.json');report=json.loads(path.read_text());report['scalar_adjoint_finite_difference_relative_error']=relative;path.write_text(json.dumps(report,indent=2));print(report)
