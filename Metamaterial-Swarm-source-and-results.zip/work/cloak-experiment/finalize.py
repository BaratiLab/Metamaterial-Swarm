from pathlib import Path
import sys,json,hashlib,csv,zipfile
import numpy as np
from scipy.io import savemat
root=Path('outputs/cloak-experiment');sys.path.insert(0,str(root.resolve()))
from adaptive_selector import propose
base=json.loads((root/'supplied_assignment_result.json').read_text());summary=json.loads((root/'summary.json').read_text())
rows=[];states={}
for arm in ['numerical','swarm']:
 state=json.loads((root/arm/'state.json').read_text());assert len(state['rounds'])==3 and len(state['history'])==9;states[arm]=state;rows+=state['history']
 savemat(root/(arm+'_retained_labels.mat'),{'Label':np.array(state['labels'],dtype=np.int64)})
for n in [1,2,3]:
 f=json.loads((root/f'numerical/round{n}/feedback.json').read_text());old=json.loads((root/f'numerical/round{n}/proposals.json').read_text());new=propose(f,f['history'])
 assert [p['actions'] for p in old]==[p['actions'] for p in new],n
p=root/'numerical_policy_replay.json';rep=json.loads(p.read_text());rep['round3']=True;rep['all_nine_actions_replayed_exactly']=True;p.write_text(json.dumps(rep,indent=2))
reference=json.loads((root/'reference_check.json').read_text());balance=json.loads((root/'force_balance.json').read_text())
num=states['numerical']['loss'];swarm=states['swarm']['loss'];eps=base['fine_loss']
text=f'''Mechanical cloaking reproduction and matched-budget comparison
16 October 2026

Outcome
The supplied label assignment evaluates to {eps*100:.6f}% normalized outside-region displacement error. The adaptive numerical search retained {num*100:.6f}%; the three-agent swarm retained {swarm*100:.6f}%. {'The adaptive numerical search produced the lower error in this experiment.' if num<swarm else 'The swarm produced the lower error in this experiment.'}

Relative error reductions from the supplied assignment:
Adaptive numerical: {(1-num/eps)*100:.4f}%
Swarm: {(1-swarm/eps)*100:.4f}%
Difference between retained errors: {abs(num-swarm)*100:.6f} percentage points.

Each group received nine proposal slots across three rounds. Every proposal could alter at most four independent cloak cells. These are independent trajectories, starting from the same supplied assignment; each group receives only its own previous measured outcomes. Every group commits its three batches before observing outcomes for that round. All unsuccessful trials are preserved in trials.csv and the arm histories.

Reproduction and verification
The full 1500 x 1500 pixel discretization is retained: 2,250,000 Q4 elements and 4,506,002 displacement coordinates. The supplied outside mask monitors 742,482 coordinates. Exact horizontal mirror symmetry reduces the linear solve to a 750 x 1500 element half-domain; reflected displacement is reconstructed before the original masked loss is calculated. No spatial coarsening is used for candidate assessment.

The evaluator is a Python port of Assemble/UCal/Evaluate, not an execution of MATLAB. All original material, load, support, and void conventions are retained, including the double E0 factor in UCal. No expected author-reported scalar loss was included; the reproduction checks instead compare a computed reference structure against the supplied UOrigin and verify the numerical formulation.

The reference structure reproduces the monitored target to relative error {reference['reference_target_relative_error']:.3e}. Independent small-model half/full equivalence is 1.097e-15; stiffness-entry disagreement with an independent element-triplet assembly is 4.441e-16. The supplied-assignment solver force residual is {base['relative_force_residual']:.3e}. Direct element-force balance checks for the supplied and retained assemblies are saved in force_balance.json; their worst relative net-force imbalance is {max(v['relative_net_force_imbalance'] for v in balance.values()):.3e}.

Selection feedback and computational budget
Both methods receive the same type of 30 x 30 homogenized elastic model, scalar objective-adjoint scores, candidate property mismatches, pixel-change fractions, and exact geometric-interface changes. Macro squared-error changes are scaled by incumbent fine_J/macro_J. This shared approximation guides selection only; all reported losses are full-resolution outcomes.

The full-geometry scalar-adjoint attempt was interrupted before search outcomes because of slow convergence at the original 7e15 material contrast. A small-model derivative check does not establish convergence of that full-model adjoint. The benchmark therefore must not be described as using full-geometry response sensitivities. The initial homogenized macro error was about 41.15%, versus the 12.76% measured fine error, and many initial predicted improvements worsened the fine response.

The adaptive numerical portfolio uses a calibration singleton, trust-region combination search, and diverse beam search. It learns a signed gain calibration and changes pixel/batch limits using measured outcomes. A positive surrogate direction can become useful when measured calibration reverses its sign. Numerical implementation details were refined during this exploratory session; the final implementation was then checked to reproduce every earlier numerical action exactly from its own recorded feedback/history. All nine numerical actions replay exactly. This is not a preregistered or held-out optimizer evaluation.

The swarm uses response, interface, and cautious roles. The coordinator resolves duplicate proposed batches before evaluation without revealing candidate outcomes. Agents can use cheap searches over the supplied features. One useful swarm step used empirical ablation: comparing a four-swap batch with its two-swap subset suggested testing the remaining pair alone; that measured test improved the incumbent. Later proposals tested composition of previously useful changes. These procedures combine language-guided strategy choice and numerical evidence; they are not language-only mechanical predictions.

Counts
'''
for arm,state in states.items():
 unique=len({h['geometry_key'] for h in state['history']});new=sum(not h['cached'] for h in state['history'])
 best=min(state['history'],key=lambda h:h['loss']);changed=int(np.sum(np.array(state['labels'])!=np.load(root/'baseline_labels.npy')))
 text+=f"{arm}: 9 slots, {unique} unique label assignments, {new} new fine solves; final {changed} independently changed cells; volume fraction {best['volume_fraction']:.8f}; connected components {best['solid_components']}.\n"
text+='''
Fine-solver seconds in trials.csv cover the iterative solve and refinement; they exclude multigrid setup, feature formation, and language-model selection. Token costs and all selection latencies were not measured. A same-design cache avoids duplicate physical solves without creating additional proposal slots. Preparation/reference solves are outside both search budgets.

Interpretation
Both procedures improved the supplied assignment under the same original objective. The lower retained loss identifies the better tested procedure on this one supplied cloak target and this budget; it does not establish general optimizer superiority. There are no repeated-agent teams, confidence intervals, GNN baseline, additional cavity geometries, or alternative load cases. Agent model snapshot/decoding settings are not fully specified. No fabrication, nonlinear, strength, or mesh-convergence claims are made. Connectivity and volume/interface metrics are reported, not newly imposed optimization constraints.

The original paper/manuscript and Overleaf project were not changed during this experiment. These results can support a clearly scoped new benchmark section; they should not be converted into an unsupported claim that the swarm beats adaptive numerical optimization.

Round-by-round retained errors in percent
Round       Adaptive numerical       Swarm
0           '''+f'{eps*100:.6f}                  {eps*100:.6f}\n'
for n in range(3):text+=f"{n+1}           {states['numerical']['rounds'][n]['retained_loss']*100:.6f}                  {states['swarm']['rounds'][n]['retained_loss']*100:.6f}\n"
text+='\nAll measured proposals in percent\n'
for h in rows:text+=f"{h['arm']:10s} round {h['round']} {h['name']:29s} {h['loss']*100:.6f}  swaps={len(h['actions'])}  residual={h['force_residual']:.3e}\n"
(root/'RESULTS.txt').write_text(text)
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and p.suffix in ['.py','.json','.csv','.mat','.txt'] and '__pycache__' not in p.parts and p.name!='manifest.json'}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile('outputs/cloak-experiment-results.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix in ['.py','.json','.csv','.txt','.png','.svg','.mat','.npz']:
   z.write(p,p.relative_to(root))
print(text[:950])
