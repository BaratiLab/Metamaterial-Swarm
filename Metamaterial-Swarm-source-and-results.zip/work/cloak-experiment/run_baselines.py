import sys,gc,json,time
from pathlib import Path
import numpy as np
sys.path[:0]=['outputs/cloak-experiment','outputs/cloak-review']
from fem_solver import solve,reflect,validate
from cloak_adapter import CloakProblem
p=CloakProblem('/Users/amirbaratifarimani/Downloads/Agent_Meta')
Path('outputs/cloak-experiment/validation.json').write_text(json.dumps(validate(),indent=2))
origin=np.tile(p.data['OriginCell'],(30,30))
_,r=solve(origin[:,:750], 'work/cloak-experiment/reference_check',initial=None)
u=np.load('work/cloak-experiment/reference_check/half_displacement.npy');full=reflect(u,1500)
ref=p.outside_loss(full);r['reference_target_relative_error']=ref
Path('outputs/cloak-experiment/reference_check.json').write_text(json.dumps(r,indent=2));print('TARGET REPRODUCTION ERROR',ref,flush=True)
del full,u;gc.collect()
phi=p.assemble(p.labels)
initial=np.load('work/cloak-experiment/baseline/half_displacement.npy')
u,r=solve(phi[:,:750],'work/cloak-experiment/verified_baseline',initial=initial,target=p.target,monitored=p.monitored)
Path('outputs/cloak-experiment/supplied_assignment_result.json').write_text(json.dumps(r,indent=2))
np.save('outputs/cloak-experiment/baseline_labels.npy',p.labels)
