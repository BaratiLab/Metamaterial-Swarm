"""Append the measured follow-up to the existing open LaTeX document in place."""
from pathlib import Path
import json,shutil

root=Path('/Users/amirbaratifarimani/Documents/Codex/2026-10-02/files-mentioned-by-the-user-1')
swarm=root/'outputs/metamaterial-selector/swarm'
out=root/'outputs/overleaf-metamaterial-selector'
main=out/'main.tex'
h=json.loads((swarm/'history.json').read_text())
assert len(h['rounds'])==3
t=main.read_text()
assert '\\section{Follow-up: three-agent repair portfolio}' not in t
rows='\n'.join(f'{r["round"]} & {100*r["starting_error"]:.3f} & {100*r["best_agent_error"]:.3f} & {100*r["best_numerical_error"]:.3f} & {100*r["incumbent_error"]:.3f} \\\\' for r in h['rounds'])
start=100*h['protocol']['starting_fine_error'];end=100*h['incumbent']['fine_relative_error']
gain=100*(1-end/start)
retained=' '.join(f'({i},{100*v:.6f})' for i,v in enumerate([h['protocol']['starting_fine_error']]+[r['incumbent_error'] for r in h['rounds']]))
agent=' '.join(f'({r["round"]},{100*r["best_agent_error"]:.6f})' for r in h['rounds'])
numeric=' '.join(f'({r["round"]},{100*r["best_numerical_error"]:.6f})' for r in h['rounds'])
section=r'''\section{Follow-up: three-agent repair portfolio}
\subsection{Protocol and full-geometry feedback}
Following the initial negative result, we tested three independent LLM subagents specializing in response matching, interface compatibility, and cautious small changes. The starting assembly was the strongest numerical repair from the original pilot, with START\% fine error. Candidate sets, target, material parameters, and loading conditions were unchanged.

We replaced homogenized repair estimates with displacement-response sensitivities from the actual assembled geometry. One forward solve and multiple response adjoints were computed for each common incumbent. For candidate pixel changes $\Delta\rho_e$, the first-order boundary response is
\begin{equation}
\Delta u_s\approx-\sum_e\boldsymbol\lambda_s^{\mathsf T}
\left(\frac{\partial\mathbf K}{\partial\rho_e}\right)\mathbf u\,\Delta\rho_e,
\end{equation}
where $\boldsymbol\lambda_s$ is the adjoint associated with sampled displacement $u_s$. We score a batch using the norm of the incumbent residual plus the sum of its candidate response vectors. The response derivative agreed with central finite differences on a smaller independent model to relative error $3.21\times10^{-9}$. This validates infinitesimal sensitivities, not their accuracy for finite topology changes.

Three deterministic numerical policies greedily minimized this linearized response error with maximum batch sizes of one, four, and eight swaps. Each LLM agent could likewise choose up to eight distinct-cell swaps, using the shared response vectors, interface costs, pixel-change fractions, and observed outcomes of previous rounds. Agents could construct small numerical searches over the supplied estimates; therefore, this tests an LLM-guided strategy portfolio, not unaided language-only optimization.

All six proposals were committed before any outcomes in that round were observed. There were three rounds and three full-FEM proposal assessments per group per round: nine agent assessments and nine numerical assessments. Repeated proposals were still assessed and recorded. Selection computation and token costs were not equated.

Eligibility required one connected solid component, mean geometric mismatch at most 0.20, mean mechanical mismatch at most 0.35, and volume fraction within 0.015 of the starting value. The best eligible assembly was retained only if its measured error improved. That assembly became the common incumbent for both groups in the next round. Thus, this is a common-incumbent competition; the two groups are not independent optimization trajectories and can benefit from one another's accepted proposals.

\subsection{Measured follow-up results}
\begin{table}[htbp]
\centering\small
\caption{Three-round comparison. Entries are measured full-geometry errors in percent. Best-agent and best-numerical columns report the best eligible proposal in that round; proposals can be worse than the starting assembly.}
\begin{tabular}{@{}crrrr@{}}\toprule
Round & Starting & Best agent & Best numerical & Retained\\\midrule
ROUND_ROWS
\bottomrule\end{tabular}
\end{table}

The final retained error was END\%, a GAIN\% reduction from the strongest initial numerical assembly. Round~1's interface-aware agent made three replacements, at zero-based cell/label pairs $(94,7)$, $(61,7)$, and $(93,7)$. Its measured error was 3.975\%, compared with 4.866\% for the best numerical proposal in that round. Subsequent results, including unsuccessful proposals, are retained in the experiment archive.

\begin{figure}[htbp]
\centering\begin{tikzpicture}
\begin{axis}[width=.88\linewidth,height=5.6cm,xmin=0,xmax=3.1,xtick={0,1,2,3},
xlabel={Round (0 = initial assembly)},ylabel={Full-geometry error (\%)},
grid=major,grid style={gray!15},legend style={font=\small,at={(.5,1.03)},anchor=south,legend columns=1}]
\addplot[black,mark=*,line width=1pt] coordinates {RETAINED};\addlegendentry{Shared retained assembly}
\addplot[magenta,only marks,mark=square*] coordinates {AGENT};\addlegendentry{Best eligible agent proposal}
\addplot[blue,only marks,mark=triangle*] coordinates {NUMERIC};\addlegendentry{Best eligible numerical proposal}
\end{axis}\end{tikzpicture}
\caption{Observed proposal outcomes and retained assembly across three rounds. No uncertainty estimates are available for this single-target experiment.}
\end{figure}

This follow-up demonstrates an agent contribution for the tested target under the stated protocol. It does not establish superiority over numerical optimization generally. The comparators are fixed greedy policies, not global optimizers, Bayesian optimization, or trained graph neural networks. No GNN experiment was performed. The agents' ability to change selection strategies using past outcomes, and their different search procedures, are part of the tested system rather than controlled away.

'''
for key,val in [('START',f'{start:.3f}'),('END',f'{end:.3f}'),('GAIN',f'{gain:.1f}'),('ROUND_ROWS',rows),('RETAINED',retained),('AGENT',agent),('NUMERIC',numeric)]:section=section.replace(key,val)
marker=r'\section{Validation and interpretation}'
assert t.count(marker)==1
t=t.replace(marker,section+marker)
t=t.replace('These findings establish implementation feasibility, rather than statistical superiority or an exact reproduction of the motivating paper.',
    f'A follow-up with three LLM subagents and three numerical policies over three common-incumbent rounds yielded a retained error of {end:.2f}\\%, using nine candidate assessments per group. The follow-up shows an agent contribution for this target, while neither experiment establishes statistical superiority or exactly reproduces the motivating paper.')
t=t.replace('It uses one target profile, one preparation seed, and one LLM decision batch.',
    'It uses one target profile and one preparation seed. The initial LLM decision batch is followed by a three-agent, three-round proposal competition.')
t=t.replace('This is one target and one LLM decision batch, with no repeated-model statistics or held-out target evaluation.',
    'Both stages use one target. The follow-up has three inherited-model agents over three rounds, with no independent repeated-team statistics or held-out target evaluation.')
t=t.replace('The next controlled experiment should compute repair sensitivities or local-response estimates from the assembled geometry, give numerical and LLM selectors identical evidence, and keep evaluation budgets equal.',
    'The follow-up implements assembled-geometry sensitivities and equal candidate-assessment counts. Further experiments should test stronger numerical comparators with learned response calibration and matched adaptive search capabilities.')
t=t.replace('This pilot implements that role on real geometries, but finds no performance advantage for its LLM repair. Numerical repair provides the strongest displacement result in the tested case. The useful outcome is a working controlled benchmark and evidence that assembled-geometry feedback should be tested before making broader claims of improved LLM selection.',
    f'The initial single-assistant repair did not improve the baseline. The three-agent follow-up, using assembled-geometry feedback, reduced the best initial numerical error from {start:.2f}\\% to {end:.2f}\\%. This is evidence of an agent contribution in the tested proposal competition, with generalization and superiority over stronger optimizers still unestablished.')
t=t.replace('and a supplementary raster comparison figure.',
    'supplementary raster comparison figures, and follow-up trial metrics and history.')
main.write_text(t)
for name,dest in [('trial_metrics.csv','swarm-trial-metrics.csv'),('history.json','swarm-history.json'),('swarm_comparison.png','swarm-comparison.png')]:shutil.copy2(swarm/name,out/dest)
print('Updated existing source:',main)
